package my.pkg;

import java.util.logging.Logger;

public class Elephant extends Animal {
	private static final Logger logger = Logger.getLogger("Elephant logger");

	static {
		System.setProperty("java.util.logging.SimpleFormatter.format", "[%1$tF %1$tT] [%4$-7s] %5$s %n");
	}

	public Elephant(String name) {
		super(name);
	}

	public void makeNoise() {
		logger.info(" Elephant  make Sound");
	}

	public void perform(String day) {
		if (day.equals("thursday") || day.equals("friday")) {
			makeNoise();
		}
	}
}