package my.pkg;

public class Employee {
	private final int id;
	private final String name;
	private final int employeeId;

	public Employee(int id, String name, int employeeId) {
		if (id < 1) {
			throw new IllegalArgumentException("id must not be negative");
		}
		if (name.isBlank() || name.isEmpty()) {
			throw new IllegalArgumentException("name must not be empty");
		}
		if (employeeId < 1000) {
			throw new IllegalArgumentException("employeeId must not less than 1000");
		}
		this.id = id;
		this.name = name;
		this.employeeId = employeeId;
	}

	public Employee() {
		this(1, "cyan", 1001);
	}

	@Override
	public String toString() {
		return "Employee{" +
				"id=" + id +
				", name='" + name + '\'' +
				", employeeId=" + employeeId +
				'}';
	}
}
