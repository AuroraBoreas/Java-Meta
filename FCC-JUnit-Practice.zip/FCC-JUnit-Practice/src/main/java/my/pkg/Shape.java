package my.pkg;

public class Shape {
	private final int numberOfSides;

	public Shape(int sides) {
		if (sides < 3 || sides == Integer.MAX_VALUE) {
			throw new IllegalArgumentException("ERR_EXP");
		}
		this.numberOfSides = sides;
	}

	public int getNumberOfSides() {
		return numberOfSides;
	}

	public String description() {
		return switch (numberOfSides) {
			case 3 -> "Triangle";
			case 4 -> "Square";
			case 5 -> "Pentagon";
			default -> "Polygon";
		};
	}
}
