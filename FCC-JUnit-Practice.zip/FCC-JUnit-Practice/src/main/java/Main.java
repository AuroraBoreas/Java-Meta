import my.pkg.Elephant;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Main {
	public static void main(String[] args) {
		Consumer<Integer> consumer = (e) -> {
			System.out.println(e);
		};
		consumer.accept(1);

		Supplier<String> supplier = () -> "hello";
		System.out.println(supplier.get());

		Function<Integer, String> f = (e) -> Objects.toString(e);
		System.out.println(f.apply(12));

		Predicate<Integer> g = e -> e % 2 == 0;
		System.out.println(g.test(4));

		Elephant elephant = new Elephant("goodies");
		elephant.makeNoise();
	}

}
