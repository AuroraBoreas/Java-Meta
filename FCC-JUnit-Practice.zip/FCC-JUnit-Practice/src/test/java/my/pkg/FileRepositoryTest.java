package my.pkg;

import com.google.common.jimfs.Configuration;
import com.google.common.jimfs.Jimfs;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.FileSystem;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

public class FileRepositoryTest {
	private static final FileSystem fs = Jimfs.newFileSystem(Configuration.windows());
	private final Path pathToStore = fs.getPath(".");
	private final FileRepository fr = new FileRepository();

	/* JUnit handles each test with separate environment, probably in all unittest framework universally ? */
	@BeforeEach
	void setUp() {
		fr.create(pathToStore, "newFile.txt");
		fr.create(pathToStore, "newFile1.bin");
		fr.create(pathToStore, "newFile2.bin");
		fr.create(pathToStore, "newFile1.png");
		fr.create(pathToStore, "newFile2.png");
		fr.create(pathToStore, "newFile1.csv");
		fr.create(pathToStore, "newFile2.csv");
		fr.create(pathToStore, "newFile3.csv");
		fr.create(pathToStore, "newFile1.txt");
		fr.create(pathToStore, "newFile2.txt");
		fr.create(pathToStore, "newFile3.txt");
		fr.create(pathToStore, "newFile4.txt");
	}

	@Test
	@DisplayName("CRUD : create file and path should work correctly")
	void createPathInWinOS() throws IOException {

		assertAll(
				() -> assertTrue(Files.exists(pathToStore.resolve("newFile.txt"))),
				() -> assertTrue(Files.exists(pathToStore.resolve("newFile1.bin"))),
				() -> assertTrue(Files.exists(pathToStore.resolve("newFile2.png"))),
				() -> assertTrue(Files.exists(pathToStore.resolve("newFile3.csv"))),
				() -> assertTrue(Files.exists(pathToStore.resolve("newFile4.txt")))
		);

		// EFMA
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(bos));
		try (Stream<Path> walk = Files.walk(pathToStore)) {
			walk.parallel()
					.filter(x -> x.toAbsolutePath().toString().endsWith(".png"))
					.forEachOrdered(System.out::println);
		}
		System.out.println("running..");
		String result = bos.toString();
		System.out.println(result);
		assertAll(
				// positive
				() -> assertTrue(result.contains("newFile1.png")),
				() -> assertTrue(result.contains("newFile2.png")),
				// nagte
				() -> assertFalse(result.contains("running..."))
		);
	}

	@Test
	@DisplayName("Files Walk should work correctly")
	void fileWalkInWinOS() throws IOException {
		long n;
		try (Stream<Path> walk = Files.walk(pathToStore)) {
			n = walk.parallel()
					.filter(x -> x.toAbsolutePath().toString().endsWith(".bin"))
					.count();
		}
		assertEquals(2, n);
	}

	@Test
	@DisplayName("methodShouldReturnCorrectAnswer")
	void methodShouldReturnCorrectAnswer() {
		assertEquals(1, 1);
	}

	@Test
	@DisplayName("hello world this is beautiful")
	void helloWorldThisIsBeautiful() {
		List<Integer> integers = List.of(1, 2, 3, 4, 5);
		List<Integer> result = integers.parallelStream()
				.filter(x -> (x & 1) == 1)
				.map(x -> x * 3)
				.toList();
		assertThat(result, hasItems(3, 9, 15));
	}

	@Test
	@DisplayName("Should Return Correct Sequential Result")
	void shouldReturnCorrectSequentialResult() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		List<Integer> seq = IntStream.rangeClosed(1, 7).boxed().toList();
		seq.stream().map(x -> x * (x * x - 1) / 3).forEachOrdered(System.out::println);
		String result = baos.toString();
		System.out.println(result);
		assertAll(
				() -> assertTrue(result.contains("0")),
				() -> assertTrue(result.contains("2")),
				() -> assertTrue(result.contains("8")),
				() -> assertTrue(result.contains("20")),
				() -> assertTrue(result.contains("40")),
				() -> assertTrue(result.contains("70")),
				() -> assertTrue(result.contains("112"))
		);
	}

	@Test
	@DisplayName("Test name")
	void testName() {
		fail("not implemented yet");
	}

	@Test
	@DisplayName("Duplicate Method Name Must Return False")
	void duplicateMethodNameMustReturnFalse() {
		fail("not implemented");
	}
}