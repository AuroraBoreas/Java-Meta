package my.pkg;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.*;

class ElephantTest {

	@Test
	@DisplayName("Elephant should make noise on friday")
	void makeNoise() {
		// given
		Elephant elephant = spy(new Elephant("foo"));
		// when
		elephant.perform("friday");
		// then
		verify(elephant).makeNoise();
	}

	@Test
	void elephantShouldNotMakeNoiseOnMonday() {
		// given
		Elephant elephant = spy(new Elephant("bar"));
		// when
		elephant.perform("monday");
		// then
		then(elephant).should(never()).makeNoise();
	}
}