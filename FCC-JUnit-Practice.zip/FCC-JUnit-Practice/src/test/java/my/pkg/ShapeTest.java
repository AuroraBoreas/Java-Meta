package my.pkg;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class ShapeTest {
	@ParameterizedTest(name = "{0}")
	@DisplayName("should Construct Shape Correctly")
	@ValueSource(ints = {3, 4, 5, 6, 8, 14})
	void shouldConstructShapeCorrectly(int expectedNumberOfSides) {
		Shape shape = new Shape(expectedNumberOfSides);
		Assertions.assertEquals(expectedNumberOfSides, shape.getNumberOfSides());
	}

	@ParameterizedTest(name = "{index} - {0}")
	@DisplayName("Should Fail To Construct Shape")
	@ValueSource(ints = {0, 1, 2, Integer.MAX_VALUE})
	void shouldFailToConstructShape(int sides) {
		Assertions.assertThrows(
				IllegalArgumentException.class,
				() -> {
					new Shape(sides);
				});
	}

	@Nested
	@DisplayName("When a shape has been created")
	class WhenShapeExists {
		private static final Shape shape = new Shape(4);

		@Nested
		@DisplayName("Should Allow")
		class ShouldAllow {
			@Test
			@DisplayName("seeing the number of sides")
			void seeingTheNumberOfSides() {
				Assertions.assertEquals(4, shape.getNumberOfSides());
			}

			@Test
			@DisplayName("seeing the description")
			void seeingTheDescription() {
				Assertions.assertEquals("Square", shape.description());
			}
		}

		@Nested
		@DisplayName("Should Not Allowed")
		class ShouldNotAllowed {
			@Test
			@DisplayName("be equal to another shape with the same number of sides")
			void beEqualToAnotherShapeWithTheSameNumberOfSides() {
				Assertions.assertNotEquals(new Shape(4), shape);
			}
		}
	}
}