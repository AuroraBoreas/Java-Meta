package my.pkg;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class EmployeeTest {
	private Employee employee;

	@BeforeEach
	void setUp() {
		employee = new Employee(1, "cyan", 1001);
		System.out.println("setUp");
	}

	@Test
	@DisplayName("toString() method should return correct results")
	void toStringShouldBeCorrect() {
		Assertions.assertEquals("Employee{id=1, name='cyan', employeeId=1001}", employee.toString());
	}

	@Test
	void constructCorrectId() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Employee employee1 = new Employee(-1, "cyan", 1001);
		});
	}

	@Test
	void constructCorrectName() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Employee employee1 = new Employee(1, "", 1001);
		});
	}

	@Test
	void constructCorrectEmployeeId() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Employee employee1 = new Employee(1, "cyan", 99);
		});
	}

	@Test
	@DisplayName("Test Employee creation on Developer Machine")
	void shouldTestEmployeeOnDEV() {
		System.out.println(System.getProperty("env"));
		Assumptions.assumeTrue("DEV".equals(System.getProperty("env")));
	}

	@Test
	@EnabledOnOs(value = OS.MAC, disabledReason = "Enabled only on MAC")
	void defaultConstructNotThrow() {
		Assertions.assertDoesNotThrow(() -> {
			Employee employee1 = new Employee();
		});
	}

	@Test
	@DisplayName("Supply Then Accept Async With Executor Should Return True")
	void supplyThenAcceptAsyncWithExecutor() {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(bos));

		ExecutorService service = Executors.newFixedThreadPool(4);
		CompletableFuture.supplyAsync(() -> "42", service)
				.thenApply(Integer::parseInt)
				.thenApply(x -> x * 2)
				.thenAccept(System.out::println);

		System.out.println("running...");
		String result = bos.toString();
		System.out.println(result);
		Assertions.assertTrue(result.contains("84"));
		Assertions.assertTrue(result.contains("running..."));
	}

	@Test
	@DisplayName("CompletableFuture allOf should return true")
	void CompletableFutureShouldReturnTrue() {
		class Demo {
			private int getNextInt() {
				try {
					Thread.sleep((long) (Math.random() * 100));
				} catch (InterruptedException e) {
					throw new RuntimeException(e);
				}
				return 42;
			}

			public CompletableFuture<Integer> getValue() {
				return CompletableFuture.supplyAsync(this::getNextInt);
			}
		}

		Demo demo = new Demo();
		CompletableFuture[] completableFutures = Stream.generate(demo::getValue)
				.limit(10)
				.toArray(CompletableFuture[]::new);
		CompletableFuture.allOf(completableFutures).join();
		Arrays.stream(completableFutures)
				.map(CompletableFuture::join)
				.forEach(System.out::println);
	}

	@Test
	void streamParallelShouldBeCorrect() {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(bos));
		DoubleStream.generate(Math::random)
				.limit(10)
				.map(x -> x * 4)
//				.sorted(Comparator.reverseOrder())
				.forEachOrdered(System.out::println);
		Stream.of(1, 2, 3, 4, 5, 6, 7, 9, 10)
				.toList().parallelStream()
				.filter(x -> x % 2 == 0)
//				.sorted()
				.map(x -> x * 2)
				.forEachOrdered(System.out::println);
		System.out.println("running...");
		String result = bos.toString();
		System.out.println(result);
//		Assertions.assertTrue(result.contains("84"));
		Assertions.assertTrue(result.contains("running..."));
		Assertions.assertTrue(result.contains("4"));
		Assertions.assertTrue(result.contains("8"));
		Assertions.assertTrue(result.contains("12"));
		Assertions.assertTrue(result.contains("20"));
	}

	@AfterEach
	void tearDown() {
		System.out.println("tearDown");
	}
}