package my.pkg;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class EmployeeTest {
    private Employee employee;

    @BeforeEach
    void setUp() {
        employee = new Employee(1, "cyan", 1001);
        System.out.println("setUp");
    }

    @Test
    @DisplayName("toString() method should return correct results")
    void toStringShouldBeCorrect() {
        Assertions.assertEquals("Employee{id=1, name='cyan', employeeId=1001}", employee.toString());
    }

    @Test
    void constructCorrectId() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Employee employee1 = new Employee(-1, "cyan", 1001);
        });
    }

    @Test
    void constructCorrectName() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Employee employee1 = new Employee(1, "", 1001);
        });
    }

    @Test
    void constructCorrectEmployeeId() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Employee employee1 = new Employee(1, "cyan", 99);
        });
    }

    @Test
    @DisplayName("Test Employee creation on Developer Machine")
    void shouldTestEmployeeOnDEV() {
        System.out.println(System.getProperty("env"));
        Assumptions.assumeTrue("DEV".equals(System.getProperty("env")));
    }

    @Test
    @EnabledOnOs(value = OS.MAC, disabledReason = "Enabled only on MAC")
    void defaultConstructNotThrow() {
        Assertions.assertDoesNotThrow(() -> {
            Employee employee1 = new Employee();
        });
    }

    @AfterEach
    void tearDown() {
        System.out.println("tearDown");
    }
}