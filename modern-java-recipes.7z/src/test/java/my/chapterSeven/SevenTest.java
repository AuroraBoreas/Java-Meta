package my.chapterSeven;

import org.junit.jupiter.api.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Comparator;
import java.util.Map;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class SevenTest {
	private Seven seven;
	@BeforeEach
	void setUp() {
		seven = new Seven();
	}

	@Test
	@DisplayName("findTenLongestWordsInWeb2 method should return correct results")
	void findTenLongestWordsInWeb2MethodShouldReturnCorrectResults() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		seven.findTenLongestWordsInWeb2("data/Word-lists-in-csv/Word lists in csv/Aword.csv");
		var result = baos.toString();
		System.out.println(result);
		Assertions.assertTrue(result.contains("argillo-areenaceous  (20)"));
	}

	@Test
	@DisplayName("mapStream should work correctly")
	void mapStreamShouldWorkCorrectly() {
		Map<String, Integer> map = Map.of(
				"hello", 1,
				"world", 2,
				"today", 3,
				"tomorrow", 4
		);
		map.forEach((k, v) -> System.out.println(k + " : " + v));
		map.entrySet().stream()
				.sorted(Map.Entry.comparingByKey(Comparator.reverseOrder()))
				.forEach(e -> System.out.println(e.getKey() + " : " + e.getValue()));
	}

	@Test
	@DisplayName("retrieveFilesAsStream should work properly")
	void retrieveFilesAsStreamShouldWorkProperly() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		seven.retrieveFilesAsStream(".");
		var result = baos.toString();
		System.out.println(result);
		Assertions.assertTrue(result.contains("D:\\pj_00_codelib\\2019_javapj\\modern-java-recipes\\.\\pom.xml"));
	}

	@Test
	@DisplayName("findNondirectoryFiles method should work correctly")
	void findNondirectoryFilesMethodShouldWorkCorrectly() {
		seven.findNondirectoryFiles(".");
	}


}