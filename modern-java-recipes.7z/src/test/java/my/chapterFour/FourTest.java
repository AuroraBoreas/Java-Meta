package my.chapterFour;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class FourTest {
	private Four four;

	@BeforeEach
	void setUp() {
	four = new Four();
	}

	@Test
	@DisplayName("oddLengthStringSet method should work as expected")
	void oddLengthStringSetMethodShouldWorkAsExpected() {
		var result = four.oddLengthStringSet("hello", "world", "abc", "xyz", "cyan");
		System.out.println(result);
	}
}