package my.chapterSix;

import org.junit.jupiter.api.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class SixTest {

	private Six six;

	@BeforeEach
	void setUp() {
		six = new Six();
	}

	@Test
	@DisplayName("returnAnOptional method should work correctly")
	void returnAnOptionalMethodShouldWorkCorrectly() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		six.returnAnOptional();
		var result = baos.toString();
		System.out.println(result);
		Assertions.assertAll(
				() -> Assertions.assertTrue(result.contains("Boss: Optional[Manager{name='Ms Cyan'}]"))
		);
	}


}