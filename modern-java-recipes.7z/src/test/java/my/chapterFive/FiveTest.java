package my.chapterFive;

import org.junit.jupiter.api.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsCollectionContaining.hasItems;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class FiveTest {

	private Five five;

	@BeforeEach
	void setUp() {
		five = new Five();
	}

	@Test
	@DisplayName("objectsDeepEquals method should return true")
	void objectsDeepEqualsMethodShouldReturnTrue() {
		Integer[] a = {1, 2, 3, 4};
		Integer[] b = a.clone();
		Assertions.assertAll(
				() -> Assertions.assertTrue(five.objectsDeepEquals(a, b)),
				() -> Assertions.assertFalse(five.objectsEquals(a, b)) // mem address equation of two arrays
		);
	}

	@Test
	@DisplayName("objectHash method should return correct result")
	void objectHashMethodShouldReturnCorrectResult() {
		int result = five.objectHash(314L);
		System.out.println(result);
	}

	@Test
	@DisplayName("objectToString method should return correct results")
	void objectToStringMethodShouldReturnCorrectResults() {
		var result = Stream.of(
				1, 2, 3, 3.14f, 2.7182818d, 5L, 'c', "hello", true
		).map(five::objectsToString).toList();
		assertThat(result, hasItems("1", "2", "3", "3.14", "2.7182818", "5", "c", "hello", "true"));
	}

	@Test
	@DisplayName("objectsNotNull method should return true")
	void objectsNotNullMethodShouldReturnTrue() {
		var result = five.objectsNotNull();
		Assertions.assertFalse(result);
	}

	@Test
	@DisplayName("generateStreamOfRandomNumbers method should work correctly")
	void generateStreamOfRandomNumbersMethodShouldWorkCorrectly() {
		five.generateStreamOfRandomNumbers();
	}

	@Test
	@DisplayName("fibonacciCalculationWithCache method should work correctly")
	void fibonacciCalculationWithCacheMethodShouldWorkCorrectly() {
		var result = five.fibonacci(3);
		Assertions.assertEquals(2, result);
	}

	// finite state machine
	@Test
	@DisplayName("countWords method should return correct results")
	void countWordsMethodShouldReturnCorrectResults() {
		String passage =  "NSA agent walks into a bar. Bartender says, " +
 "'Hey, I have a new joke for you.' Agent says, 'heard it'.";
		var result = five.countWords(passage, "NSA", "agent", "joke");
		Assertions.assertAll(
				() -> Assertions.assertEquals(1, result.get("NSA")),
				() -> Assertions.assertEquals(1, result.get("agent")),
				() -> Assertions.assertEquals(1, result.get("joke"))
		);
	}

	@Test
	@DisplayName("composeAndThen method should work correctly")
	void composeAndThenMethodShouldWorkCorrectly() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		five.composeAndThen(1);
		var result = baos.toString();
		System.out.println(result);
		Assertions.assertAll(
				() -> Assertions.assertTrue(result.contains("5")),
				() -> Assertions.assertTrue(result.contains("9"))
		);
	}

	@Test
	@DisplayName("parseStringThenAdd2 should work properly")
	void parseStringThenAdd2ShouldWorkProperly() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		five.parseStringThenAdd2("1");
		var result = baos.toString();
		System.out.println(result);
		Assertions.assertAll(
				() -> Assertions.assertTrue(result.contains("3"))
		);
	}

	@Test
	@DisplayName("composedConsumerForPrintAndThenLog method should work correctly")
	void composedConsumerForPrintAndThenLogMethodShouldWorkCorrectly() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		five.composedConsumerForPrintAndThenLog();
		var result = baos.toString();
		System.out.println(result);
		Assertions.assertAll(
				() -> Assertions.assertTrue(result.contains("this"))
		);
	}


}