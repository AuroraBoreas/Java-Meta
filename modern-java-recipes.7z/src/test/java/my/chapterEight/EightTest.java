package my.chapterEight;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class EightTest {

	private Eight eight;

	@BeforeEach
	void setUp() {
		eight = new Eight();
	}

	@Test
	@DisplayName("resultOfCallingTheNowMethod should work correctly")
	void resultOfCallingTheNowMethodShouldWorkCorrectly() {
		eight.resultOfCallingTheNowMethod();
	}

	@Test
	@DisplayName("methodForDateTimeClass")
	void methodForDateTimeClass() {
		eight.methodForDateTimeClass();
	}

	@Test
	@DisplayName("regionId/ZoneId should print out correct results")
	void regionIdZoneIdShouldPrintOutCorrectResults() {
		eight.regionId();
	}

	@Test
	@DisplayName("applyTimeZoneToLocalDateTime")
	void applyTimeZoneToLocalDateTime() {
		eight.applyTimeZoneToLocalDateTime();
	}

	@Test
	@DisplayName("someMethodsInMonthEnum should work correctly")
	void someMethodsInMonthEnumShouldWorkCorrectly() {
		eight.someMethodsInMonthEnum();
	}

	@Test
	@DisplayName("localDatePlus should work properly")
	void localDatePlusShouldWorkProperly() {
		eight.localDatePlus();
	}

	@Test
	@DisplayName("localTimePlus method should work properly")
	void localTimePlusMethodShouldWorkProperly() {
		eight.localTimePlus();
	}

	@Test
	@DisplayName("plusMinus method should work correctly")
	void plusMinusMethodShouldWorkCorrectly() {
		eight.plusMinus();
	}


}