package my.chapterNine;

import org.junit.jupiter.api.*;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Stream;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class NineTest {
	private Nine nine;

	@BeforeEach
	void setUp() {
		nine = new Nine();
	}

	// isParallel / sequential
	@Test
	@DisplayName("sequentialStreamOf")
	void sequentialStreamOf() {
		Assertions.assertFalse(
				Stream.of(1, 2, 3, 4, 5).isParallel()
		);
	}

	@Test
	@DisplayName("sequentialIterateStream")
	void sequentialIterateStream() {
		Assertions.assertFalse(
				// figr -> of, iterate, generate, range
				Stream.iterate(1, n -> n + 1).isParallel()
		);
	}

	@Test
	@DisplayName("sequentialGenerateStream")
	void sequentialGenerateStream() {
		Assertions.assertFalse(
				Stream.generate(Math::random).isParallel()
		);
	}

	@Test
	@DisplayName("sequentialCollectionStream")
	void sequentialCollectionStream() {
		Assertions.assertFalse(
				Arrays.stream(new int[]{3, 1, 2}).isParallel()
		);
	}

	@Test
	@DisplayName("parallelStreamMethodOnCollection")
	void parallelStreamMethodOnCollection() {
		Assertions.assertTrue(
				List.of(1, 2, 3).parallelStream().isParallel()
		);
	}

	@Test
	@DisplayName("parallelStreamThenSequential")
	void parallelStreamThenSequential() {
		Assertions.assertFalse(
				Arrays.asList(3, 1, 4)
						.parallelStream()
						.sequential()
						.isParallel()
		);
	}

	@Test
	@DisplayName("createYourOwnForkJoinPool")
	void createYourOwnForkJoinPool() {
		nine.createYourOwnForkJoinPool();
	}

	@Test
	@DisplayName("codepoints method should work correctly")
	void codepointsMethodShouldWorkCorrectly() {
		String s = "你好世界!";
		System.out.println("chars()");
		s.chars().forEach(System.out::println);
		System.out.println("codePoints()");
		s.codePoints().forEach(System.out::println);
	}

	@Test
	@DisplayName("completableFutureThing method should works correctly")
	void completableFutureThingMethodShouldWorksCorrectly() {
		nine.completableFutureThing();
	}

	@Test
	@DisplayName("completableFutureSupplyAsync method should work properly")
	void completableFutureSupplyAsyncMethodShouldWorkProperly() {
		nine.completableFutureSupplyAsync();
	}

	@Test
	@DisplayName("runCompletableFutureTasksWithSeparateThreadPool method should work as expected")
	void runCompletableFutureTasksWithSeparateThreadPoolMethodShouldWorkAsExpected() {
		nine.runCompletableFutureTasksWithSeparateThreadPool();
	}


	@Test
	@DisplayName("compose method should return correct results")
	void composeMethodShouldReturnCorrectResults() throws ExecutionException, InterruptedException {
		int x = 2, y = 3;
		CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> x)
				.thenCompose(n -> CompletableFuture.supplyAsync(() -> n + y));
		Assertions.assertEquals(5, future.get());
	}

	@Test
	@DisplayName("combine two futures")
	void combineTwoFutures() throws InterruptedException, ExecutionException {
		int x = 2, y = 3;
		CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> x)
				.thenCombine(
						CompletableFuture.supplyAsync(() -> y),
						(a, b) -> a + b
				);
		Assertions.assertEquals(5, future.get());
	}

	@Test
	@DisplayName("getIntegerCompletableFuture method should work correctly")
	void getIntegerCompletableFutureMethodShouldWorkCorrectly() throws ExecutionException, InterruptedException {
		String n = "abc";
		var result = nine.getIntegerCompletableFuture(n);
		Assertions.assertEquals(0, result.get());
		// negate
		n = "69";
		result = nine.getIntegerCompletableFuture(n);
		Assertions.assertEquals(69, result.get());
	}

	@Test
	@DisplayName("demonstrating immutability")
	void demonstratingImmutability() {
		List<Integer> list = List.of(1, 2, 3);
		Map<Integer, String> map = Map.of(1, "hello");
		Set<Integer> set = Set.of(1, 2, 3);

		Assertions.assertThrows(
				UnsupportedOperationException.class,
				() -> list.add(4)
		);
		Assertions.assertThrows(
				UnsupportedOperationException.class,
				() -> map.put(2, "world")
		);
		Assertions.assertThrows(
				UnsupportedOperationException.class,
				() -> set.remove(1)
		);
	}

	@Test
	@DisplayName("pecs method should work as expected")
	void pecsMethodShouldWorkAsExpected() {
		nine.pecs();
	}
}