package my.chapterThree;

import org.junit.jupiter.api.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Stream;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsCollectionContaining.hasItems;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ThreeTest {
	private Three three;

	@BeforeEach
	void setUp() {
		System.out.println("set up");
		three = new Three();
	}

	@Test
	@DisplayName("streamOf method should work correctly")
	void streamOfMethodShouldWorkCorrectly() {
		var result = three.streamOf("hello", "world", "cyan", "blue", "yellow");
		Assertions.assertEquals("hello,world,cyan,blue,yellow", result);
	}


	@Test
	@DisplayName("streamIterateBigDecimal should work correctly")
	void streamIterateBigDecimalShouldWorkCorrectly() {
		var result = three.streamIterateBigDecimal();
		assertThat(result, hasItems(BigDecimal.ZERO, BigDecimal.ONE, BigDecimal.valueOf(2)));
	}

	@Test
	@DisplayName("streamIterateLocalDate should work correctly")
	void streamIterateLocalDateShouldWorkCorrectly() {
		var result = three.streamIterateLocalDate();
		assertThat(
				result,
				hasItems(
						LocalDate.of(2023, 6, 14),
						LocalDate.of(2023, 6, 15),
						LocalDate.of(2023, 6, 16)
				)
		);
	}

	@Test
	@DisplayName("streamGenerateRandomNumber should work correctly")
	void streamGenerateRandomNumberShouldWorkCorrectly() {
		var result = three.streamGenerateRandomNumbers();
		Assertions.assertAll(
				() -> Assertions.assertEquals(3, result.size()),
				() -> assertTrue(result.get(0) < 1D),
				() -> assertTrue(result.get(0) >= 0D)
		);
	}

	@Test
	@DisplayName("intStreamRange should work correctly")
	void intStreamRangeShouldWorkCorrectly() {
		var result = three.intStreamRange();
		assertThat(result, hasItems(10, 11, 12));
	}

	@Test
	@DisplayName("intStreamRangeClosed should work correctly")
	void intStreamRangeClosedShouldWorkCorrectly() {
		var result = three.intStreamRangeClosed();
		assertThat(result, hasItems(10, 11, 12, 13));
	}

	@Test
	@DisplayName("mapToInteger should work correctly")
	void mapToIntegerShouldWorkCorrectly() {
		var result = three.mapToInteger();
		assertThat(result, hasItems(97, 98, 99, 100));
	}

	@Test
	@DisplayName("threeArgumentsCollect should work correctly")
	void threeArgumentsCollectShouldWorkCorrectly() {
		var result = three.threeArgumentsCollect();
		assertThat(result, hasItems(3, 1, 4, 1, 5, 9));
	}

	@Test
	@DisplayName("streamReductionCount should work correctly")
	void streamReductionCountShouldWorkCorrectly() {
		var result = three.streamReductionCount("hello", "world", "abc", "xyz", "cyan");
		Assertions.assertEquals(5, result);
	}

	@Test
	@DisplayName("streamReductionSum should work correctly")
	void streamReductionSumShouldWorkCorrectly() {
		var result = three.streamReductionSum("hello", "world");
		Assertions.assertEquals(10, result);
	}

	@Test
	@DisplayName("streamReductionAvg should work correctly")
	void streamReductionAvgShouldWorkCorrectly() {
		var result = three.streamReductionAvg("hello", "world");
		Assertions.assertEquals(OptionalDouble.of(5D), result);
	}

	@Test
	@DisplayName("streamReductionMax should work correctly")
	void streamReductionMaxShouldWorkCorrectly() {
		var result = three.streamReductionMax("hello", "cyan");
		Assertions.assertEquals(OptionalInt.of(5), result);
	}

	@Test
	@DisplayName("streamReductionMin should work correctly")
	void streamReductionMinShouldWorkCorrectly() {
		var result = three.streamReductionMin("hello", "cyan");
		Assertions.assertEquals(OptionalInt.of(4), result);
	}

	@Test
	@DisplayName("streamReductionReduce should work correctly")
	void streamReductionReduceShouldWorkCorrectly() {
		var result = three.streamReductionReduce();
		Assertions.assertEquals(55, result);
	}


	@Test
	@DisplayName("intStreamReduceIntBinaryOperator should work correctly")
	void intStreamReduceIntBinaryOperatorShouldWorkCorrectly() {
		var result = three.intStreamReduceIntBinaryOperator();
		Assertions.assertEquals(64, result);
	}

	@Test
	@DisplayName("intStreamReduceIntBinaryOperatorMax should work properly")
	void intStreamReduceIntBinaryOperatorMaxShouldWorkProperly() {
		var result = three.intStreamReduceIntBinaryOperatorMax();
		Assertions.assertEquals(10, result);
	}

	@Test
	@DisplayName("reduceArrayToString work correctly")
	void reduceArrayToStringWorkCorrectly() {
		var result = three.reduceArrayToString("hello", "world");
		Assertions.assertEquals(" helloworld", result);
	}

	@Test
	@DisplayName("reduceIntArrayToString should work correctly")
	void reduceIntArrayToStringShouldWorkCorrectly() {
		var result = three.reduceIntArrayToString(1, 2, 3);
		Assertions.assertEquals("123", result);
	}

	@Test
	@DisplayName("reduceIntArrayToStringEfficient should work correctly")
	void reduceIntArrayToStringEfficientShouldWorkCorrectly() {
		var result = three.reduceIntArrayToStringEfficient(1, 2, 3);
		Assertions.assertEquals("123", result);
	}

	@Test
	@DisplayName("reduceIntArrayToStringSimplest should work properly")
	void reduceIntArrayToStringSimplestShouldWorkProperly() {
		var result = three.reduceIntArrayToStringSimplest(1, 2, 3);
		Assertions.assertEquals("123", result);
	}

	@Test
	@DisplayName("general Form of reduce should work correctly")
	void generalFormOfReduceShouldWorkCorrectly() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		three.mostGeneralFormOfReduce();
		String result = baos.toString();
		System.out.println(result);
		Assertions.assertAll(
				() -> assertTrue(result.contains("1 Book{id=1, title=hello world}")),
				() -> assertTrue(result.contains("4 Book{id=4, title=math language}")),
				() -> assertTrue(result.contains("5 Book{id=5, title=programming language}"))
		);
	}

	@Test
	@DisplayName("check sorted using reduce pair should work correctly")
	void checkSortedUsingReducePairShouldWorkCorrectly() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		three.checkSortingUsingReduce();
		String result = baos.toString();
		System.out.println(result);
		assertTrue(result.contains("[a, is, of, this, list, strings]"));
	}

	@Test
	@DisplayName("sumDoubleDivisibleBy3 should work properly")
	void sumDoubleDivisibleBy3ShouldWorkProperly() {
		Assertions.assertEquals(6, three.sumDoublesDivisibleBy3(1, 3));
	}

	@Test
	@DisplayName("palindrome method should work correctly")
	void palindromeMethodShouldWorkCorrectly() {
		Assertions.assertAll(
				() -> Assertions.assertFalse(three.convertStringToStreamAndBack("hello")),
				() -> assertTrue(three.convertStringToStreamAndBack("ollo")),
				() -> assertTrue(three.convertStringToStreamAndBack("helleh")),
				() -> Assertions.assertFalse(three.convertStringToStreamAndBack("helloh"))
		);
	}

	@Test
	@DisplayName("is palindrome method work properly")
	void isPalindromeMethodWorkProperly() {
		assertTrue(Stream.of(
				"Madam, in Eden, I'm Adam",
				"Go hang a salami; I'm a lasagna hog",
				"Flee to me, remote elf!",
				"A Santa pets rats as Pat taps a star step at NASA"

		).allMatch(three::isPalindrome));

		Assertions.assertAll(
				() -> assertTrue(three.isPalindrome("Go hang a salami; I'm a lasagna hog")),
				() -> Assertions.assertFalse(three.isPalindrome("hello")),
				() -> Assertions.assertFalse(three.isPalindrome("world"))
		);
	}

	@Test
	@DisplayName("count String partitioned by length method should work correctly")
	void countStringPartitionedByLengthMethodShouldWorkCorrectly() {
		Map<Boolean, Long> map = three.countStringPartitionedByLength(List.of("hello", "world", "cyan", "red", "blue", "green"));
		Assertions.assertEquals(2, map.get(true));
		Assertions.assertEquals(4, map.get(false));
	}

	@Test
	@DisplayName("collect with sac of team method should work correctly")
	void collectWithSacOfTeamMethodShouldWorkCorrectly() {
		var teamStats = three.collectWithSACOfTeams(
				List.of(
						new Team(1, "Los Angeles Dodgers", 245_269_535.00D),
						new Team(2, "Boston Red Sox", 202_135_939.00D),
						new Team(3, "New York Yankees", 202_095_552.00D),
						new Team(28, "San Diego Padres", 73_754_027.00D),
						new Team(29, "Tampa Bay Rays", 73_102_766.00D),
						new Team(30, "Milwaukee Brewers", 62_094_433.00D)
				)
		);
		Assertions.assertAll(
				() -> Assertions.assertEquals(858_452_252.00D, teamStats.getSum())
		);
	}

	@Test
	@DisplayName("collectorSummarizingDouble method should work properly")
	void collectorSummarizingDoubleMethodShouldWorkProperly() {
		var teamStats = three.collectorSummarizing(
				List.of(
						new Team(1, "Los Angeles Dodgers", 245_269_535.00D),
						new Team(2, "Boston Red Sox", 202_135_939.00D),
						new Team(3, "New York Yankees", 202_095_552.00D),
						new Team(28, "San Diego Padres", 73_754_027.00D),
						new Team(29, "Tampa Bay Rays", 73_102_766.00D),
						new Team(30, "Milwaukee Brewers", 62_094_433.00D)
				)
		);
		Assertions.assertEquals(62_094_433.00D, teamStats.getMin());
	}

	@Test
	@DisplayName("find first method should work correctly")
	void findFirstMethodShouldWorkCorrectly() {
		var result = three.findFirst(List.of(
				3, 2, 1, 2, 4, 5, 6, 9
		));
		assertFalse(result.isEmpty());
		assertEquals(2, result.get());

		result = three.findFirst(List.of(
				3, 1, 3, 1, 5, 3, 5, 3
		));
		assertTrue(result.isEmpty());
	}

	@Test
	@DisplayName("firstEven method should work correctly")
	void firstEvenMethodShouldWorkCorrectly() {
		for (int i = 0; i < 10; i++) {
			var result = three.firstEven(List.of(
					3, 4, 1, 2, 6, 7, 8, 9
			));
			assertFalse(result.isEmpty());
			assertEquals(4, result.get()); // encounter order (sequential collections: list, array) -> HST
		}
	}

	@Test
	@DisplayName("findAny in parallel after a random delay should work correctly")
	void findAnyInParallelAfterARandomDelayShouldWorkCorrectly() {
		// findFirst and findAny are both short-circuit, terminal operations;
		var result = three.findAnyInParallelAfterARandomDelay(
				List.of(3, 1, 4, 1, 5, 9, 2, 6, 5)
		);
		assertFalse(result.isEmpty());
		assertNotEquals(Optional.empty(), result.get());
	}

	@Test
	@DisplayName("isPrime method should work correctly")
	void isPrimeMethodShouldWorkCorrectly() {
		assertTrue(Stream.of(2, 3, 4, 5, 6, 7).anyMatch(three::isPrime));
		assertFalse(Stream.of(2, 3, 4, 5, 6, 7).allMatch(three::isPrime));
		assertTrue(Stream.of(4, 6, 8).noneMatch(three::isPrime));
	}

	@Test
	@DisplayName("concatTwoStreams method should work correctly")
	void concatStreamMethodShouldWorkCorrectly() {
		var result = three.concatTwoStreams();
		assertEquals(result, Arrays.asList("a", "b", "c", "x", "y", "z"));
	}

	@Test
	@DisplayName("concatThreeStreams method should work correctly")
	void concatThreeStreamMethodShouldWorkCorrectly() {
		List<String> list = three.concatThreeStreams();
		assertEquals(list, Arrays.asList("a", "b", "c", "x", "y", "z", "alpha", "beta", "gamma"));
	}

	@Test
	@DisplayName("concatMoreStream method should work correctly")
	void concatMoreStreamMethodShouldWorkCorrectly() {
		var result = three.concatMoreStreams();
		assertEquals(result, Arrays.asList("a", "b", "c", "x", "y", "z", "alpha", "beta", "gamma"));
	}

	@Test
	@DisplayName("combineStreamsNaturalSolution method should work correctly")
	void combineStreamsNaturalSolutionMethodShouldWorkCorrectly() {
		assertFalse(three.combineStreamsNaturalSolution());
	}

	@Test
	@DisplayName("quirksCombineParallel method should work properly")
	void quirksCombineParallelMethodShouldWorkProperly() {
		assertTrue(three.quirksCombineParallel());
	}

	@AfterEach
	void tearDown() {
		System.out.println("tear down");
	}
}