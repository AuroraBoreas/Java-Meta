package my.chapterOne;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsCollectionContaining.hasItems;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
public class MightyTest {
	static Stream<List<Integer>> argsProviderFactory() {
		return Stream.of(List.of(-1, 0, 2, 3, 4), List.of(3, 1, 2, 4));
	}

	@Test
	@DisplayName("built-in interface has default methods")
	void builtInInterfaceHasDefaultMethods() {
		List<Integer> numbers = Arrays.asList(0, 3, 1, 4, 1, 5, 9, -1);
		boolean removed = numbers.removeIf(n -> n < 2);
		assertThat(numbers, hasItems(3, 4, 5, 9));
		Assertions.assertAll(
				() -> Assertions.assertFalse(numbers.contains(1)),
				() -> Assertions.assertFalse(numbers.contains(0)),
				() -> Assertions.assertFalse(numbers.contains(-1)),
				() -> Assertions.assertTrue(removed)
		);
	}

	@ParameterizedTest
	@MethodSource("argsProviderFactory")
	@DisplayName("parameterized test should pass")
	void parameterizedTestShouldPass(List<Integer> list) {
		Assertions.assertTrue(list.contains(2));
		Assertions.assertTrue(list.contains(3));
		Assertions.assertTrue(list.contains(4));
	}
}
