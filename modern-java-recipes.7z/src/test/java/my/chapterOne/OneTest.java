package my.chapterOne;

import org.junit.jupiter.api.*;
import org.mockito.Mockito;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsCollectionContaining.hasItems;
import static org.mockito.BDDMockito.then;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class OneTest {
	@Nested
	@DisplayName("should work correctly")
	class shouldWorkCorrectly {
		@Test
		@DisplayName("should not throw")
		void shouldNotThrow() {
			One one = new One();
			Assertions.assertDoesNotThrow(one::basic);
		}

		@Test
		@DisplayName("should perform correctly")
		void shouldPerformCorrectly() {
			// given
			One one = Mockito.spy(new One());
			// when
			one.basic();
			// then
			then(one).should().basic();
		}

		@Test
		@DisplayName("should sort Cyan list correctly")
		void shouldSortCyanListCorrectly() {
			One one = new One();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			System.setOut(new PrintStream(baos));
			one.fundamental();
			String result = baos.toString();
			System.out.println(result);
			Assertions.assertAll(
					() -> Assertions.assertTrue(result.contains("1001")),
					() -> Assertions.assertTrue(result.contains("1002")),
					() -> Assertions.assertTrue(result.contains("1003")),
					() -> Assertions.assertTrue(result.contains("Cyan")),
					() -> Assertions.assertTrue(result.contains("Yellow")),
					() -> Assertions.assertTrue(result.contains("Magenta")),
					() -> Assertions.assertTrue(result.contains("Blue"))
			);
		}

		@Test
		@DisplayName("lambda should work correctly")
		void lambdaShouldWorkCorrectly() {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			System.setOut(new PrintStream(baos));
			One one = new One();
			one.lambda();
			String result = baos.toString();
			System.out.println(result);
			Assertions.assertAll(
					() -> Assertions.assertTrue(result.contains("world")),
					() -> Assertions.assertTrue(result.contains("Consumer"))
			);
		}

		@Test
		@DisplayName("my consumer should return correct string concatenation")
		void myConsumerShouldReturnCorrectStringConcatenation() {
			List<List<String>> list = new ArrayList<>(List.of(
					List.of("hello1", "world1"),
					List.of("hello2", "world2"),
					List.of("hello3", "world3"),
					List.of("hello4", "world4"),
					List.of("hello5", "world5")
			));
			One one = new One();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			System.setOut(new PrintStream(baos));
			Consumer<String> consumer = System.out::println;
			consumer.accept("XYZ?");
			list.forEach(one.myConsumer());
			String result = baos.toString();
			System.out.println(result);
			Assertions.assertAll(
					() -> Assertions.assertFalse(result.contains("hello1world1")), // negate
					() -> Assertions.assertTrue(result.contains("HELLO2WORLD2")),  // positive
					() -> Assertions.assertFalse(result.contains("hello3world3")), // negate
					() -> Assertions.assertFalse(result.contains("hello4world4")), // negate
					() -> Assertions.assertFalse(result.contains("hello5world5")), // negate
					() -> Assertions.assertTrue(result.contains("XYZ?"))           // positive
			);
		}

		@Test
		@DisplayName("stream printer should work correctly")
		void streamPrinterShouldWorkCorrectly() {
			One one = new One();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			System.setOut(new PrintStream(baos));
			one.streamPrinter();
			String result = baos.toString();
			System.out.println(result);
			Assertions.assertAll(
					() -> Assertions.assertTrue(result.contains("1")),  // positive
					() -> Assertions.assertTrue(result.contains("2")),  // positive
					() -> Assertions.assertTrue(result.contains("3")),  // positive
					() -> Assertions.assertTrue(result.contains("4")),  // positive
					() -> Assertions.assertTrue(result.contains("5")),  // positive
					() -> Assertions.assertFalse(result.contains("0")), // negate
					() -> Assertions.assertFalse(result.contains("7"))  // negate
			);
		}

		@Test
		@DisplayName("stream generator should work correctly")
		void streamGeneratorShouldWorkCorrectly() {
			One one = new One();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			System.setOut(new PrintStream(baos));
			one.streamGenerator();
			var result = baos.toString();
			System.out.println(result);
			Assumptions.assumeTrue(result.contains("0.1"));  // positive
			Assumptions.assumeTrue(result.contains("0.2"));  // positive
			Assumptions.assumeTrue(result.contains("0.3"));  // positive
			Assumptions.assumeFalse(result.contains("-10")); // negate
			Assumptions.assumeFalse(result.contains("10"));  // negate
		}

		@Test
		@DisplayName("multiple-argument instance method should work correctly")
		void multipleArgumentInstanceMethodShouldWorkCorrectly() {
			One one = new One();
			List<String> result = one.multiArgumentInstanceMethod();
			assertThat(result, hasItems("this", "is", "list", "of", "string"));
		}

		@Test
		@DisplayName("use string instance method should return correct result")
		void useStringInstanceMethodShouldReturnCorrectResult() {
			One one = new One();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			System.setOut(new PrintStream(baos));
			one.useStringMethodReference();
			String result = baos.toString();
			System.out.println(result);
			Assertions.assertAll(
					() -> Assertions.assertTrue(result.contains("4")),
					() -> Assertions.assertTrue(result.contains("2")),
					() -> Assertions.assertTrue(result.contains("6")),
					() -> Assertions.assertFalse(result.contains("5")),
					() -> Assertions.assertFalse(result.contains("-1")),
					() -> Assertions.assertFalse(result.contains("10"))
			);
		}

		@Test
		@DisplayName("constructor method reference should work correctly")
		void constructorMethodReferenceShouldWorkCorrectly() {
			One one = new One();
			var people = one.constructorReference();
			var result = people.stream().map(Person::toString).toList();
			assertThat(result, hasItems("Cyan       18   unknown"));
		}

		@Test
		@DisplayName("custom class instance method should work correctly")
		void customClassInstanceMethodShouldWorkCorrectly() {
			One one = new One();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			System.setOut(new PrintStream(baos));
			one.customClassInstanceMethod();
			String result = baos.toString();
			System.out.println(result);
			Assertions.assertAll(
					() -> Assertions.assertTrue(result.contains("Cyan")),
					() -> Assertions.assertTrue(result.contains("Lyan")),
					() -> Assertions.assertTrue(result.contains("Hello")),
					() -> Assertions.assertFalse(result.contains("world"))
			);
		}

		@Test
		@DisplayName("copy constructor should work properly")
		void copyConstructorShouldWorkProperly() {
			Person before = new Person("Cyan", 38, "female");
			List<Person> people = Stream.of(before).map(Person::new).toList();
			Person after = people.get(0);
			Assertions.assertEquals(before, after);
			before.setName("Lyan");
			Assertions.assertNotEquals("Lyan", after.getName());
		}

		@Test
		@DisplayName("varargs constructor should work correctly")
		void varargsConstructorShouldWorkCorrectly() {
			Person before = new Person("hello", "world", "Cyan", "Magenta", "Peach");
			List<Person> people = Stream.of(before).map(Person::new).toList();
			Person after = people.get(0);
			Assertions.assertEquals(before.getName(), after.getName());
		}

		@Test
		@DisplayName("constructor with Arrays")
		void constructorWithArrays() {
			List<String> names = List.of("hello", "world", "Cyan", "Magenta", "Peach");
			Person[] people = names.stream().map(Person::new).toArray(Person[]::new);
			Person p1 = people[2];
			Assertions.assertEquals("Cyan", p1.getName());
		}

	}
}