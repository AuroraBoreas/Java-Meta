package my.chapterOne;

import com.google.common.jimfs.Configuration;
import com.google.common.jimfs.Jimfs;
import org.junit.jupiter.api.*;

import java.util.Comparator;

import java.nio.file.FileSystem;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;


 @TestInstance(TestInstance.Lifecycle.PER_CLASS)
class FileRepositoryTest {
	private static final FileSystem fs = Jimfs.newFileSystem(Configuration.unix());
	private static final FileRepository fr = new FileRepository();

	private static final Path pathToStore = fs.getPath("");
	private static final List<String> bonds = Arrays.asList("Connery", "Lazenby", "Moore", "Dalton", "Brosnan", "Craig");

	@BeforeEach
	void setUp() {
		List.of(
				"hello.txt",
				"world.bin",
				"cyan.csv",
				"yellow.xlsx",
				"book"
		).forEach(x -> fr.create(pathToStore, x));
	}

	@Test
	@DisplayName("should create a file on a given file system")
	void shouldCreateAFileOnAGivenFileSystem() {
		Assertions.assertTrue(Files.exists(pathToStore.resolve("hello.txt")));
	}

	@Test
	@DisplayName("sorting strings should return correct result")
	void sortingStringsShouldReturnCorrectResult() {
		List<String> result = bonds.stream().sorted(Comparator.naturalOrder()).toList();
		Assertions.assertEquals("Connery", result.get(1));
	}

	 @Test
	 @DisplayName("sorting with reversed order should return correct result")
	 void sortingWithReversedOrderShouldReturnCorrectResult() {
		List<String> result = bonds.stream().sorted(Comparator.reverseOrder()).toList();
		Assertions.assertEquals("Moore", result.get(0));
	 }

	 @Test
	 @DisplayName("sorting with instance method reference should work correctly")
	 void sortingWithInstanceMethodReferenceShouldWorkCorrectly() {
		List<String> result = bonds.stream().sorted(Comparator.comparing(String::length)).toList();
		Assertions.assertEquals("Moore", result.get(0));
	 }

	 @Test
	 @DisplayName("sorting with string length then natural order should work correctly")
	 void sortingWithStringLengthThenNaturalOrderShouldWorkCorrectly() {
		 List<String> result = bonds.stream()
				 .sorted(Comparator.comparing(String::length).thenComparing(Comparator.naturalOrder()))
				 .toList();
		 Assertions.assertEquals("Craig", result.get(0));
	 }
}