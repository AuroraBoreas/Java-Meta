package my.chapterTwo;

import org.junit.jupiter.api.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsCollectionContaining.hasItems;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class TwoTest {
	private static Two two;

	@BeforeEach
	void setUp() {
		two = new Two();
	}

	@Test
	@DisplayName("java util function consumer should work correctly")
	void javaUtilFunctionConsumerShouldWorkCorrectly() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		List.of("this", "is", "a", "list", "of", "string", "consumer").forEach(two.getConsumer());
		String result = baos.toString();
		System.out.println(result);
		Assertions.assertAll(
				() -> Assertions.assertFalse(result.contains("this")),
				() -> Assertions.assertTrue(result.contains("consumer"))
		);
	}

	@Test
	@DisplayName("find first method should work correctly")
	void findFirstMethodShouldWorkCorrectly() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));

		// Optional.orElse()
		System.out.println(two.findFirst().orElse("None"));
		String result = baos.toString();
		System.out.println(result);
		Assertions.assertAll(
				() -> Assertions.assertTrue(result.contains("None"))
		);

		// String.join or Stream().collect(Collectors.joining(__deli__))
		System.out.println(two.findFirst().orElse(
						String.format(
								"No result found in %s%n",
								String.join(", ", Two.names)
						)
				)
		);
		String result2 = baos.toString();
		System.out.println(result2);
		Assertions.assertAll(
				() -> Assertions.assertTrue(result2.contains("Mal"))
		);

		// Optional.orElseGet()
		System.out.println(
				two.findFirst().orElseGet(
						() -> String.format(
								"No result found in %s%n", String.join(", ", Two.names)
						)
				)
		);

		String result3 = baos.toString();
		System.out.println(result3);
		Assertions.assertAll(
				() -> Assertions.assertTrue(result3.contains("Mal, Wash, Kaylee"))
		);
	}

	@Test
	@DisplayName("get names of length method should work correctly")
	void getNamesOfLengthMethodShouldWorkCorrectly() {
		String result = two.getNamesOfLength(3, "hello", "world", "xyz", "abc", "professional", "cyan");
		Assertions.assertAll(
				() -> Assertions.assertEquals(8, result.length()),
				() -> Assertions.assertTrue(result.contains("xyz")),
				() -> Assertions.assertTrue(result.contains("abc")),
				() -> Assertions.assertFalse(result.contains("hello"))
		);
	}

	@Test
	@DisplayName("flatmap method should work correctly")
	void flatmapMethodShouldWorkCorrectly() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		var data = List.of(
				List.of("hello", "world"),
				List.of("abc", "xyz", "cyan", "blue", "red", "green", "magenta")
		);
		two.flatMe(data);
		String result = baos.toString();
		System.out.println(result);
		Assertions.assertAll(
				() -> Assertions.assertTrue(result.contains("3=[abc, xyz, red]")),
				() -> Assertions.assertTrue(result.contains("5=[hello, world, green]"))
		);
	}

	@Test
	@DisplayName("allMatch method should work correctly")
	void allMatchMethodShouldWorkCorrectly() {
		var data = List.of("hello", "world", "Cyan", "abc", "xyz", "hibernate", "Hilarious");
		var result = two.allMatch(data);
		Assertions.assertFalse(result);

		result = two.anyMatch(data);
		Assertions.assertTrue(result);

		result = two.noneMatch(data);
		Assertions.assertFalse(result);
	}

	@Test
	@DisplayName("utilFunction method should work correctly")
	void utilFunctionMethodShouldWorkCorrectly() {
		var data = List.of("hello", "world", "Cyan", "abc", "xyz", "hibernate", "Hilarious");
		var result = two.utilFunction(data);
		assertThat(result, hasItems(5, 5, 4, 3, 3, 9, 9));
	}
}