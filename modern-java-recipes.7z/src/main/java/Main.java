import my.chapterSeven.Seven;

public class Main {
	public static void main(String[] args) {
		Seven seven = new Seven();
		seven.findTenLongestWordsInWeb2("data/Word-lists-in-csv/Word lists in csv/Aword.csv");
	}
}
