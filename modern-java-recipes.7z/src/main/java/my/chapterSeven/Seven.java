package my.chapterSeven;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.stream.Stream;

public class Seven {
	// NIO (nonblocking)
	// lines -> read the content of a single file as a stream
	// list  -> process all files in a given directory
	// walk  -> recursively walk through a root directory
	// find  -> find files in a file tree that satisfy give properties
	public void findTenLongestWordsInWeb2(String file) {
		try (Stream<String> lines = Files.lines(Paths.get(file))) {
			lines.filter(s -> s.length() > 10)
					.sorted(Comparator.comparingInt(String::length).reversed())
					.limit(10)
					.forEach(x -> System.out.printf("%s (%d)%n", x, x.length()));
		} catch (IOException ignore) {
		}
	}
	
	public void retrieveFilesAsStream(String directory) {
		try (Stream<Path> list = Files.list(Paths.get(directory))){
			list.map(Path::toAbsolutePath)
					.forEach(System.out::println);
		} catch(IOException ignore) {
		}
	}
	
	public void findNondirectoryFiles(String directory) {
		try (Stream<Path> find = Files.find(
				Paths.get(directory),
				Integer.MAX_VALUE,
				(path, attr) -> !attr.isDirectory() && path.toString().contains("pom")
		)) {
			find.forEach(System.out::println);
		} catch(IOException ignore) {
		}
	}
	
}
