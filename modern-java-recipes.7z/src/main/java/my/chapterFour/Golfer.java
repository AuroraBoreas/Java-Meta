package my.chapterFour;

public class Golfer {
	private String first;
	private String last;
	private int score;

	public Golfer(String first, String last, int score) {
		this.first = first;
		this.last = last;
		this.score = score;
	}

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getLast() {
		return last;
	}

	public void setLast(String last) {
		this.last = last;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getFullName() {
	    return first + " " + last;
	}


	@Override
	public String toString() {
		return "Golfer{" +
				"first='" + first + '\'' +
				", last='" + last + '\'' +
				", score=" + score +
				'}';
	}
}
