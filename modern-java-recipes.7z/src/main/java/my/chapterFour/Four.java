package my.chapterFour;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/* P107/302, Comparators and Collectors */
public class Four {
	private final List<String> list = Arrays.asList("this", "is", "a", "list", "of", "strings");
	List<Golfer> golfers = Arrays.asList(
			new Golfer("Jack", "Nicklaus", 68),
			new Golfer("Tiger", "Woods", 70),
			new Golfer("Tom", "Watson", 70),
			new Golfer("Ty", "Webb", 68),
			new Golfer("Bubba", "Watson", 70)
	);

	public List<String> defaultSort() {
		Collections.sort(list);
		return list;
	}

	public List<String> defaultSortUsingStream() {
		return list.stream().sorted().collect(Collectors.toList());
	}

	public List<String> lengthSortUsingSorted() {
		return list.stream()
				.sorted((s1, s2) -> s1.length() - s2.length())
				.toList();
	}

	public List<String> lengthSortUsingComparator() {
		return list.stream()
				.sorted(Comparator.comparing(String::length))
				.toList();
	}

	public List<String> lengthSortThenAlphabeticSort() {
		return list.stream()
				.sorted(Comparator.comparing(String::length).
						thenComparing(Comparator.naturalOrder()))
				.toList();
	}

	public List<Golfer> sortByScoreThenLastThenFirst() {
		return golfers.stream()
				.sorted(Comparator.comparing(Golfer::getScore)
						.thenComparing(Golfer::getLast)
						.thenComparing(Golfer::getFirst))
				.toList();
	}

	public List<String> collectorsToList() {
		return Stream.of("Mr. Furious", "The Blue Raja", "The Shoveler",
						"The Bowler", "Invisible Boy", "The Spleen", "The Sphinx")
				.collect(Collectors.toList());
	}

	public Set<String> collectorsToSet() {
		return Stream.of("Casanova Frankenstein", "The Disco Boys",
						"The Not-So-Goodie Mob", "The Suits", "The Suzies",
						"The Furriers", "The Furriers")
				.collect(Collectors.toSet());
	}

	public List<String> collectorsToLinkedList() {
		return Stream.of("Hank Azaria", "Janeane Garofalo", "William H. Macy",
						"Paul Reubens", "Ben Stiller", "Kel Mitchell", "Wes Studi")
				.collect(Collectors.toCollection(LinkedList::new));
	}

	public String[] collectorsToArray() {
		return Stream.of("The Waffler", "Reverse Psychologist", "PMS Avenger")
				.toArray(String[]::new);
	}

	public Map<String, Golfer> collectorsToMap() {
		return golfers.stream()
				// .collect(Collectors.toMap(Golfer::getFullName, Function.identity()))
				.collect(Collectors.toMap(Golfer::getFullName, g -> g));
	}

	public void readDictionaryToMap(Path dictionary) {
		try (Stream<String> lines = Files.lines(dictionary)) {
			lines.filter(s -> s.length() > 20)
					.collect(Collectors.groupingBy(String::length, Collectors.counting()))
					.forEach((len, num) -> System.out.printf("%d : %d%n", len, num));
		} catch (IOException ignore) {
		}
	}

	public void sortMapByKey(Path directory) {
		try (Stream<String> lines = Files.lines(directory)) {
			Map<Integer, Long> map = lines.filter(s -> s.length() > 20)
					.collect(Collectors.groupingBy(String::length, Collectors.counting()));
			map.entrySet().stream()
					.sorted(Map.Entry.comparingByKey(Comparator.reverseOrder()))
					.forEach(e -> System.out.printf("%d : %d%n", e.getKey(), e.getValue()));
		} catch (IOException ignore) {
		}
	}

	public void partitioningAndGroup() {
		list.stream()
				.collect(Collectors.partitioningBy(x -> x.length() % 2 == 0))
				.forEach((k, v) -> System.out.printf("%s : %s%n", k, v));
	}

	public void groupingByLength() {
		list.stream()
				.collect(Collectors.groupingBy(String::length))
				.forEach((k, v) -> System.out.printf("%d : %s%n", k, v));
	}

	public Optional<Golfer> usingBinaryOperatorMaxBy() {
		return golfers.stream()
				.reduce(BinaryOperator.maxBy(Comparator.comparingInt(Golfer::getScore)));
	}

	public Optional<Golfer> usingStreamMax() {
		return golfers.stream()
				.max(Comparator.comparingInt(Golfer::getScore));
	}

	public void findHighestScore() {
		OptionalInt score = golfers.stream().mapToInt(Golfer::getScore).max();
		System.out.println(score);
	}

	public void usingCollectorsMaxByAsDownstreamCollector() {
		var mini = golfers.stream().collect(
				Collectors.groupingBy(
						Golfer::getFullName,
						Collectors.minBy(Comparator.comparingInt(Golfer::getScore))
				)
		);
		mini.forEach((k, v) -> System.out.printf("%s : %s%n", k, v.orElse(new Golfer("hello", "world", 32))));
	}

	public Map<String, Integer> createImmutableMap() {
		return Collections.unmodifiableMap(
				new HashMap<>() {{
					put("have", 1);
					put("the", 2);
					put("high", 3);
					put("ground", 4);
				}}
		);
	}
	
	public SortedSet<String> oddLengthStringSet(String... strings) {
		Collector<String, ?, SortedSet<String>> intoSet = Collector.of(
				TreeSet<String>::new,
				SortedSet::add,
				(left, right) -> {
					left.addAll(right);
					return left;
				},
				Collections::unmodifiableSortedSet
		);
		return Stream.of(strings)
				.filter(s -> s.length() % 2 == 1)
				.collect(intoSet);
	}
	

	public void howTheCollectorMethodsAreUsed() {
		/*
		 * R container = collector.supplier.get();
		 * for(T t : data) {
		 *   collector.accumulator().accept(container, r);
		 * }
		 * return collector.finisher().apply(container);
		 * */
		// implement Collector interface by myself
		// components:
		// s -> supplier, create the accumulator container using a Supplier<A>
		// a -> accumulator, add a single new element to accumulator container using BiConsumer<A, T>
		// c -> combiner, merge two accumulator containers using a BinaryOperator<A>
		// f -> finisher, transform the accumulator container into the result container using Function<A, R>
		// c -> characteristic, A Set<Collector.Characteristics> chosen from the enum values
		Supplier<String> supplier = () -> "hello";
		System.out.println(supplier.get());

		Consumer<Integer> consumer = (e) -> System.out.println(e);
		consumer.accept(new Supplier<Integer>() {
			@Override
			public Integer get() {
				return 0;
			}
		}.get());

		UnaryOperator<Boolean> unaryOperator = t -> t;
		System.out.println(unaryOperator.apply(true));

		BinaryOperator<Long> binaryOperator = (a, b) -> a + b;
		System.out.println(binaryOperator.apply(1L, 2L));

		Predicate<String> predicate = s -> s.length() % 2 == 0;
		System.out.println(predicate.test("hello"));
	}
	// sacfc

}
