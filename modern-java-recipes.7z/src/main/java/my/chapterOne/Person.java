package my.chapterOne;

import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Collectors;

public class Person {
	private String name;
	private int age;
	private String sex;

	public Person() {
	}

	public Person(String name, int age, String sex) {
		this.name = name;
		this.age = age;
		this.sex = sex;
	}

	public Person(String s) {
		this.name = s;
		this.age = 18;
		this.sex = "unknown";
	}

	public Person(Person p) {
		this.name = p.getName();
		this.age = p.getAge();
		this.sex = p.getSex();
	}

	public Person(String... names) {
		this.name = Arrays.stream(names).collect(Collectors.joining(" "));
		this.age = 30;
		this.sex = "male";
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getSex() {
		return sex;
	}

	@Override
	public String toString() {
		return "%1$-10s %2$-4d %3$-7s".formatted(name, age, sex);
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Person person)) return false;
		return age == person.age && Objects.equals(name, person.name) && Objects.equals(sex, person.sex);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, age, sex);
	}
}
