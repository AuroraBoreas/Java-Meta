package my.chapterOne;

import java.util.Comparator;
import java.util.Random;

public class Cyan {
	public static class CyanComparator implements Comparator<Cyan> {
		@Override
		public int compare(Cyan o1, Cyan o2) {
			return o1.getName().compareTo(o2.getName());
		}
	}
	private final int id;
	private final String name;
	private final int employeeId;

	private static final Random random = new Random();

	public Cyan(int id, String name, int employeeId) {
		this.id = id;
		this.name = name;
		this.employeeId = employeeId;
	}

	public Cyan() {
		this(random.nextInt(1, 1_000), "anonymous", random.nextInt(1_000, 10_000));
	}

	@Override
	public String toString() {
		return "%1$-4d %2$-10s %3$-5d".formatted(id, name, employeeId);
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getEmployeeId() {
		return employeeId;
	}
}
