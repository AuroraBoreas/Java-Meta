package my.chapterOne;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class One {
	// anonymous inner class ->
	public void basic() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					Thread.sleep(100);
					System.out.println("hello world from " + Thread.currentThread());
				} catch (InterruptedException e) {
					throw new RuntimeException(e);
				}
			}
		}).start();
	}

	// anonymous inner static class
	public void fundamental() {
		List<Cyan> list = new ArrayList<>(List.of(
				new Cyan(1, "Cyan", 1001),
				new Cyan(2, "Yellow", 1002),
				new Cyan(3, "Magenta", 1003),
				new Cyan(4, "Blue", 1004),
				new Cyan()
		));
		var c0 = new Cyan.CyanComparator();
		list.sort(c0);
		System.out.println(list);
		list.sort(new Comparator<Cyan>() {
			@Override
			public int compare(Cyan o1, Cyan o2) {
				return o1.getEmployeeId() - o2.getEmployeeId();
			}
		});
		list.sort((c1, c2) -> c1.getName().compareTo(c2.getName()));
		list.sort(Comparator.comparing(Cyan::getName));
	}

	// lambda
	public void lambda() {
		// supplier, consumer, function, predictor
		// + unary / bi
		String[] s = {"hello", "world", "Supplier", "Consumer", "Function", "Predictor"};
		Stream.of(s).parallel().filter(e -> e.startsWith("o", 1)).forEach(System.out::println);
	}

	public Consumer<List<String>> myConsumer() {
		return (s) -> System.out.println(s.get(0).toUpperCase() + s.get(1).toUpperCase());
	}

	public void createFile(String fileName) {
		File file = new File(fileName);
		try {
			Files.createFile(file.toPath());
		} catch (IOException ignore) {
		}
	}

	public String[] implementFilenameFilter(File directory) {
		return directory.list((x, y) -> y.endsWith(".java"));
	}

	public void streamPrinter(){
		Stream.of(1,2,3,4,5).forEach(System.out::println);
	}

	public void streamGenerator() {
		Stream.generate(Math::random).limit(19).forEach(System.out::println);
	}

	public List<String> multiArgumentInstanceMethod() {
		List<String> list = Arrays.asList("this", "is", "a", "list", "of", "string");
		// return list.stream().sorted((s1, s2) -> s1.compareTo(s2)).toList();
		return list.stream().sorted(String::compareTo).toList();
	}
	
	public void useStringMethodReference() {
		multiArgumentInstanceMethod().stream().map(String::length).forEach(System.out::println);
	}

	public void customClassInstanceMethod() {
		List<Person> people = new ArrayList<>(List.of(
				new Person("Cyan", 38, "female"),
				new Person("Lyan", 38, "male"),
				new Person("Hello", 22, "female")
		));
		people.stream().map(Person::getName).forEach(System.out::println);
	}

	public List<Person> constructorReference() {
		List<String> names = List.of("Cyan", "Lyan", "Hello", "Blue");
		return names.stream().map(Person::new).collect(Collectors.toList());
	}
}
