package my.chapterFive;

public interface Company {
	default String getName() {
		return "Initech";
	}

	// other methods
}
