package my.chapterFive;

import jdk.jfr.BooleanFlag;

import java.math.BigInteger;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.logging.Logger.getLogger;

public class Five {
	// P135 / 321, issues with Streams, lambdas, and method references;

	private final Map<Long, BigInteger> cache = new HashMap<>();

	@BooleanFlag
	public <T> boolean objectsDeepEquals(T[] a, T[] b) {
		Objects.requireNonNull(a);
		Objects.requireNonNull(b);
		return Objects.deepEquals(a, b);
	}

	@BooleanFlag
	public <T> boolean objectsEquals(T a, T b) {
		Objects.requireNonNull(a);
		Objects.requireNonNull(b);
		return Objects.equals(a, b);
	}

	public <T> int objectHash(T a) {
		return Objects.hash(a);
	}

	public <T> String objectsToString(T a) {
		return Objects.toString(a);
	}

	public boolean objectsNotNull() {
		List<String> strings = Arrays.asList("this", null, "is", "a", null, "list", "of", "strings", null);
		List<String> noNull = strings.stream().filter(Objects::nonNull).collect(Collectors.toList());
		return Objects.deepEquals(strings, noNull);
	}

	public void generateStreamOfRandomNumbers() {
		Random random = new Random();

		System.out.println("=".repeat(30));
		random.ints(5)
				.sorted()
				.forEachOrdered(System.out::println);

		System.out.println("=".repeat(30));
		random.doubles(5, 0, 5)
				.sorted()
				.forEach(System.out::println);

		System.out.println("=".repeat(30));
		List<Long> list = random.longs(5)
				.sorted()
				.boxed().toList();
		System.out.println(list);

		List<Integer> ints = random.ints(5, 10, 20)
				.collect(
						Vector::new,
						Vector::add,
						Vector::addAll
				);
		System.out.println(ints);
	}

	public long fibonacci(long i) {
		if (i < 0) throw new IllegalArgumentException("i must not be less than 0");
		if (i == 0) return 0;
		if (i == 1) return 1;
		return fibonacci(i - 2) + fibonacci(i - 1);
	}

	public BigInteger fib(long i) {
		if (i == 0) return BigInteger.ZERO;
		if (i == 1) return BigInteger.ONE;
		return cache.computeIfAbsent(
				i,
				n -> fib(n - 2).add(fib(n - 1))
		);
	}

	public Map<String, Integer> countWords(String passage, String... strings) {
		Map<String, Integer> map = new HashMap<>();
		Arrays.stream(strings).forEach(x -> map.put(x, 0));
		Arrays.stream(passage.split(" "))
				.forEach(x -> map.computeIfPresent(x, (k, v) -> v + 1));
		return map;
	}

	public void composeAndThen(int n) {
		Function<Integer, Integer> add2 = x -> x + 2;
		Function<Integer, Integer> mul3 = x -> x * 3;
		Function<Integer, Integer> mul3add2 = add2.compose(mul3);
		Function<Integer, Integer> add2mul3 = add2.andThen(mul3);
		System.out.println("compose -> " + mul3add2.apply(n));
		System.out.println("andThen -> " + add2mul3.apply(n));
	}

	public void parseStringThenAdd2(String s) {
		Function<Integer, Integer> add2 = x -> x + 2;
		Function<String, Integer> parseThenAdd2 = add2.compose(Integer::parseInt);
		System.out.println("parseThenAdd2 -> " + parseThenAdd2.apply(s));
	}

	public void composedConsumerForPrintAndThenLog() {
		Logger logger = getLogger(this.getClass().getName());
		Consumer<String> c1 = System.out::println;
		Consumer<String> c2 = logger::info;
		Consumer<String> printThenLog = c1.andThen(c2);
		Stream.of("this", "is", "a", "stream", "of", "strings")
				.forEach(printThenLog);
	}

	public boolean isPerfect(long n) {
		return Math.sqrt(n) % 1 == 0;
	}

	public boolean isTriangle(long n) {
		double val = (Math.sqrt(8 * n + 1) - 1) / 2;
		return val % 1 == 0;
	}

	public List<Integer> div(List<Integer> list, Integer factor) {
		return list.stream()
				.map(x -> divide(x, factor))
				.toList();
	}

	private Integer divide(Integer val, Integer factor) {
		Integer res = null;
		try {
			res = val / factor;
		} catch (ArithmeticException e) {
			e.printStackTrace();
		}
		return res;
	}

	public List<String> encodeValueWithWrapper(String... values) {
		return Arrays.stream(values)
				.map(wrapper(s -> URLEncoder.encode(s, StandardCharsets.UTF_8)))
				.toList();
	}

	private <T, R, E extends Exception> Function<T, R> wrapper(
			FunctionWithException<T, R, E> fe
	) {
		return arg -> {
			try {
				return fe.apply(arg);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		};
	}

}