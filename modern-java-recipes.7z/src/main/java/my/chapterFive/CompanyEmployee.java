package my.chapterFive;

import java.util.logging.Logger;

public class CompanyEmployee implements Company, Employee {
	Logger logger = Logger.getLogger(this.getClass().getName());
	private String first;
	private String last;

	public CompanyEmployee() {
	}

	public CompanyEmployee(String first, String last) {
		this.first = first;
		this.last = last;
	}

	@Override
	public String getFirst() {
		return first;
	}

	@Override
	public String getLast() {
		return last;
	}

	@Override
	public void convertCaffeineToCodeForMoney() {
		logger.info("Coding...");
	}

	@Override
	public String getName() {
		return String.format(
				"%s working for %s",
				Employee.super.getName(),
				Company.super.getName()
		);
	}

	@Override
	public String toString() {
		return "CompanyEmployee{" +
				"first='" + first + '\'' +
				", last='" + last + '\'' +
				'}';
	}
}
