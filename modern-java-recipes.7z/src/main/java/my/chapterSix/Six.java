package my.chapterSix;

public class Six {
	public void returnAnOptional() {
		Manager manager = new Manager("Ms Cyan");
		Department d1 = new Department();
		d1.setBoss(manager);
		System.out.println("Boss: " + d1.getBoss());
		System.out.println("Name: " + d1.getBoss().map(Manager::getName));

		Department d2 = new Department();
		System.out.println("Boss: " + d2.getBoss());
		System.out.println("Name: " + d2.getBoss().map(Manager::getName));
	}

	
}
