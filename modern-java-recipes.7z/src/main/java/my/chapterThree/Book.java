package my.chapterThree;

public class Book {
	public int id;
	public String title;
	// hashcode, toString, wait, notify, notifyAll
	// getters, setters, equals, ctr

	public Book(int id, String title) {
		this.title = title;
		this.id=id;
	}

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Book{id=%d, title=%s}".formatted(id, title);
	}
}
