package my.chapterThree;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Three {
	/*
	 * topic: create stream
	 * what I know is Arrays.stream(); Stream.of(); List.stream();
	 * Steam.iterate(); Stream.generate();
	 * IntStream.range(); DoubleStream.range(); LongStream.range();
	 * Stream "g -> generate, o -> of, i -> iterate"
	 *
	 * */

	public String streamOf(String... args) {
		Objects.requireNonNull(args);
		return Arrays.stream(args).collect(Collectors.joining(","));
	}

	public List<BigDecimal> streamIterateBigDecimal() {
		return Stream.iterate(BigDecimal.ZERO, x -> x.add(BigDecimal.ONE))
				.limit(3)
				.toList();
	}

	public List<LocalDate> streamIterateLocalDate() {
		return Stream.iterate(LocalDate.now(), x -> x.plusDays(1L))
				.limit(3)
				.toList();
	}

	public List<Double> streamGenerateRandomNumbers() {
		return Stream.generate(Math::random)
				.limit(3)
				.toList();
	}

	public List<Integer> intStreamRange() {
		return IntStream.range(10, 13)
				.boxed()
				.toList();
	}

	public List<Integer> intStreamRangeClosed() {
		return IntStream.rangeClosed(10, 13)
				.boxed()
				.toList();
	}

	public List<Integer> mapToInteger() {
		return IntStream.of('a', 'b', 'c', 'd')
				.mapToObj(Integer::valueOf)
				.toList();
	}

	public List<Integer> threeArgumentsCollect() {
		return IntStream.of(3, 1, 4, 1, 5, 9)
				.collect(
						ArrayList<Integer>::new,
						ArrayList::add,
						ArrayList::addAll
				);
	}

	// min max cnt avg sum
	// f i g r
	public long streamReductionCount(String... args) {
		return Arrays.stream(args).map(String::length).count();
	}

	public int streamReductionSum(String... args) {
		return Arrays.stream(args).mapToInt(String::length).sum();
	}

	public OptionalDouble streamReductionAvg(String... args) {
		return Arrays.stream(args).mapToInt(String::length).average();
	}

	public OptionalInt streamReductionMax(String... args) {
		return Arrays.stream(args).mapToInt(String::length).max();
	}

	public OptionalInt streamReductionMin(String... args) {
		return Arrays.stream(args).mapToInt(String::length).min();
	}

	public int streamReductionReduce() {
		return IntStream.rangeClosed(1, 10)
				.reduce(0, (x, y) -> x + y);
	}

	public int intStreamReduceIntBinaryOperator() {
		return IntStream.rangeClosed(1, 10).reduce(9, Integer::sum);
	}

	public int intStreamReduceIntBinaryOperatorMax() {
		return IntStream.rangeClosed(1, 10).reduce(Integer.MIN_VALUE, Integer::max);
	}

	public String reduceArrayToString(String... args) {
		Objects.requireNonNull(args);
		return Arrays.stream(args).reduce(" ", String::concat);
	}

	public String reduceIntArrayToString(int... args) {
		// inefficient because of String::concat creates then destroy temporary objects on the fly
		Objects.requireNonNull(args);
		return Arrays.stream(args).mapToObj(Objects::toString).reduce("", String::concat);
	}

	public String reduceIntArrayToStringEfficient(int... args) {
		Objects.requireNonNull(args);
		// TODO: understand three-arguments Collector xD
		return Arrays.stream(args).collect(
				StringBuilder::new,    // Supplier
				StringBuilder::append, // BiConsumer, accumulator
				StringBuilder::append  // BiConsumer. combiner
		).toString();
	}

	public String reduceIntArrayToStringSimplest(int... args) {
		Objects.requireNonNull(args);
		return Arrays.stream(args)
				.mapToObj(Objects::toString)
				.collect(Collectors.joining());
	}

	public void mostGeneralFormOfReduce() {
		/*
		 * <U> U reduce(
		 *   U identity,
		 *   BiFunction<U, ? super T, U> accumulator,
		 *   BiOperator<U> combiner,
		 * )
		 * */
		List<Book> list = new ArrayList<>(List.of(
				new Book(1, "hello world"),
				new Book(2, "Colors"),
				new Book(3, "natural language"),
				new Book(4, "math language"),
				new Book(5, "programming language")
		));
		HashMap<Integer, Book> bookMap = list.stream()
				.reduce(
						new HashMap<>(),
						(map0, book) -> {
							map0.put(book.getId(), book);
							return map0;
						},
						(map1, map2) -> {
							map1.putAll(map2);
							return map1;
						}
				);
		bookMap.forEach((k, v) -> System.out.println(k + " " + v));
	}

	public void checkSortingUsingReduce() {
		List<String> list = new ArrayList<>(List.of("this", "is", "a", "list", "of", "strings"));
		var result = list.stream()
				.sorted(Comparator.comparingInt(String::length))
				.toList();
		result.stream()
				.reduce((prev, curr) -> {
					assert (prev.length() <= curr.length());
					return curr;
				});
		System.out.println(result);
	}

	public int sumDoublesDivisibleBy3(int start, int inclusiveEnd) {
		return IntStream.rangeClosed(start, inclusiveEnd)
				.map(n -> n * 2)
				.filter(n -> n % 3 == 0)
				.sum();
	}

	public boolean convertStringToStreamAndBack(String s) {
		StringBuilder sb = new StringBuilder();
		for (char c : s.toCharArray()) {
			if (Character.isLetterOrDigit(c))
				sb.append(c);
		}
		var forward = sb.toString().toLowerCase();
		var backward = sb.reverse().toString().toLowerCase();
		return forward.equals(backward);
	}

	public boolean isPalindrome(String s) {
		/*
		 * <R> R collect(
		 *   Supplier<R> supplier,
		 *   BiConsumer<R, ? super T> accumulator,
		 *   BiConsumer<R, R> combiner
		 * );
		 * */
		var forward = s.toLowerCase().codePoints()
				.filter(Character::isLetterOrDigit)
				.collect(
						StringBuilder::new,
						StringBuilder::appendCodePoint,
						StringBuilder::append
				)
				.toString();
		var backward = new StringBuilder(forward).reverse().toString();
		return backward.equals(forward);
	}

	public Map<Boolean, Long> countStringPartitionedByLength(List<String> strings) {
		// 84 / 321
		return strings.stream()
				.collect(
						// downstream collector
						Collectors.partitioningBy(s -> s.length() % 2 == 0, Collectors.counting())
				);
	}

	public DoubleSummaryStatistics summaryStatistics() {
		// randomness is untestable
		// 大小计平和
		return DoubleStream.generate(Math::random).limit(1_000_000).summaryStatistics();
	}

	public DoubleSummaryStatistics collectWithSACOfTeams(List<Team> teams) {
		return teams.stream()
				.mapToDouble(Team::getSalary)
				.collect(
						DoubleSummaryStatistics::new,
						DoubleSummaryStatistics::accept,
						DoubleSummaryStatistics::combine
				);
	}

	public DoubleSummaryStatistics collectorSummarizing(List<Team> teams) {
		return teams.stream()
				.collect(Collectors.summarizingDouble(Team::getSalary));
	}

	public Optional<Integer> findFirst(List<Integer> numbers) {
		return numbers.stream()
				.filter(x -> x % 2 == 0)
				.findFirst();
	}

	public Optional<Integer> firstEven(List<Integer> numbers) {
		return numbers.stream()
				.parallel()
				.filter(n -> n % 2 == 0)
				.findFirst(); // encounter order
	}

	public void setAndEncounterOrder() {
		List<String> list = Arrays.asList("this", "is", "a", "list", "of", "strings");
		Set<String> set1 = new HashSet<>(list);
		Set<String> set2 = new HashSet<>(set1);
		// add and remove enough elements to force a rehash
		IntStream.rangeClosed(1, 500).forEachOrdered(i -> set2.add(String.valueOf(i)));
		set2.retainAll(list); // intersection
		// compare
		System.out.println(set1.equals(set2));
		System.out.println("Before: " + set1);
		System.out.println("after : " + set2);
	}

	public int fakeSleep(int n) {
		try {
			Thread.sleep((long) (Math.random() * 100));
		} catch (InterruptedException ignore) {
		}
		return n;
	}

	public Optional<Integer> findAnyInParallelAfterARandomDelay(List<Integer> list) {
		return list.stream()
				.unordered() // disable sequential encounter order
				.parallel()
				.map(this::fakeSleep)
				.findAny();
	}

	public boolean isPrime(int n) {
		int limit = (int) (Math.sqrt(n) + 1);
		return n == 2 || n > 2 && IntStream.range(2, limit).noneMatch(d -> n % d == 0);
	}

	public List<String> concatTwoStreams() {
		Stream<String> first = Stream.of("a", "b", "c").parallel();
		Stream<String> second = Stream.of("x", "y", "z");
		return Stream.concat(first, second).toList();
	}

	public List<String> concatThreeStreams() {
		Stream<String> first = Stream.of("a", "b", "c").parallel();
		Stream<String> second = Stream.of("x", "y", "z");
		Stream<String> third = Stream.of("alpha", "beta", "gamma");
		// using Stream.concat() creates a parallel stream if any of the input streams are parallel
		return Stream.concat(Stream.concat(first, second), third).collect(Collectors.toList());
	}

	public List<String> concatMoreStreams() {
		Stream<String> first = Stream.of("a", "b", "c").parallel();
		Stream<String> second = Stream.of("x", "y", "z");
		Stream<String> third = Stream.of("alpha", "beta", "gamma");
		Stream<String> forth = Stream.empty();
		return Stream.of(first, second, third, forth)
				.reduce(Stream.empty(), Stream::concat).toList();
	}

	public boolean combineStreamsNaturalSolution() {
		Stream<String> first = Stream.of("a", "b", "c").parallel();
		Stream<String> second = Stream.of("x", "y", "z");
		Stream<String> third = Stream.of("alpha", "beta", "gamma");
		Stream<String> forth = Stream.empty();
		// using Stream.flatMap() does not create a parallel stream if any of the input streams are parallel
		Stream<String> result = Stream.of(first, second, third, forth)
				.flatMap(Function.identity());
		return result.isParallel(); // false
//		return result.equals(Arrays.asList("a", "b", "c", "x", "y", "z", "alpha", "beta", "gamma"));
	}

	public boolean quirksCombineParallel() {
		Stream<String> first = Stream.of("a", "b", "c").parallel();
		Stream<String> second = Stream.of("x", "y", "z");
		Stream<String> third = Stream.of("alpha", "beta", "gamma");
		Stream<String> forth = Stream.empty();
		Stream<String> result = Stream.of(first, second, third, forth)
				.reduce(Stream.empty(), Stream::concat);
		return result.isParallel(); // true
	}

	
}