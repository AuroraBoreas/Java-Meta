package my.chapterTwo;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Two {
	public static final List<String> names = Arrays.asList("Mal", "Wash", "Kaylee", "Inara",
			"Zoë", "Jayne", "Simon", "River", "Shepherd Book"
	);

	// basic principle: lambda / method reference always has a context.
	public Consumer<String> getConsumer() {
		return new Consumer<String>() {
			@Override
			public void accept(String s) {
				if (s.toLowerCase().startsWith("c")) {
					System.out.println(s);
				}
			}
		};
	}
	
	public Optional<String> findFirst() {
		return names.stream()
				.filter(x -> x.toLowerCase().startsWith("c"))
				.findFirst();
	}

	public String getNamesOfLength(int length, String... names) {
	    return Stream.of(names)
			    .filter(x -> x.length() == length)
			    .collect(Collectors.joining(", "));
	}

	/**
	 *
	 * @param condition @Predicate<T>
	 * @param names varargs of strings
	 * @return String
	 */
	public String getNamesSatisfyingCondition(Predicate<String> condition, String... names) {
		return Arrays.stream(names)
				.filter(condition)
				.collect(Collectors.joining(", "));
	}

	public void flatMe(List<List<String>> list) {
		var result = list.stream().flatMap(Collection::stream).collect(Collectors.groupingBy(String::length));
		System.out.println(result);
	}

	public boolean allMatch(List<String> data) {
	    return data.stream().allMatch(x -> x.toLowerCase().startsWith("h"));
	}

	public boolean anyMatch(List<String> data) {
	    return data.stream().anyMatch(x -> x.toLowerCase().startsWith("c"));
	}

	public boolean noneMatch(List<String> data) {
	    return data.stream().noneMatch(x -> x.toLowerCase().startsWith("c"));
	}

	public List<Integer> utilFunction(List<String> names) {
	    return names.stream().map(String::length).toList();
	}
}
