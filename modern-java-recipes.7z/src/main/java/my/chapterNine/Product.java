package my.chapterNine;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class Product {
	private int id;
	private final Map<Integer, Product> cache = new HashMap<>();
	public CompletableFuture<Product> getProduct(int id) {
		try {
			Product product = getLocal(id);
			if (product != null) {
				return CompletableFuture.completedFuture(product);
			} else {
				CompletableFuture<Product> cfo = new CompletableFuture<>();
				Product p = getLocal(id);
				cache.put(id, p);
				cfo.complete(p);
				return cfo;
			}
		} catch (Exception e) {
			CompletableFuture<Product> future = new CompletableFuture<>();
			future.completeExceptionally(e);
			return future;
		}
	}

	public void sync() throws InterruptedException {
		synchronized (this) {
			for (int i=0; i<10; i++) {
				Thread.sleep(i * 100);
				System.out.println(i);
			}
		}
	}

	public Product getLocal(int id) {
		return new Product(id);
	}

	public Product(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Product{" +
				"id=" + id +
				'}';
	}
}
