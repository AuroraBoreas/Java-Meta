package my.chapterNine;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.stream.LongStream;

import static java.util.concurrent.Executors.newFixedThreadPool;

public class Nine implements MyInterface{
	// concurrency vs parallelism
	// concurrency -> when multiple tasks CAN run in overlapping time period;
	// parallelism -> when multiple tasks run at literally the same time;

	public void createYourOwnForkJoinPool() {
		// make implementation first, then consider applying parallelism
		ForkJoinPool pool = new ForkJoinPool(15);
		ForkJoinTask<Long> task = pool.submit(
				() -> LongStream.rangeClosed(1, 3_000_000)
						.parallel()
						.sum()
		);

		Long result = null;
		try {
			result = task.get();
		} catch (ExecutionException | RuntimeException | InterruptedException ignore) {
		} finally {
			pool.shutdown();
		}

		System.out.println(result);
		System.out.println(pool.getPoolSize());
	}

	public void completableFutureThing() {
		// CompletableFuture allows you to coordinate activities w/o writing nested callbacks
//		ForkJoinPool pool = new ForkJoinPool(15);
//		ForkJoinTask<String> task = pool.submit(
//				() -> {
//					String hello = "hello";
//					Thread.sleep(400);
//					return hello;
//				}
//		);
//
//		String result = null;
//		try {
//			result = task.get();
//		} catch (ExecutionException | RuntimeException | InterruptedException ignore) {
//		} finally {
//			pool.shutdown();
//		}
//		System.out.println(result);

		// P242 / 321, CompletableFuture mechanism
		// is rather similar to JavaScript's Future and Promise;
		// goto restaurant and order your favorite food then wait
		// good or not ?
		// chef promises the food is good in future by default;
	}

	public String sleepThenReturnString() {
		try {
			Thread.sleep(100);
		} catch (InterruptedException ignore) {
		}
	    return "69";
	}

	public void completableFutureSupplyAsync() {
		CompletableFuture.supplyAsync(this::sleepThenReturnString)
				.thenApply(Integer::parseInt)
				.thenApply(x -> x * 2)
				.thenAccept(System.out::println)
				.join();
		System.out.println("Running...");
	}

	public void runCompletableFutureTasksWithSeparateThreadPool() {
		// CompletableFuture coordination methods (using common ForkJoinPool <- default hardware threads)
		// anyOf
		// allOf
		// accept: thenAccept, acceptEither,
		// apply: thenApply, applyToEither,
		// async: runAsync, supplyAsync
		// run: thenRun, runAfter, runAfterBoth,
		// combine: thenCombine
		// compose: thenCompose
		// complete: whenComplete
		// 5a r 3c
		ExecutorService service = newFixedThreadPool(15);
		CompletableFuture.supplyAsync(this::sleepThenReturnString, service)
				.thenApply(Integer::parseInt)
				.thenApply(x -> x*2)
				.thenAccept(System.out::println)
				.join()
		;
		System.out.println("Running..");
	}

	public CompletableFuture<Integer> getIntegerCompletableFuture(String n) {
		return CompletableFuture.supplyAsync(() -> Integer.parseInt(n))
				.handle((val, exc) -> val != null ? val : 0);
	}

	public void pecs() {
		// PECS
		// producer extends (covariant): using `extends` when u only get values out of a data structure
		// consumer super (contravariant): using `super` when u only put values into a data structure
		// (invariant) using an explicit type when u plan to do both
		List<Number> list = new ArrayList<>();
		list.add(1);
		covariant(list);
		contravariant(list);
		System.out.println(list);
	}

	public void covariant(List<? extends Number> list) {
		list
//				.filter(x -> x > 10)
//				.map(x -> x * 2)
				.forEach(System.out::println);
	}

	public void contravariant(List<? super Number> list) {
		list.add(5);

//		ForkJoinPool pool = new ForkJoinPool(15);
//		ForkJoinTask<Integer> task = pool.submit(
//				() -> {
//					Thread.sleep(400);
//					return 42;
//				}
//		);
//
//		Integer result = null;
//		try {
//			result = task.get();
//		} catch (ExecutionException | RuntimeException | InterruptedException ignore) {
//		} finally {
//			pool.shutdown();
//		}
//		System.out.println(result);

		// 文时结算数
		// 件存档密行
		// 局互邮块地
		// 开运语模包

		// Predict  -> test();   + unary, binary
		// Function -> apply();  + unary, binary
		// Supplier -> get();    + unary, binary
		// Consumer -> accept(); + unary, binary

		// Collectors
		// S A C F P
		// supplier
		// accumulator
		// combiner
		// finisher
		// characteristics

		// JVM::Separator

	}
}
