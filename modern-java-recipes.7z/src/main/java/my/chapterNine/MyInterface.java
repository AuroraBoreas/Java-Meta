package my.chapterNine;

public interface MyInterface {
	// sam
	String sleepThenReturnString();
}
