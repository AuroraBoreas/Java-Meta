package my.chapterEight;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.*;
import java.util.stream.Stream;

public class Eight {
	public void resultOfCallingTheNowMethod() {
		Stream.of(
				Instant.now(),
				LocalDate.now(),
				LocalTime.now(),
				LocalDateTime.now(),
				ZonedDateTime.now()
		).forEach(System.out::println);
	}
	
	public void methodForDateTimeClass() {
		Stream.of(
				Instant.ofEpochMilli(3_000_000),
				LocalDate.of(2023, Month.JUNE, 30),
				LocalTime.of(13, 30),
				LocalDateTime.of(2023, Month.DECEMBER, 31, 8,30, 30, 150_000_000)
		).forEach(System.out::println);
	}

	public void regionId() {
		Stream.of(
				ZoneId.getAvailableZoneIds(),
				ZoneId.of("Asia/Shanghai")
		).forEach(System.out::println);
	}
	
	public void applyTimeZoneToLocalDateTime() {
		LocalDateTime dateTime = LocalDateTime.of(2023, Month.JUNE, 21, 14, 0, 0);
		System.out.println(dateTime.atZone(ZoneId.of("Asia/Shanghai")));;
	}
	
	public void someMethodsInMonthEnum() {
		Stream.of(
				Month.FEBRUARY.length(true),
				Month.FEBRUARY.minLength(),
				Month.MARCH.maxLength(),
				Month.APRIL.firstDayOfYear(false),
				Month.MAY.minus(1)
		).forEach(System.out::println);
	}
	
	public void localDatePlus() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate localDate = LocalDate.of(2023,Month.JUNE,21);
		Stream.of(
				localDate,
				localDate.plusDays(3).format(formatter),
				localDate.plusWeeks(1).format(formatter),
				localDate.plusMonths(2).format(formatter),
				localDate.plusYears(1).format(formatter),
				localDate.minusDays(1).format(formatter),
				localDate.minusWeeks(2).format(formatter),
				localDate.minusMonths(3).format(formatter),
				localDate.minusYears(4).format(formatter)
		).forEach(System.out::println);
	}
	
	public void localTimePlus() {
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_TIME;
		LocalTime start = LocalTime.of(8, 30, 0);
		Stream.of(
				start.format(formatter),
				start.plusHours(1).format(formatter),
				start.plusMinutes(2).format(formatter),
				start.plusSeconds(30).format(formatter),
				start.plusNanos(15_000_000).format(formatter),
				start.minusHours(1).format(formatter),
				start.minusMinutes(2).format(formatter),
				start.minusSeconds(3).format(formatter),
				start.minusNanos(15_000_000).format(formatter)
		).forEach(System.out::println);
	}
	
	public void plusMinus() {
		Period period = Period.of(2, 3, 4);
		LocalDateTime start = LocalDateTime.of(2017, Month.JUNE, 2, 11, 30);
		LocalDateTime end = start.plus(period);
		System.out.println(end.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
		end = start.plus(3, ChronoUnit.HALF_DAYS);
		System.out.println(end.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
		end = start.minus(3, ChronoUnit.CENTURIES);
		System.out.println(end.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
	}
}
