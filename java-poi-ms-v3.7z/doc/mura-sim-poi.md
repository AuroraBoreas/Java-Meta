# Mura Adjustment Simulation Result Check

To improve the confirmation of Mura Adjustment process at SSVE, especially ten thousand of files, I leverage Java
multithreading / parallel computing features to create this App.

## Author

TVQA member `@ZL`, 20230510

## Changelog

- v0.0.1, create classes to search Mura log files, then implement sampling.
- v0.0.2, construct user interface using Java Swing.
- v0.0.3, delayer C# Form App(provided by SGMO), distill BinToBmp functionality, compile C# library into a DLL file.
  using JNI to bridge then Java calls it.
- v0.0.4, utilise Apache poi to create Excel files on the fly.
- v0.0.5, read a csv file that contains SCC number list.
- v0.0.6, introduce SQLite database using JDBC

## GUI

<img src="2023-05-22-18-10-46.png" width="480" height="300">

### Usage

1. Labels with asterisk(*) must not be empty. click `...` to choose a directory;
2. Choose `source` (root) directory wisely, Or it will take a long time to search. It prefers a narrowed root directory;
3. Be careful of `interval` numbers. Otherwise it spends long time to convert \*.bin to \*.jpg files;
4. Have a basic knowladge about Mura Adjustment process and select proporiate IRE patterns.
5. Other are optional;

### Note

source files (*.bin) are provided by SSVE IE/PE team.

## Final Outcome

<img src="2023-05-22-18-11-39.png" width="480" height="300">

## Schema

<img src="20230522_mura-sim-poi.png" width="600" height="420">

## Project Structure

```cmd
X:.
+---main
|   +---java
|   |   \---my
|   |       +---db
|   |       +---gui
|   |       +---pkg
|   |       \---util
|   \---resources
|       +---archetype-resources  
|       |   \---src
|       |       +---main
|       |       |   \---java     
|       |       \---test
|       |           \---java     
|       \---META-INF
|           \---maven
\---test
    \---java
        \---my
            \---pkg
```

## Implementation

The following is the implementation of this probject.

### GUI Design

User interface design

<img src="2023-05-22-18-30-39.png" width="480" height="300">

```Java
package my.gui;
public class MyApp extends JFrame {
    ...
    public MyApp() throws HeadlessException {...}
    public static void main(String[] args) {...}
    private void createWindows() {...}
    private void attachActionListeners() {
        openButtonSrc.addActionListener(e -> {...});
        openButtonDst.addActionListener(e -> {...});
        openButtonScc.addActionListener(e -> {...});
        startButton.addActionListener(e -> {...});
        resetButton.addActionListener(e -> {...});
    }

    private boolean isValidatedTextFields() {...}
    private void selectDirectoryDialog(JTextField textField) {...}
    private void selectFileDiaglog(JTextField textField) {...}
    private void createUIComponents() {...}
}
```

### SQL

A Java class connects with Sqlite database using JDBC.

```Java
package my.db;
public class Connector {
    ...
    public Connector(String dbName) {...}
    public void connect() {...}
    public void createNewTable() {...}
    public void insert(
            String lineName,
            String setNo,
            String date,
            String ire,
            String method,
            int interval,
            String file
    ) {...}
    public void selectAll() {...}
    private byte[] readFileToBytes(String file) throws IOException {...}
    private void writeBytesToFile(byte[] data, String savedFileName) {...}
    public void close() throws SQLException {...}
}
```

### Prototype

create an abstract class that has abilities to search and match \*.bin files.

```Java
package my.pkg;
public abstract class Prototype {
    ...
    public void reset() {...}
    public abstract void sort(Path src);
    public abstract void match() throws IOException;
    protected abstract void compare(
            TreeMap<String, Path> beforeMap,
            TreeMap<String, Path> afterMap
    ) throws IOException;

    protected abstract void compare(TreeMap<String, Path> beforeMap) throws IOException;
}

```

create an interface that has an ability to convert \*.bin to \*.jpg;

```Java
package my.pkg;
public interface Simulator {
    void convert() throws IOException, InterruptedException;
}
```

### Generate report

create a class to generate an Excel file on the fly.

```Java
package my.pkg;
public class Reporter {
    public static void start(String dstFileName, Prototype p) {...}
    private static void load(
            Map<String, Path> map,
            Workbook workbook,
            Sheet sheet,
            int column,
            float height
    ) throws IOException {...}
    private static void load(
            Prototype p,
            Workbook workbook,
            Sheet sheet,
            int beforeColumn,
            int afterColumn,
            float height
    ) throws IOException {...}
    private static void loadImageIntoWorksheet(
            Workbook workbook,
            Sheet sheet,
            String name,
            int firstRow,
            int firstColumn
    ) {...}
}
```

## Apply unit test

using JUnit, Mokito and Hamcrest to do unit test.

```Java
package my.pkg;
@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class DisassemblerTest {
    private Disassembler disassembler;
    @BeforeEach
    void setUp() {
        disassembler = new Disassembler("MesData640GResult_A5052876A_0000112_20230221143220.bin");
        disassembler.dissect();
        System.out.println("setUp");
    }
    @AfterEach
    void tearDown() {
        System.out.println("tearDown");
    }
    @Test
    @DisplayName("getFileHeaderPattern should return the correct pattern")
    void getFileHeaderPattern() {
        Assertions.assertEquals("mesdata\\d+(\\w)?(result)?(_corner)?_", disassembler.getFileHeaderPattern());
    }
    @Test
    @DisplayName("getFileTailPattern should return the correct pattern")
    void getFileTailPattern() {
        Assertions.assertEquals("_(result_)?[0-9]{14}.(bin|jpg)", disassembler.getFileTailPattern());
    }
    @Test
    @DisplayName("getFileHeader should return the correct file header")
    void getFileHeader() {
        Assertions.assertEquals("MesData640GResult_", disassembler.getFileHeader());
    }
    @Test
    @DisplayName("getFileTail should return the correct file tail")
    void getFileTail() {
        Assertions.assertEquals("_20230221143220.bin", disassembler.getFileTail());
    }
    @Test
    @DisplayName("getaNo_Scc should return the correct aNo_Scc")
    void getaNo_Scc() {
        Assertions.assertEquals("A5052876A_0000112", disassembler.getaNo_Scc());
    }
    @Test
    @DisplayName("dissect should return the correct result")
    void dissect() {
        List<String> list = new ArrayList<>(List.of(...));
        List<String> aNo_Sccs = new ArrayList<>(list.size());
        Disassembler disassembler1;
        for (String fileName : list) {
            disassembler1 = new Disassembler(fileName);
            disassembler1.dissect();
            aNo_Sccs.add(disassembler1.getaNo_Scc());
        }
        assertThat(aNo_Sccs, hasItems(...));
    }
}

```

## Pitfalls

There are several pitfalls encountered during development.

1. log4j2-core missing -> solution: download `log4j-core-2.20.0.jar` and add it into `classpath`(Modules dependencies)
2. the artifact cannot find sqlite-jdbc -> solution: download `sqlite-jdbc-3.41.2.1.jar` and add it into `classpath`(
   Modules dependencies); also add it into Artifacts Output Layout as `Extracted Directory`
3. idea64 automatically changes Java language level from 17 to 1.5 -> solution:
   add `<maven.compiler.source>17</maven.compiler.source>` `<maven.compiler.target>17</maven.compiler.target>` into
   pom.xml; always check Project Settings(Project-SDK, Language level; Modules-SDK, Language level; Java compiler; all
   of them should be precisely same)
4. where to put my DLL file path? -> solution: put them under Project directory(root); put them at the same directory
   level as JAR
5. JAR -> executable -> solution: launch4j
6. setup.exe -> solution: inno
7. downloading maven dependencies is struggling -> solution: just like `pip`, change `settings.ini` or `settings.xml`
8. maven dependencies missing after reopened idea64 -> solution: File -> Invalidate cache... -> Reload all maven projects

```xml
<!-- ~/.m2/settings.xml -->

<?xml version="1.0" encoding="UTF-8"?>
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
          xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0 http://maven.apache.org/xsd/settings-1.0.0.xsd">
    <mirrors>
        <!-- mirror
         | Specifies a repository mirror site to use instead of a given repository. The repository that
         | this mirror serves has an ID that matches the mirrorOf element of this mirror. IDs are used
         | for inheritance and direct lookup purposes, and must be unique across the set of mirrors.
         |
        <mirror>
          <id>mirrorId</id>
          <mirrorOf>repositoryId</mirrorOf>
          <name>Human Readable Name for this Mirror.</name>
          <url>http://my.repository.com/repo/path</url>
        </mirror>
         -->
 
        <mirror>
            <id>alimaven</id>
            <name>aliyun maven</name>
            <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
            <mirrorOf>central</mirrorOf>
        </mirror>
 
        <mirror>
            <id>uk</id>
            <mirrorOf>central</mirrorOf>
            <name>Human Readable Name for this Mirror.</name>
            <url>http://uk.maven.org/maven2/</url>
        </mirror>
 
        <mirror>
            <id>CN</id>
            <name>OSChina Central</name>
            <url>http://maven.oschina.net/content/groups/public/</url>
            <mirrorOf>central</mirrorOf>
        </mirror>
 
        <mirror>
            <id>nexus</id>
            <name>internal nexus repository</name>
            <!-- <url>http://192.168.1.100:8081/nexus/content/groups/public/</url>-->
            <url>http://repo.maven.apache.org/maven2</url>
            <mirrorOf>central</mirrorOf>
        </mirror>
 
    </mirrors>
</settings>
```

## About

MIT License

Copyright (c) 2023 ZL

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
