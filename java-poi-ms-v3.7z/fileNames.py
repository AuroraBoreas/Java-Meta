import logging
import pathlib
from typing import Generator

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')

def client_code() -> None:
    folder: str = r"c:\Users\5106001995\Desktop\20230508_85TP_Foreign_Material_SOEM_MP\data\TP_RD"
    files: Generator[pathlib.Path, None, None] = pathlib.Path(folder).rglob("*.bin")
    for file in files:
        print(file.name)
     
text: str = """
"MesData1023_A5052876A_0000112_20230221143124.jpg",
"MesData128Result_A5052876A_0000112_Result_20230221143206.jpg",
"MesData128_A5052876A_0000112_20230221143133.jpg",
"MesData1Result_12543800_0012962_20230424182930.jpg",
"MesData1_12543800_0012962_20230425155746.jpg",
"MesData256Result_A5052876A_0000112_Result_20230221143202.jpg",
"MesData256_A5052876A_0000112_20230221143130.jpg",
"MesData2Result_12543800_0012962_20230424182932.jpg",
"MesData2_12543800_0012962_20230425155748.jpg",
"MesData3Result_12543800_0012962_20230424182933.jpg",
"MesData3_12543800_0012962_20230425155749.jpg",
"MesData4Result_12543800_0012962_20230424182935.jpg",
"MesData4_12543800_0012962_20230425155751.jpg",
"MesData512Result_A5052876A_0000112_Result_20230221143200.jpg",
"MesData512_A5052876A_0000112_20230221143128.jpg",
"MesData512_Corner_A5052876A_0000112_20230221143149.jpg",
"MesData5Result_12543800_0012962_20230424182943.jpg",
"MesData5_12543800_0012962_20230425155753.jpg",
"MesData640BResult_12543800_0012962_20230424182950.jpg",
"MesData640BResult_A5052876A_0000112_20230221143220.jpg",
"MesData640B_12543800_0012962_20230425155805.jpg",
"MesData640B_A5052876A_0000112_20230221143212.jpg",
"MesData640GResult_12543800_0012962_20230424182950.jpg",
"MesData640GResult_A5052876A_0000112_20230221143220.jpg",
"MesData640G_12543800_0012962_20230425155805.jpg",
"MesData640G_A5052876A_0000112_20230221143212.jpg",
"MesData640RResult_12543800_0012962_20230424182950.jpg",
"MesData640RResult_A5052876A_0000112_20230221143220.jpg",
"MesData640R_12543800_0012962_20230425155805.jpg",
"MesData640R_A5052876A_0000112_20230221143212.jpg",
"MesData768Result_A5052876A_0000112_Result_20230221143159.jpg",
"MesData768_A5052876A_0000112_20230221143126.jpg",
"MesData768_Corner_A5052876A_0000112_20230221143147.jpg",
"""

"""
"A5052876A_0000112",
"A5052876A_0000112",
"A5052876A_0000112",
"12543800_0012962",
"12543800_0012962",
"A5052876A_0000112",
"A5052876A_0000112",
"12543800_0012962",
"12543800_0012962",
"12543800_0012962",
"12543800_0012962",
"12543800_0012962",
"12543800_0012962",
"A5052876A_0000112",
"A5052876A_0000112",
"A5052876A_0000112",
"12543800_0012962",
"12543800_0012962",
"12543800_0012962",
"A5052876A_0000112",
"12543800_0012962",
"A5052876A_0000112",
"12543800_0012962",
"A5052876A_0000112",
"12543800_0012962",
"A5052876A_0000112",
"12543800_0012962",
"A5052876A_0000112",
"12543800_0012962",
"A5052876A_0000112",
"A5052876A_0000112",
"A5052876A_0000112",
"A5052876A_0000112",
"""

def main() -> None:
    # client_code()
    import re
    p1: str = r"mesdata\d+(\w)?(result)?(_corner)?_"
    p2: str = r"_(result_)?[0-9]{14}\.(bin|jpg)"
    scc: str = ""
    for line in text.split(",\n"):
        # print("-" * 30)
        matcher1 = re.search(p1, line, re.IGNORECASE)
        matcher2 = re.search(p2, line, re.IGNORECASE)
        # print(line)
        # if matcher1:
        #     print(matcher1.group())
        # if matcher2:
        #     print(matcher2.group())
        if matcher1 and matcher2:
            print(line.replace(matcher1.group(), "").replace(matcher2.group(), ""))
        # scc = line.replace(matcher1.group(), "").replace(matcher2.group())
        # print(scc)

if __name__ == '__main__':
    main()