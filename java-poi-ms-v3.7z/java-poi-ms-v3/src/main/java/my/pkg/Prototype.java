package my.pkg;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public abstract class Prototype {
    protected String timestampPattern = "_[0-9]{14}";
    protected String fileHeaderPattern = "mesdata[0-9]+(result)?_";
    protected String panelInfixPattern = "_result";
    protected String emptyString = "";
    protected String sccNo = emptyString;
    protected String ext = ".bin";
    protected String delimiter = "_";
    protected TreeMap<String, Path> beforeMap = new TreeMap<>();
    protected TreeMap<String, Path> afterMap = new TreeMap<>();
    protected List<String> sccList = new ArrayList<>();

    public void setSccNo(String sccNo) {
        this.sccNo = sccNo;
    }

    public void setSccList(List<String> sccList) {
        this.sccList = sccList;
    }

    public String getTimestampPattern() {
        return timestampPattern;
    }

    public void setTimestampPattern(String timestampPattern) {
        this.timestampPattern = timestampPattern;
    }

    public String getFileHeaderPattern() {
        return fileHeaderPattern;
    }

    public void setFileHeaderPattern(String fileHeaderPattern) {
        this.fileHeaderPattern = fileHeaderPattern;
    }

    public String getEmptyString() {
        return emptyString;
    }

    public void setEmptyString(String emptyString) {
        this.emptyString = emptyString;
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext;
    }

    public TreeMap<String, Path> getBeforeMap() {
        return beforeMap;
    }

    public void setBeforeMap(Prototype prototype) {
        this.beforeMap = prototype.beforeMap;
    }

    public TreeMap<String, Path> getAfterMap() {
        return afterMap;
    }

    public void setAfterMap(Prototype prototype) {
        this.afterMap = prototype.afterMap;
    }

    public void setPanelInfixPattern(String panelInfixPattern) {
        this.panelInfixPattern = panelInfixPattern;
    }

    public void reset() {
        this.beforeMap.clear();
        this.afterMap.clear();
    }

    public abstract void sort(Path src);

    public abstract void match() throws IOException;

    protected abstract void compareBoth(
            TreeMap<String, Path> beforeMap,
            TreeMap<String, Path> afterMap
    ) throws IOException;

    protected abstract void compare(TreeMap<String, Path> beforeMap) throws IOException;
}
