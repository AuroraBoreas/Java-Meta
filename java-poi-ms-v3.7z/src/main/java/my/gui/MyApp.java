package my.gui;

import my.pkg.Assembler;
import my.pkg.Extractor;
import my.pkg.Worker;
import my.util.Cleaner;
import my.util.CsvParser;
import my.util.MilitaryDateTimer;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class MyApp extends JFrame {
	private final String emptyString = "";
	private JPanel mainPanel;
	private JTextField textFieldSrc;
	private JButton openButtonSrc;
	private JTextField textFieldDst;
	private JButton openButtonDst;
	private JTextField textFieldLineName;
	private JTextField textFieldSetNo;
	private JTextField textFieldDate;
	private JComboBox comboBoxIre;
	private JComboBox comboBoxMethod;
	private JSpinner spinnerInterval;
	private JTextArea textAreaOutput;
	private JButton startButton;
	private JButton resetButton;
	private JPanel sourcePanel;
	private JProgressBar progressBarOutput;
	private JPanel outputPanel;
	private JPanel setupPanel;
	private JPanel basicSetupPanel;
	private JPanel processPanel;
	private JPanel buttonPanel;
	private JPanel footPanel;
	private JLabel footLabel;
	private JTextField textFieldScc;
	private JTextField textFieldSccList;
	private JButton openButtonScc;
	private JComboBox comboBoxWRGB;
	private JComboBox comboBoxLRC;
	private JComboBox comboBoxAdOnOff;

	public MyApp() throws HeadlessException {
		createWindows();
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(MyApp::new);
	}

	private void createWindows() {
		// setup main window
		final int width = 640;
		final int height = 400;
		Point point = GraphicsEnvironment.getLocalGraphicsEnvironment().getCenterPoint();
		setBounds(point.x - width / 2, point.y - height / 2, width, height);
		setLocationRelativeTo(null);
		setTitle("Bonjour");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setSize(width, height);
		setAlwaysOnTop(false);
		setFocusable(false);
		setResizable(false);
		// border
		Border border = BorderFactory.createLineBorder(Color.white, 2, true);
		sourcePanel.setBorder(border);
		setupPanel.setBorder(border);
		outputPanel.setBorder(border);
		footPanel.setBorder(border);
		mainPanel.setBorder(border);
		textAreaOutput.setLineWrap(true);
		textAreaOutput.setAutoscrolls(true);
		// action listeners
		attachActionListeners();
		// init states
		spinnerInterval.setValue(1);
		// go
		add(mainPanel);
	}

	private void attachActionListeners() {
		openButtonSrc.addActionListener(e -> selectDirectoryDialog(textFieldSrc));
		openButtonDst.addActionListener(e -> selectDirectoryDialog(textFieldDst));
		openButtonScc.addActionListener(e -> selectFileDialog(textFieldSccList));

		startButton.addActionListener(e -> {
			if (isValidatedTextFields()) {
				progressBarOutput.setValue(0);
				progressBarOutput.setStringPainted(true);
				footLabel.setText("Processing...");
				startButton.setEnabled(false);
				// setup Extractor
				String lineName = textFieldLineName.getText().isEmpty() ? "na" : textFieldLineName.getText();
				String setNo = textFieldSetNo.getText();
				String workDateTime = MilitaryDateTimer.getMilitaryDateTime();
				String sccNo = textFieldScc.getText();
				String ire = comboBoxIre.getSelectedItem().toString();
				String wrgb = comboBoxWRGB.getSelectedItem().toString();
				String lrc = comboBoxLRC.getSelectedItem().toString();
				String adOnOff = comboBoxAdOnOff.getSelectedItem().toString();
				Assembler assembler = new Assembler(ire, wrgb, lrc, adOnOff);
				int compMethod = comboBoxMethod.getSelectedIndex();
				int interval = (Integer) spinnerInterval.getValue();
				Extractor extractor;
				try {
					extractor = new Extractor(
							textFieldSrc.getText(),
							setNo.toLowerCase(),
							textFieldDate.getText(),
							assembler, compMethod, interval);
				} catch (IOException exp) {
					throw new RuntimeException(exp);
				}
				CsvParser csvParser = new CsvParser(textFieldSccList.getText());
				csvParser.get2dArray();
				if (sccNo.length() > 1)
					csvParser.getFlattenRecords().add(sccNo);
				extractor.setSccList(csvParser.getFlattenRecords());
				// setup Worker
				String folderPath = textFieldDst.getText();
				String savedFileName = "%s\\%s_%s_%s_Mura_Image_List_MesData%s.xlsx".formatted(
						folderPath, workDateTime,
						lineName.toUpperCase(), setNo.toUpperCase(),
						assembler.toString());
				Worker worker = new Worker(extractor, lineName, workDateTime, savedFileName);
				SwingWorker<Void, Void> swingWorker = new SwingWorker<>() {
					@Override
					protected Void doInBackground() throws Exception {
						worker.search();
						return null;
					}

					@Override
					protected void done() {
						textAreaOutput.setText(textAreaOutput.getText() + worker + "\n");
						SwingWorker<Void, Integer> swingCounter = new SwingWorker<>() {
							@Override
							protected Void doInBackground() throws Exception {
								for (int i = 0; i <= 100; i++) {
									Thread.sleep(50);
									publish(i);
								}
								return null;
							}

							@Override
							protected void process(List<Integer> chunks) {
								int value = chunks.get(chunks.size() - 1);
								progressBarOutput.setValue(value);
							}

							@Override
							protected void done() {
								Cleaner.clean(extractor.getDst().toString());
								footLabel.setText("Finished!");
								startButton.setEnabled(true);
							}
						};
						swingCounter.execute();
					}
				};
				swingWorker.execute();
			} else {
				footLabel.setText("Aborted!");
			}
		});

		resetButton.addActionListener(e -> {
			textFieldSrc.setText(emptyString);
			textFieldSrc.setBackground(Color.white);
			textFieldDst.setText(emptyString);
			textFieldDst.setBackground(Color.white);
			textFieldSccList.setText(emptyString);
			textFieldLineName.setText(emptyString);
			textFieldLineName.setBackground(Color.white);
			textFieldSetNo.setText(emptyString);
			textFieldSetNo.setBackground(Color.white);
			textFieldDate.setText(emptyString);
			textFieldDate.setBackground(Color.white);
			textFieldScc.setText(emptyString);
			comboBoxIre.setSelectedIndex(1);
			comboBoxMethod.setSelectedIndex(0);
			spinnerInterval.setValue(1);
			comboBoxWRGB.setSelectedIndex(0);
			comboBoxLRC.setSelectedIndex(0);
			comboBoxAdOnOff.setSelectedIndex(0);
			if (startButton.isEnabled())
				footLabel.setText("TV QA: blah blah blah");
		});
	}

	private boolean isValidatedTextFields() {
		if (textFieldSrc.getText().length() < 1 || !Files.isDirectory(Paths.get(textFieldSrc.getText()))) {
			textFieldSrc.setBackground(Color.red);
		} else {
			textFieldSrc.setBackground(Color.white);
		}

		if (textFieldDst.getText().length() < 1 || !Files.isDirectory(Paths.get(textFieldDst.getText()))) {
			textFieldDst.setBackground(Color.red);
		} else {
			textFieldDst.setBackground(Color.white);
		}

		if (textFieldSccList.getText().isBlank()) {
			textFieldSccList.setText(emptyString);
		}

		if (textFieldScc.getText().isBlank()) {
			textFieldScc.setText(emptyString);
		}

		if (textFieldLineName.getText().length() < 1) {
			textFieldLineName.setText(emptyString);
		} else {
			textFieldLineName.setBackground(Color.white);
		}

		if (textFieldSetNo.getText().length() < 7 || textFieldSetNo.getText().length() > 9) {
			textFieldSetNo.setBackground(Color.red);
		} else {
			textFieldSetNo.setBackground(Color.white);
		}

		if (textFieldDate.getText().length() != 8) {
			textFieldDate.setText(emptyString);
		} else {
			textFieldDate.setBackground(Color.white);
		}

		if (textFieldSrc.getBackground() == Color.red ||
				textFieldDst.getBackground() == Color.red ||
				textFieldSetNo.getBackground() == Color.red
		) {
			JOptionPane.showMessageDialog(this,
					"Eggs are not supposed to be green.",
					"Inane error",
					JOptionPane.ERROR_MESSAGE);
			return false;
		} else {
			return true;
		}
	}

	private void selectDirectoryDialog(JTextField textField) {
		JFileChooser fileChooser = new JFileChooser(FileSystemView.getFileSystemView());
		fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		int option = fileChooser.showOpenDialog(this);
		if (option == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			textField.setText(file.getAbsolutePath());
		} else {
			textField.setText(emptyString);
		}
	}

	private void selectFileDialog(JTextField textField) {
		JFileChooser fileChooser = new JFileChooser(FileSystemView.getFileSystemView());
		fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		int option = fileChooser.showOpenDialog(this);
		if (option == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			textField.setText(file.getAbsolutePath());
		} else {
			textField.setText(emptyString);
		}
	}

	private void createUIComponents() {
		Integer[] ires = {1, 2, 3, 4, 5, 1023, 896, 768, 640, 512, 384, 256, 128};
		comboBoxIre = new JComboBox(ires);
		comboBoxIre.setSelectedIndex(1);
		String[] methods = {"both", "before", "after"};
		comboBoxMethod = new JComboBox(methods);
		comboBoxMethod.setSelectedIndex(0);
		String[] wrgb = {"w", "r", "g", "b"};
		comboBoxWRGB = new JComboBox(wrgb);
		comboBoxWRGB.setSelectedIndex(0);
		String[] lrc = {"none", "left", "right", "corner"};
		comboBoxLRC = new JComboBox(lrc);
		comboBoxLRC.setSelectedIndex(0);
		String[] AdOnOff = {"none", "ad_on", "ad_off"};
		comboBoxAdOnOff = new JComboBox(AdOnOff);
		comboBoxAdOnOff.setSelectedIndex(0);
	}
}
