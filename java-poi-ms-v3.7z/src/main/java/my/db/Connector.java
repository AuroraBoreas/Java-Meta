package my.db;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;

public class Connector {
    private final String dbName;
    private Connection conn;

    public Connector(String dbName) {
        this.dbName = dbName;
    }

    /**
     * This method connects to local sqlite database
     *
     * @throws SQLException           If connection fails.
     * @throws ClassNotFoundException If sqlite JDBC is not found.
     */
    public void connect() {
        Connection conn = null;
        try {
            Class.forName("org.sqlite.JDBC");
            // + you have to manually add sqlite.jar to your artifacts as an extracted directory @ZL, 20230518
            String url = "jdbc:sqlite:" + dbName;
            conn = DriverManager.getConnection(url);
        } catch (SQLException | ClassNotFoundException ignore) {
        }
        this.conn = conn;
    }

    /**
     * This method creates a table in sqlite database
     *
     * @throws SQLException If creating table operation fails.
     */
    public void createNewTable() {
        String sql = """
                CREATE TABLE IF NOT EXISTS reports (
                     id integer PRIMARY KEY,
                     lineName text NOT NULL,
                     setNo text NOT NULL,
                     date text,
                     ire text,
                     method text,
                     interval integer,
                     file BLOB
                );""";
        try {
            Statement stmt = conn.createStatement();
            stmt.execute(sql);
        } catch (SQLException ignored) {
        }
    }

    /**
     * @param lineName product line name
     * @param setNo    product A number
     * @param date     production date
     * @param ire      Mura Adjustment pattern(gray scale 1 ~ 1023)
     * @param method   Either comparing before and after Mura Adjustment(0), or check before(1) or after(2) only
     * @param interval Sampling interval
     * @param file     an Excel file that has Mura simulation images
     */
    public void insert(
            String lineName,
            String setNo,
            String date,
            String ire,
            String method,
            int interval,
            String file
    ) {
        String sql = """
                INSERT INTO reports(lineName,setNo,date,ire,method,interval,file)
                VALUES(?,?,?,?,?,?,?);""";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, lineName);
            stmt.setString(2, setNo);
            stmt.setString(3, date);
            stmt.setString(4, ire);
            stmt.setString(5, method);
            stmt.setInt(6, interval);
            stmt.setBytes(7, readFileToBytes(file));
            stmt.executeUpdate();
        } catch (SQLException ignored) {
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void selectAll() {
        String sql = """
                SELECT * FROM reports
                ORDER BY id DESC
                LIMIT 1;
                """;
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                System.out.println(rs.getInt("id") + "\t" +
                        rs.getString("lineName") + "\t" +
                        rs.getString("setNo"));
            }
        } catch (SQLException ignored) {
        }
    }

    /**
     * This method reads a file into {@code byte}, the bytes will be stored in sqlite database later
     *
     * @param file File path
     * @return a byte array
     * @throws IOException If file is not found or does not exist or is not readable
     */
    private byte[] readFileToBytes(String file) throws IOException {
        return Files.readAllBytes(Paths.get(file));
    }


    /**
     * This method writes a byte array into an Excel file.
     *
     * @param data          a byte array.
     * @param savedFileName the path of an Excel file
     */
    private void writeBytesToFile(byte[] data, String savedFileName) {
        File file = new File(savedFileName);
        try (OutputStream os = new FileOutputStream(file)) {
            os.write(data);
        } catch (IOException ignore) {
        }
    }

    public void close() throws SQLException {
        this.conn.close();
    }
}