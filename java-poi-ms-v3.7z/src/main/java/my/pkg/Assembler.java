package my.pkg;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Assembler {
	private final String emptyString = "";
	private final String aNoSccPattern = "[a-zA-Z0-9]{8,9}_[0-9]{1,7}";
	private String ire;
	private String wrgb;
	private String position;
	private String adOnOff;

	public Assembler(String ire) {
		this(ire, "w", "none", "none");
	}

	public Assembler(String ire, String wrgb, String position, String adOnOff) {
		this.ire = ire.toLowerCase();
		this.wrgb = wrgb.toLowerCase();
		this.position = position.toLowerCase();
		this.adOnOff = adOnOff.toLowerCase();
	}

	public String assemblePrefixMesData() {
		return "mesdata%s%s%s_".formatted(ire, getWrgb(), getPosition());
	}

	public String assemblePrefixMesDataResult() {
		return "mesdata%s%sresult%s_".formatted(ire, getWrgb(), getPosition());
	}

	public String getIre() {
		return ire;
	}

	public void setIre(String ire) {
		this.ire = ire;
	}

	public String getWrgb() {
		return wrgb.equalsIgnoreCase("w") ? emptyString : wrgb;
	}

	public void setWrgb(String wrgb) {
		this.wrgb = wrgb;
	}

	public String getPosition() {
		return position.equalsIgnoreCase("none") ? emptyString : "_" + position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getAdOnOff() {
		return adOnOff.equalsIgnoreCase("none") ? emptyString : adOnOff;
	}

	public void setAdOnOff(String adOnOff) {
		this.adOnOff = adOnOff;
	}

	public String assembleAdOnOffOriginal() {
		return adOnOff.equalsIgnoreCase("none") ? emptyString : adOnOff + "_original";
	}

	public String assembleAdOnOffResult() {
		return adOnOff.equalsIgnoreCase("none") ? emptyString : adOnOff + "_result";
	}

	public boolean isBeforeAdj(String fileName) {
		Disassembler disassembler = new Disassembler(fileName);
		Pattern prefix = Pattern.compile("^" + assemblePrefixMesData() + aNoSccPattern, Pattern.CASE_INSENSITIVE);
		Matcher matcher = prefix.matcher(fileName.toLowerCase());
		return matcher.find() && (
				disassembler.getResidue().chars().filter(ch -> ch == '_').count() == 1L ||
						disassembler.getResidue().contains(assembleAdOnOffOriginal())
		);
	}

	public boolean isAfterAdj(String fileName) {
		Disassembler disassembler = new Disassembler(fileName);
		Pattern prefix = Pattern.compile("^" + assemblePrefixMesDataResult() + aNoSccPattern, Pattern.CASE_INSENSITIVE);
		Matcher matcher = prefix.matcher(fileName.toLowerCase());
		return matcher.find() &&
				disassembler.getResidue().contains(assembleAdOnOffResult());
	}

	@Override
	public String toString() {
		return "(%1$s_%2$s_%3$s_%4$s)".formatted(ire, wrgb, position, adOnOff);
	}
}