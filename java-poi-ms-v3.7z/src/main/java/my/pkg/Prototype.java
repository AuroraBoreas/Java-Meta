package my.pkg;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public abstract class Prototype {
	protected Disassembler disassembler;
	protected Assembler assembler;
	protected String emptyString = "";
	protected TreeMap<String, Path> beforeMap = new TreeMap<>();
	protected TreeMap<String, Path> afterMap = new TreeMap<>();
	protected List<String> sccList = new ArrayList<>();

	public Assembler getAssembler() {
		return assembler;
	}

	public void setAssembler(Assembler assembler) {
		this.assembler = assembler;
	}

	public void setSccList(List<String> sccList) {
		this.sccList = sccList;
	}

	public TreeMap<String, Path> getBeforeMap() {
		return beforeMap;
	}

	public void setBeforeMap(Prototype prototype) {
		this.beforeMap = prototype.beforeMap;
	}

	public TreeMap<String, Path> getAfterMap() {
		return afterMap;
	}

	public void setAfterMap(Prototype prototype) {
		this.afterMap = prototype.afterMap;
	}

	public void reset() {
		this.beforeMap.clear();
		this.afterMap.clear();
	}

	public abstract void sort(Path src);

	public abstract void match() throws IOException;

	protected abstract void compare(
			TreeMap<String, Path> beforeMap,
			TreeMap<String, Path> afterMap
	) throws IOException;

	protected abstract void compare(TreeMap<String, Path> beforeMap) throws IOException;
}
