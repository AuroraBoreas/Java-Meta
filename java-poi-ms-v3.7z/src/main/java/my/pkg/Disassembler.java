package my.pkg;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Disassembler {
	private String fileHeaderPattern = "mesdata\\d+[rgb]?(result)?(_right|_left|_corner)?_";
	private String fileTailPattern = "_(ad_)?(on_|off_)?(original_|result_)?[0-9]{14}.(bin|jpg)";
	private String fileHeader;
	private String fileTail;
	private String aNo_Scc;
	private String Scc;
	private String residue;

	public Disassembler(String fileName) {
		dissect(fileName);
	}

	public String getResidue() {
		return residue;
	}

	public String getScc() {
		return Scc;
	}

	public String getFileHeaderPattern() {
		return fileHeaderPattern;
	}

	public void setFileHeaderPattern(String fileHeaderPattern) {
		this.fileHeaderPattern = fileHeaderPattern;
	}

	public String getFileTailPattern() {
		return fileTailPattern;
	}

	public void setFileTailPattern(String fileTailPattern) {
		this.fileTailPattern = fileTailPattern;
	}

	public String getFileHeader() {
		return fileHeader;
	}

	public String getFileTail() {
		return fileTail;
	}

	public String getaNo_Scc() {
		return aNo_Scc;
	}

	/**
	 * This method returns nothing
	 *
	 * <p> disassemble filename into parts using regex </>
	 *
	 * @throws IndexOutOfBoundsException If Scc No index is not 1.
	 */
	public void dissect(String fileName) {
		String lowered = fileName.toLowerCase();
		final String emptyString = "";
		final String delimiter = "_";
		int sccIndex = 1;
		final String fileTailLess = "_[0-9]{14}.(bin|jpg)";
		Pattern headPattern = Pattern.compile(fileHeaderPattern, Pattern.CASE_INSENSITIVE);
		Pattern tailPattern = Pattern.compile(fileTailPattern, Pattern.CASE_INSENSITIVE);
		Matcher matcher = headPattern.matcher(lowered);
		fileHeader = matcher.find() ? matcher.group() : emptyString;
		matcher = tailPattern.matcher(lowered);
		fileTail = matcher.find() ? matcher.group() : emptyString;
		aNo_Scc = lowered
				.replaceAll(fileHeaderPattern, emptyString)
				.replaceAll(fileTailPattern, emptyString)
				.toUpperCase();
		residue = lowered
				.replaceAll(fileHeaderPattern, emptyString)
				.replaceAll(fileTailLess, emptyString);
		try {
			Scc = aNo_Scc.split(delimiter)[sccIndex];
		} catch (IndexOutOfBoundsException ignore) {
		}
	}

	@Override
	public String toString() {
		return "%-20s %-20s %-20s".formatted(fileHeader, aNo_Scc, fileTail);
	}
}
