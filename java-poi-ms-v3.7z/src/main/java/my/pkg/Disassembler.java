package my.pkg;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Disassembler {
    private String fileHeaderPattern = "mesdata\\d+(\\w)?(result)?(_corner)?_";
    private String fileTailPattern = "_(result_)?[0-9]{14}.(bin|jpg)";
    private String fileName;
    private String fileHeader;
    private String fileTail;
    private String aNo_Scc;
    private String Scc;

    public Disassembler(String fileName) {
        this.fileName = fileName;
    }

    public String getScc() {
        return Scc;
    }

    public String getFileHeaderPattern() {
        return fileHeaderPattern;
    }

    public void setFileHeaderPattern(String fileHeaderPattern) {
        this.fileHeaderPattern = fileHeaderPattern;
    }

    public String getFileTailPattern() {
        return fileTailPattern;
    }

    public void setFileTailPattern(String fileTailPattern) {
        this.fileTailPattern = fileTailPattern;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileHeader() {
        return fileHeader;
    }

    public String getFileTail() {
        return fileTail;
    }

    public String getaNo_Scc() {
        return aNo_Scc;
    }

    /**
     * This method returns nothing
     *
     * <p> disassemble filename into parts using regex </>
     *
     * @throws IndexOutOfBoundsException If Scc No index is not 1.
     */
    public void dissect() {
        String emptyString = "";
        String delimiter = "_";
        int sccIndex = 1;
        Pattern headPattern = Pattern.compile(fileHeaderPattern, Pattern.CASE_INSENSITIVE);
        Pattern tailPattern = Pattern.compile(fileTailPattern, Pattern.CASE_INSENSITIVE);
        Matcher matcher = headPattern.matcher(fileName);
        fileHeader = matcher.find() ? matcher.group() : emptyString;
        matcher = tailPattern.matcher(fileName);
        fileTail = matcher.find() ? matcher.group() : emptyString;
        aNo_Scc = fileName.toLowerCase()
                .replaceAll(fileHeaderPattern, emptyString)
                .replaceAll(fileTailPattern, emptyString)
                .toUpperCase();
        try {
            Scc = aNo_Scc.split(delimiter)[sccIndex];
        } catch (IndexOutOfBoundsException ignore) {
        }
    }

    @Override
    public String toString() {
        return "%-20s %-20s %-20s".formatted(fileHeader, aNo_Scc, fileTail);
    }
}
