package my.pkg;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Extractor extends Prototype {
    private final int bothFlag = 0;
    private final int beforeFlag = 1;
    private final int afterFlag = 2;
    // setup filter parts
    private final String ire;
    private Path src;
    private Path dst;
    private String prefixMesData;
    private String prefixMesDataResult;
    private String setNo;
    private String productDate;
    private String ext = ".bin";
    private int sampleInterval;
    private int compMethod;

    public Extractor(
            String src,
            String setNo,
            String productDate,
            String ire,
            int compMethod,
            int sampleInterval
    ) throws IOException {
        this.src = Paths.get(src);
        this.dst = Files.createTempDirectory(".tempBinDir").toAbsolutePath();
        this.ire = ire;
        this.prefixMesData = "mesdata%s_".formatted(ire);
        this.prefixMesDataResult = "mesdata%sresult_".formatted(ire);
        this.setNo = (setNo.length() < 7 || setNo.length() > 9) ? emptyString : setNo;
        this.productDate = productDate.length() != 8 ? emptyString : productDate;
        this.compMethod = compMethod < bothFlag || compMethod > afterFlag ? afterFlag : compMethod;
        this.sampleInterval = Math.max(sampleInterval, 1);
    }

    public Extractor(String src, String setNo, String productDate) throws IOException {
        this(src, setNo, productDate, "2", 2, 1);
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext;
    }

    public String getIre() {
        return ire;
    }

    public void setPrefixMesData(String prefixMesData) {
        this.prefixMesData = prefixMesData;
    }

    public String getMesData() {
        return prefixMesData;
    }

    public void setMesData(String prefixMesData) {
        this.prefixMesData = prefixMesData;
    }

    public String getMesDataResult() {
        return prefixMesDataResult;
    }

    public void setMesDataResult(String prefixMesDataResult) {
        this.prefixMesDataResult = prefixMesDataResult;
    }

    public String getSetNo() {
        return setNo;
    }

    public void setSetNo(String setNo) {
        this.setNo = setNo;
    }

    public String getProductDate() {
        return productDate;
    }

    public void setProductDate(String productDate) {
        this.productDate = productDate;
    }

    public int getSampleInterval() {
        return sampleInterval;
    }

    public void setSampleInterval(int sampleInterval) {
        this.sampleInterval = sampleInterval;
    }

    public int getCompMethod() {
        return compMethod;
    }

    public void setCompMethod(int compMethod) {
        this.compMethod = compMethod;
    }

    public Path getSrc() {
        return src;
    }

    public void setSrc(Path src) {
        this.src = src;
    }

    public Path getDst() {
        return dst;
    }

    public void setDst(Path dst) {
        this.dst = dst;
    }

    /**
     * This method sorts file names using Stream.
     *
     * @param src The source folder that contains *.ext files.
     */
    public void sort(Path src) {
        long beg = System.nanoTime();
        try (Stream<Path> walk = Files.walk(src)) {
//            walk.filter(getPathPredicate())
//                    .sorted(Comparator.reverseOrder())
//                    .forEachOrdered(getPathConsumer());
            Stream<Path> sp = walk.toList()
                    .parallelStream()
                    .filter(getPathPredicate());
            sp.sorted(Comparator.reverseOrder())
                    .forEachOrdered(getPathConsumer());
        } catch (IOException ignore) {
        }
        long duration = System.nanoTime() - beg;
        double ms = TimeUnit.MILLISECONDS.convert(duration, TimeUnit.NANOSECONDS);
        System.out.println("parallel performance(ms) -> " + ms);
    }

    private Consumer<Path> getPathConsumer() {
        return x -> {
            String fileName = x.getFileName().toString().toLowerCase();
            this.disassembler = new Disassembler(fileName);
            disassembler.dissect();
            String aNo_Scc = disassembler.getaNo_Scc();
            boolean cond1 = fileName.startsWith(prefixMesData);
            boolean cond2 = fileName.startsWith(prefixMesDataResult);
            boolean cond3 = isSccIncluded(disassembler.getScc());
            switch (compMethod) {
                case bothFlag -> {
                    if (cond1 && cond3 && !beforeMap.containsKey(aNo_Scc)) {
                        beforeMap.put(aNo_Scc, x);
                    }
                    if (cond2 && cond3 && !afterMap.containsKey(aNo_Scc)) {
                        afterMap.put(aNo_Scc, x);
                    }
                }
                case beforeFlag -> {
                    if (cond1 && cond3 && !beforeMap.containsKey(aNo_Scc))
                        beforeMap.put(aNo_Scc, x);
                }
                default -> {
                    if (cond2 && cond3 && !afterMap.containsKey(aNo_Scc))
                        afterMap.put(aNo_Scc, x);
                }
            }
        };
    }

    /**
     * Return {@code true} if aNo_Scc contains Scc No else {@code false}
     *
     * @param scc The format of sccNo is 7 digit places with leading 0 padded
     * @return boolean
     */
    private boolean isSccIncluded(String scc) {
        return (sccList.isEmpty() || sccList.contains(scc));
    }

    private Predicate<Path> getPathPredicate() {
        return x -> {
            String fileName = x.getFileName().toString().toLowerCase();
            return (fileName.startsWith(prefixMesData) || fileName.startsWith(prefixMesDataResult)) &&
                    fileName.endsWith(ext) &&
                    fileName.contains(setNo) &&
                    fileName.contains(productDate);
        };
    }

    /**
     * This method matches before Mura Adjustment and after Mura Adjustment files by ANo_Scc
     *
     * @throws IOException If files are not found or readable.
     */
    public void match() throws IOException {
        if (!beforeMap.isEmpty() && !afterMap.isEmpty()) {
            this.compMethod = bothFlag;
        } else {
            if (!beforeMap.isEmpty()) {
                this.compMethod = beforeFlag;
            }
            if (!afterMap.isEmpty()) {
                this.compMethod = afterFlag;
            }
        }
        switch (compMethod) {
            case bothFlag -> compare(beforeMap, afterMap);
            case beforeFlag -> compare(beforeMap);
            default -> compare(afterMap);
        }
    }

    /**
     * This method compares before and after Mura Adjustment files
     *
     * @param beforeMap {@code TreeMap} contains {@code Path} of before Mura Adjustment files(.bin or .jpg)
     * @param afterMap  {@code TreeMap} contains {@code Path} of after Mura Adjustment files(.bin or .jpg)
     * @throws IOException If files are not found or do not exist
     */
    protected void compare(
            TreeMap<String, Path> beforeMap,
            TreeMap<String, Path> afterMap
    ) throws IOException {
        String key;
        int i = 0;
        for (Map.Entry<String, Path> entry : beforeMap.entrySet()) {
            key = entry.getKey();
            if (afterMap.containsKey(key) && (i % sampleInterval == 0)) {
                Files.copy(beforeMap.get(key), dst.resolve(beforeMap.get(key).getFileName()), StandardCopyOption.REPLACE_EXISTING);
                Files.copy(afterMap.get(key), dst.resolve(afterMap.get(key).getFileName()), StandardCopyOption.REPLACE_EXISTING);
            }
            i++;
        }
    }

    /**
     * This method compares before or after Mura Adjustment files
     *
     * @param map {@code TreeMap} contains {@code Path} of before or after Mura Adjustment files
     * @throws IOException If files are not found or do not exist.
     */
    protected void compare(TreeMap<String, Path> map) throws IOException {
        int i = 0;
        List<Path> list = new ArrayList<>(map.values());
        list.sort(Comparator.reverseOrder());
        for (Path e : list) {
            if (i % sampleInterval == 0) {
                Files.copy(e, dst.resolve(e.getFileName()), StandardCopyOption.REPLACE_EXISTING);
            }
            i++;
        }
    }

    @Override
    public String toString() {
        return "Extractor{" +
                "beforeQty=" + beforeMap.size() +
                ", afterQty=" + afterMap.size() +
                '}';
    }
}
