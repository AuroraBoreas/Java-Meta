package my.pkg;

import my.db.Connector;

import java.io.IOException;
import java.sql.SQLException;

public class Worker implements Simulator {
    private final Extractor extractor;
    private final String toFileName;
    private final String workDateTime;
    private final String lineName;

    public Worker(Extractor e, String lineName, String workDateTime, String savedFileName) {
        this.extractor = e;
        this.lineName = lineName;
        this.workDateTime = workDateTime;
        this.toFileName = savedFileName;
    }

    /**
     * This method connects a local sqlite database, and stores data into it.
     */
    private void saveToDatabase() {
        Connector connector = new Connector("data.db");
        connector.connect();
        connector.createNewTable();
        connector.insert(lineName,
                extractor.getSetNo(),
                workDateTime,
                extractor.getIre(),
                Integer.valueOf(extractor.getCompMethod()).toString(),
                extractor.getSampleInterval(),
                toFileName);
        try {
            connector.close();
        } catch (SQLException ignore) {
        }
    }

    public void search() throws IOException, InterruptedException {
        extractor.sort(extractor.getSrc());
        extractor.match();
        convert();
        extractor.setExt(".jpg");
        extractor.reset();
        extractor.sort(extractor.getDst());
        Reporter.start(toFileName, extractor);
        saveToDatabase();
    }

    /**
     * Implements interface method that converts *.bin to *.jpg
     *
     * @throws InterruptedException If the C# console app fails file conversion
     * @throws IOException          If file is not found or does not exist
     */
    @Override
    public void convert() throws InterruptedException, IOException {
        String executable = "PLRLogger.exe";
        Process p = Runtime.getRuntime().exec(executable + " " + extractor.getDst().toString());
        p.waitFor();
    }

    @Override
    public String toString() {
        return extractor.toString();
    }
}
