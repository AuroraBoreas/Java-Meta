package my.pkg;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.Map;

public class Reporter {

	/**
	 * Load Mura simulation image files (*.jpg) into an Excel on the fly.
	 *
	 * @param dstFileName an Excel file
	 * @param p           {@code Prototype} an Extractor object
	 */
	public static void start(String dstFileName, Prototype p) {
		try (Workbook workbook = new XSSFWorkbook()) {
			// setup sheet, headers
			String sheetName = "Result";
			Sheet sheet = workbook.createSheet(sheetName);
			setSheetColumnWidth(sheet);
			Row header = sheet.createRow(0);
			setHeaders(header);
			// load image
			int beforeColumn = 2, afterColumn = 3;
			float height = 104.5f;
			if (!p.getBeforeMap().isEmpty() && !p.getAfterMap().isEmpty()) {
				load(p, workbook, sheet, beforeColumn, afterColumn, height);
			} else {
				if (!p.getBeforeMap().isEmpty()) {
					load(p.getBeforeMap(), workbook, sheet, beforeColumn, height);
				}
				if (!p.getAfterMap().isEmpty()) {
					load(p.getAfterMap(), workbook, sheet, afterColumn, height);
				}
			}
			try (FileOutputStream saveExcel = new FileOutputStream(dstFileName)) {
				workbook.write(saveExcel);
			} catch (IOException ignore) {
			}
		} catch (IOException ignore) {
		}
	}

	/**
	 * This method load an image file (before or after) into a Workbook
	 *
	 * @param map      {@code TreeMap} which contains aNo_Scc and its Mura simulation image file path.
	 * @param workbook an Excel workbook
	 * @param sheet    an Excel worksheet
	 * @param column   a column index
	 * @param height   row height
	 * @throws IOException If file is not found or does not exist
	 */
	private static void load(
			Map<String, Path> map,
			Workbook workbook,
			Sheet sheet,
			int column,
			float height
	) throws IOException {
		String key;
		Row row;
		int i = 1;
		CellStyle cellStyle = getCellStyle(workbook);
		Cell cell;
		for (Map.Entry<String, Path> entry : map.entrySet()) {
			key = entry.getKey();
			row = sheet.createRow(i);
			row.setHeightInPoints(height);
			row.createCell(0).setCellValue(i); // No
			row.createCell(1).setCellValue(key); // log file name;
			cell = row.createCell(column);
			cell.setCellValue(map.get(key).getFileName().toString());
			cell.setCellStyle(cellStyle);
			loadImageIntoWorksheet(workbook, sheet, map.get(key).toAbsolutePath().toString(), i, column); // before or after adj Mura image
			i++;
		}
	}

	/**
	 * This method load an image file (before and after) into a Workbook
	 *
	 * @param p            {@code Prototype} an Extractor
	 * @param workbook     an Excel workbook
	 * @param sheet        an Excel worksheet
	 * @param beforeColumn a column index
	 * @param afterColumn  a column index
	 * @param height       row height
	 * @throws IOException If file is not found or does not exist
	 */
	private static void load(
			Prototype p,
			Workbook workbook,
			Sheet sheet,
			int beforeColumn,
			int afterColumn,
			float height
	) throws IOException {
		String key;
		Row row;
		int i = 1;
		CellStyle cellStyle = getCellStyle(workbook);
		Cell cell;
		for (Map.Entry<String, Path> entry : p.getBeforeMap().entrySet()) {
			key = entry.getKey();
			if (p.getAfterMap().containsKey(key)) {
				row = sheet.createRow(i);
				row.setHeightInPoints(height);
				row.createCell(0).setCellValue(i);   // No
				row.createCell(1).setCellValue(key); // log file name;
				cell = row.createCell(beforeColumn);
				cell.setCellValue(p.getBeforeMap().get(key).getFileName().toString());
				cell.setCellStyle(cellStyle);
				cell = row.createCell(afterColumn);
				cell.setCellValue(p.getAfterMap().get(key).getFileName().toString());
				cell.setCellStyle(cellStyle);
				loadImageIntoWorksheet(workbook, sheet, p.getBeforeMap().get(key).toAbsolutePath().toString(), i, beforeColumn); // before adj Mura image
				loadImageIntoWorksheet(workbook, sheet, p.getAfterMap().get(key).toAbsolutePath().toString(), i, afterColumn); // after adj Mura image
				i++;
			}
		}
	}

	private static CellStyle getCellStyle(Workbook workbook) {
		Font font = workbook.createFont();
		font.setFontHeightInPoints((short) 2);
		CellStyle cellStyle = workbook.createCellStyle();
		cellStyle.setFont(font);
		return cellStyle;
	}

	/**
	 * This method sets up the headers of an Excel workbook
	 *
	 * @param header an Excel Row object
	 */
	private static void setHeaders(Row header) {
		header.createCell(0).setCellValue("No");
		header.createCell(1).setCellValue("LogScc");
		header.createCell(2).setCellValue("BeforeAdj");
		header.createCell(3).setCellValue("AfterAdj");
		header.setHeightInPoints(14.5f);
	}

	/**
	 * This method sets up column width.
	 *
	 * @param sheet an Excel worksheet
	 */
	private static void setSheetColumnWidth(Sheet sheet) {
		final int width = 32 * 256;
		sheet.setColumnWidth(1, width);
		sheet.setColumnWidth(2, width);
		sheet.setColumnWidth(3, width);
	}

	/**
	 * This method converts a single image to a byte array then load into an Excel worksheet.
	 *
	 * @param workbook    an Excel workbook object
	 * @param sheet       an Excel worksheet object
	 * @param name        a Mura simulation image file path
	 * @param firstRow    an Excel row index
	 * @param firstColumn an Excel column index
	 */
	private static void loadImageIntoWorksheet(
			Workbook workbook,
			Sheet sheet,
			String name,
			int firstRow,
			int firstColumn
	) {
		try (InputStream inputStream = new FileInputStream(name)) {
			// assert inputStream != null;
			byte[] inputImageBytes = IOUtils.toByteArray(inputStream);
			int inputImagePictureID = workbook.addPicture(inputImageBytes, Workbook.PICTURE_TYPE_PNG);
			XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
			XSSFClientAnchor anchor = new XSSFClientAnchor();
			anchor.setRow1(firstRow);        // Sets the row (0 based) of the first cell.
			anchor.setRow2(firstRow + 1);    // Sets the row (0 based) of the Second cell.
			anchor.setCol1(firstColumn);     // Sets the column (0 based) of the first cell.
			anchor.setCol2(firstColumn + 1); // Sets the column (0 based) of the Second cell.
			drawing.createPicture(anchor, inputImagePictureID);
		} catch (IOException ignore) {
		}
	}
}