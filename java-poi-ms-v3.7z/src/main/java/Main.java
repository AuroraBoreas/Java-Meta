import my.gui.MyApp;
import my.util.MilitaryDateTimer;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        if (MilitaryDateTimer.getMilitaryDateTime().compareTo("20250401") < 1) {
            SwingUtilities.invokeLater(MyApp::new);
        }
    }
}