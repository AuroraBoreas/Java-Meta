package my.pkg;

import org.junit.jupiter.api.*;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;

@TestInstance(TestInstance.Lifecycle.PER_METHOD)
class DisassemblerTest {
	private Disassembler disassembler;

	@BeforeEach
	void setUp() {
		disassembler = new Disassembler("MesData640GResult_A5052876A_0000112_20230221143220.bin");
		System.out.println("setUp");
	}

	@AfterEach
	void tearDown() {
		System.out.println("tearDown");
	}

	@Test
	@DisplayName("getFileHeaderPattern should return the correct pattern")
	void getFileHeaderPattern() {
		Assertions.assertEquals("mesdata\\d+[rgb]?(result)?(_right|_left|_corner)?_", disassembler.getFileHeaderPattern());
	}

	@Test
	@DisplayName("getFileTailPattern should return the correct pattern")
	void getFileTailPattern() {
		Assertions.assertEquals("_(ad_)?(on_|off_)?(original_|result_)?[0-9]{14}.(bin|jpg)", disassembler.getFileTailPattern());
	}

	@Test
	@DisplayName("getFileHeader should return the correct file header")
	void getFileHeader() {
		Assertions.assertEquals("mesdata640gresult_", disassembler.getFileHeader());
	}

	@Test
	@DisplayName("getFileTail should return the correct file tail")
	void getFileTail() {
		Assertions.assertEquals("_20230221143220.bin", disassembler.getFileTail());
	}

	@Test
	@DisplayName("getaNo_Scc should return the correct aNo_Scc")
	void getaNo_Scc() {
		Assertions.assertEquals("A5052876A_0000112", disassembler.getaNo_Scc());
	}


	@Test
	@DisplayName("getScc method should return correct result")
	void getSccMethodShouldReturnCorrectResult() {
		Assertions.assertEquals("0000112", disassembler.getScc());
	}

	@Test
	@DisplayName("getResidue should return correct result")
	void getResidueShouldReturnCorrectResult() {
		List<String> list = new ArrayList<>(List.of(
				"MesData128_A5052876A_0000031_20230206145959.bin",
				"MesData128Result_A5052876A_0000004_Result_20230206110717.bin",
				"MesData128_T5040452A_0000091_AD_OFF_Original_20211028191801.bin",
				"MesData128Result_T5040452A_0000091_AD_OFF_Result_20211028191857.bin"
		));
		List<String> residues = new ArrayList<>(list.size());
		Disassembler disassembler1;
		for (String fileName : list) {
			disassembler1 = new Disassembler(fileName);
			residues.add(disassembler1.getResidue());
		}
		assertThat(residues, hasItems(
				"a5052876a_0000031",
				"a5052876a_0000004_result",
				"t5040452a_0000091_ad_off_original",
				"T5040452A_0000091_AD_OFF_Result".toLowerCase()
		));
	}

	@Test
	@DisplayName("dissect should return the correct result")
	void dissect() {
		List<String> list = new ArrayList<>(List.of(
				"MesData128_A5052876A_0000031_20230206145959.bin",
				"MesData128Result_A5052876A_0000004_Result_20230206110717.bin",
				"MesData256_A5052876A_0000004_20230206110645.bin",
				"MesData256Result_A5052876A_0000004_Result_20230206110715.bin",
				"MesData512_A5052876A_0000004_20230206110643.bin",
				"MesData512_Corner_A5052876A_0000004_20230206110703.bin",
				"MesData512Result_A5052876A_0000004_Result_20230206150622.bin",
				"MesData640B_A5052876A_0000004_20230206110722.bin",
				"MesData640BResult_A5052876A_0000004_20230206110730.bin",
				"MesData640G_A5052876A_0000004_20230206110722.bin",
				"MesData640GResult_A5052876A_0000004_20230206110730.bin",
				"MesData640R_A5052876A_0000004_20230206110722.bin",
				"MesData640RResult_A5052876A_0000004_20230206110730.bin",
				"MesData768_A5052876A_0000004_20230206110642.bin",
				"MesData768_Corner_A5052876A_0000004_20230206110701.bin",
				"MesData768Result_A5052876A_0000004_Result_20230206110712.bin",
				"MesData1023_A5052876A_0000004_20230206110640.bin",
				"MesData896_T5040452A_0000040_AD_OFF_Original_20211028165213.bin",
				"MesData896Result_T5040452A_0000040_AD_OFF_Result_20211028165309.bin",
				"MesData896_T5040452A_0000040_AD_ON_Original_20211028165043.bin",
				"MesData896Result_T5040452A_0000040_AD_ON_Result_20211028165138.bin",
				"MesData384_Right_T5040452A_0000013_20211028153842.bin",
				"MesData384_Left_T5040452A_0000125_20211028122108.bin",
				"MesData1023_A5052876A_0000112_20230221143124.bin",
				"MesData128Result_A5052876A_0000112_Result_20230221143206.bin",
				"MesData128_A5052876A_0000112_20230221143133.bin",
				"MesData1Result_12543800_0012962_20230424182930.bin",
				"MesData1_12543800_0012962_20230425155746.bin",
				"MesData256Result_A5052876A_0000112_Result_20230221143202.bin",
				"MesData256_A5052876A_0000112_20230221143130.bin",
				"MesData2Result_12543800_0012962_20230424182932.bin",
				"MesData2_12543800_0012962_20230425155748.bin",
				"MesData3Result_12543800_0012962_20230424182933.bin",
				"MesData3_12543800_0012962_20230425155749.bin",
				"MesData4Result_12543800_0012962_20230424182935.bin",
				"MesData4_12543800_0012962_20230425155751.bin",
				"MesData512Result_A5052876A_0000112_Result_20230221143200.bin",
				"MesData512_A5052876A_0000112_20230221143128.bin",
				"MesData512_Corner_A5052876A_0000112_20230221143149.bin",
				"MesData5Result_12543800_0012962_20230424182943.bin",
				"MesData5_12543800_0012962_20230425155753.bin",
				"MesData640BResult_12543800_0012962_20230424182950.bin",
				"MesData640BResult_A5052876A_0000112_20230221143220.bin",
				"MesData640B_12543800_0012962_20230425155805.bin",
				"MesData640B_A5052876A_0000112_20230221143212.bin",
				"MesData640GResult_12543800_0012962_20230424182950.bin",
				"MesData640GResult_A5052876A_0000112_20230221143220.bin",
				"MesData640G_12543800_0012962_20230425155805.bin",
				"MesData640G_A5052876A_0000112_20230221143212.bin",
				"MesData640RResult_12543800_0012962_20230424182950.bin",
				"MesData640RResult_A5052876A_0000112_20230221143220.bin",
				"MesData640R_12543800_0012962_20230425155805.bin",
				"MesData640R_A5052876A_0000112_20230221143212.bin",
				"MesData768Result_A5052876A_0000112_Result_20230221143159.bin",
				"MesData768_A5052876A_0000112_20230221143126.bin",
				"MesData768_Corner_A5052876A_0000112_20230221143147.bin",
				"MesData1023_A5052876A_0000112_20230221143124.jpg",
				"MesData128Result_A5052876A_0000112_Result_20230221143206.jpg",
				"MesData128_A5052876A_0000112_20230221143133.jpg",
				"MesData1Result_12543800_0012962_20230424182930.jpg",
				"MesData1_12543800_0012962_20230425155746.jpg",
				"MesData256Result_A5052876A_0000112_Result_20230221143202.jpg",
				"MesData256_A5052876A_0000112_20230221143130.jpg",
				"MesData2Result_12543800_0012962_20230424182932.jpg",
				"MesData2_12543800_0012962_20230425155748.jpg",
				"MesData3Result_12543800_0012962_20230424182933.jpg",
				"MesData3_12543800_0012962_20230425155749.jpg",
				"MesData4Result_12543800_0012962_20230424182935.jpg",
				"MesData4_12543800_0012962_20230425155751.jpg",
				"MesData512Result_A5052876A_0000112_Result_20230221143200.jpg",
				"MesData512_A5052876A_0000112_20230221143128.jpg",
				"MesData512_Corner_A5052876A_0000112_20230221143149.jpg",
				"MesData5Result_12543800_0012962_20230424182943.jpg",
				"MesData5_12543800_0012962_20230425155753.jpg",
				"MesData640BResult_12543800_0012962_20230424182950.jpg",
				"MesData640BResult_A5052876A_0000112_20230221143220.jpg",
				"MesData640B_12543800_0012962_20230425155805.jpg",
				"MesData640B_A5052876A_0000112_20230221143212.jpg",
				"MesData640GResult_12543800_0012962_20230424182950.jpg",
				"MesData640GResult_A5052876A_0000112_20230221143220.jpg",
				"MesData640G_12543800_0012962_20230425155805.jpg",
				"MesData640G_A5052876A_0000112_20230221143212.jpg",
				"MesData640RResult_12543800_0012962_20230424182950.jpg",
				"MesData640RResult_A5052876A_0000112_20230221143220.jpg",
				"MesData640R_12543800_0012962_20230425155805.jpg",
				"MesData640R_A5052876A_0000112_20230221143212.jpg",
				"MesData768Result_A5052876A_0000112_Result_20230221143159.jpg",
				"MesData768_A5052876A_0000112_20230221143126.jpg",
				"MesData768_Corner_A5052876A_0000112_20230221143147.jpg"
		));
		List<String> aNo_Sccs = new ArrayList<>(list.size());
		Disassembler disassembler1;
		for (String fileName : list) {
			disassembler1 = new Disassembler(fileName);
			aNo_Sccs.add(disassembler1.getaNo_Scc());
		}
		assertThat(aNo_Sccs, hasItems(
				"A5052876A_0000004",
				"T5040452A_0000040",
				"T5040452A_0000013",
				"T5040452A_0000125",
				"A5052876A_0000112",
				"A5052876A_0000112",
				"A5052876A_0000112",
				"12543800_0012962",
				"12543800_0012962",
				"A5052876A_0000112",
				"A5052876A_0000112",
				"12543800_0012962",
				"12543800_0012962",
				"12543800_0012962",
				"12543800_0012962",
				"12543800_0012962",
				"12543800_0012962",
				"A5052876A_0000112",
				"A5052876A_0000112",
				"A5052876A_0000112",
				"12543800_0012962",
				"12543800_0012962",
				"12543800_0012962",
				"A5052876A_0000112",
				"12543800_0012962",
				"A5052876A_0000112",
				"12543800_0012962",
				"A5052876A_0000112",
				"12543800_0012962",
				"A5052876A_0000112",
				"12543800_0012962",
				"A5052876A_0000112",
				"12543800_0012962",
				"A5052876A_0000112",
				"A5052876A_0000112",
				"A5052876A_0000112",
				"A5052876A_0000112"
		));
	}
}