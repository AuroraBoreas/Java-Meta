package my.pkg;

import org.junit.jupiter.api.*;

import java.util.stream.Stream;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class AssemblerTest {
	private Assembler assembler;

	@BeforeEach
	void setUp() {
		this.assembler = new Assembler("128");
	}

	@Test
	@DisplayName("assemblePrefixMesData method should work correctly")
	void assemblePrefixMesDataMethodShouldWorkCorrectly() {
		Assertions.assertEquals("mesdata128_", assembler.assemblePrefixMesData());
	}

	@Test
	@DisplayName("assemblePrefixMesDataResult method should work correctly")
	void assemblePrefixMesDataResultMethodShouldWorkCorrectly() {
		Assertions.assertEquals("mesdata128result_", assembler.assemblePrefixMesDataResult());
	}

	@Test
	@DisplayName("assemblePrefixMesData when 895 R Left None")
	void assemblePrefixMesDataWhen895RLeftNone() {
		this.assembler = new Assembler("895", "R", "Left", "None");
		Assertions.assertEquals("mesdata895r_left_", assembler.assemblePrefixMesData());
	}

	@Test
	@DisplayName("assemble 640 W Left AD_ON")
	void assemble640NoneLeftAdOn() {
		this.assembler = new Assembler("640", "W", "Left", "AD_ON");
		Assertions.assertEquals("mesdata640_left_", assembler.assemblePrefixMesData());
		Assertions.assertEquals("ad_on", assembler.getAdOnOff());
		Assertions.assertEquals("mesdata640result_left_", assembler.assemblePrefixMesDataResult());
	}

	@Test
	@DisplayName("assembleAdOnOffResult should return correct result")
	void assembleAdOnOffResultShouldReturnCorrectResult() {
		this.assembler = new Assembler("640", "w", "none", "none");
		Assertions.assertEquals("", assembler.assembleAdOnOffResult());
	}

	@Test
	@DisplayName("assembleAdOnOffOriginal should return correct result")
	void assembleAdOnOffOriginalShouldReturnCorrectResult() {
		this.assembler = new Assembler("640", "w", "none", "none");
		Assertions.assertEquals("", assembler.assembleAdOnOffResult());
	}

	@Test
	@DisplayName("assembleAdOnOffOriginal should return correct result")
	void assembleAdOnOffOriginalShouldReturnCorrectResultNegate1() {
		this.assembler = new Assembler("640", "w", "none", "ad_on");
		Assertions.assertEquals("ad_on_result", assembler.assembleAdOnOffResult());
	}

	@Test
	@DisplayName("assembleAdOnOffOriginal should return correct result")
	void assembleAdOnOffOriginalShouldReturnCorrectResultNegate2() {
		this.assembler = new Assembler("640", "w", "none", "ad_on");
		Assertions.assertEquals("ad_on_original", assembler.assembleAdOnOffOriginal());
	}

	@Test
	@DisplayName("underscore counter should work correctly")
	void underscoreCounterShouldWorkCorrectly() {
		String names = "MesData640BResult_T5040452A_0000011_20211028133315.bin";
		var n = names.chars().filter(x -> x == '_').count();
		Assertions.assertEquals(3L, n);
	}


	@Test
	@DisplayName("assemble 512 W corner none")
	void assemble512NoneLeftAdOn() {
		this.assembler = new Assembler("512", "W", "corner", "none");
		Assertions.assertEquals("mesdata512_corner_", assembler.assemblePrefixMesData());
		Assertions.assertEquals("", assembler.getAdOnOff());
		Assertions.assertEquals("mesdata512result_corner_", assembler.assemblePrefixMesDataResult());
	}

	@Test
	@DisplayName("hasAdOnOffOriginalOrResult should work correctly")
	void hasAdOnOffOriginalOrResultShouldWorkCorrectly() {
		this.assembler = new Assembler("640", "b", "none", "none");
		var result = Stream.of(
				"MesData640B_T5040452A_0000011_20211028133302.bin",
//				"MesData640G_T5040452A_0000011_20211028133302.bin",
//				"MesData640R_T5040452A_0000011_20211028133302.bin",
//				"MesData640Result_T5040452A_0000011_AD_OFF_Result_20211028133251.bin",
//				"MesData640_T5040452A_0000011_AD_OFF_Original_20211028133155.bin",
//				"MesData640BResult_T5040452A_0000011_20211028133144.bin",
//				"MesData640GResult_T5040452A_0000011_20211028133144.bin",
//				"MesData640RResult_T5040452A_0000011_20211028133144.bin",
				"MesData640B_T5040452A_0000011_20211028133129.bin"
//				"MesData640G_T5040452A_0000011_20211028133129.bin",
//				"MesData640R_T5040452A_0000011_20211028133129.bin",
//				"MesData640Result_T5040452A_0000011_AD_ON_Result_20211028133110.bin",
//				"MesData640_T5040452A_0000011_AD_ON_Original_20211028133009.bin"
		).allMatch(assembler::isBeforeAdj);
		Assertions.assertTrue(result);
	}

	@Test
	@DisplayName("hasAdOnOffOriginalOrResult should work correctly")
	void hasAdOnOffOriginalOrResultShouldWorkCorrectly2() {
		this.assembler = new Assembler("640", "w", "none", "ad_on");
		var result = Stream.of(
//				"MesData640Result_T5040452A_0000011_AD_ON_Result",
				"MesData640_T5040452A_0000011_AD_ON_Original"
		).noneMatch(assembler::isAfterAdj);
		Assertions.assertTrue(result);
	}

	@Test
	@DisplayName("hasAdOnOffOriginalOrResult should work correctly")
	void hasAdOnOffOriginalOrResultShouldWorkCorrectly3() {
		this.assembler = new Assembler("640", "w", "none", "ad_on");
		var result = Stream.of(
				"MesData640_T5040452A_0000091_AD_ON_Original_20211028191623.bin",
				"MesData640_T5040452A_0000035_AD_ON_Original_20211028185930.bin"
		).allMatch(assembler::isBeforeAdj);
		Assertions.assertTrue(result);
	}

	@Test
	@DisplayName("hasAdOnOffOriginalOrResult should work correctly")
	void hasAdOnOffOriginalOrResultShouldWorkCorrectly4() {
		this.assembler = new Assembler("640", "w", "left", "none");
		var result = Stream.of(
				"MesData1023_Left_T5040452A_0000041",
				"MesData1023_Left_T5040452A_0000040"
		).noneMatch(assembler::isBeforeAdj);
		Assertions.assertTrue(result);
	}

	@Test
	@DisplayName("hasAdOnOffOriginalOrResult should work correctly")
	void hasAdOnOffOriginalOrResultShouldWorkCorrectly5() {
		this.assembler = new Assembler("640", "w", "right", "none");
		var result = Stream.of(
				"MesData640Result_T5040452A_0000090_AD_ON_Result_20211028185443.bin",
				"MesData640Result_T5040452A_0000089_AD_ON_Result_20211028183732.bin"
		).noneMatch(assembler::isAfterAdj);
		Assertions.assertTrue(result);
	}
}