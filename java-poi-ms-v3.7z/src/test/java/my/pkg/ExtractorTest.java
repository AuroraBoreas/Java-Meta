package my.pkg;

import com.google.common.jimfs.Configuration;
import com.google.common.jimfs.Jimfs;
import org.junit.jupiter.api.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.FileSystem;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ExtractorTest {
	private static final FileSystem fs = Jimfs.newFileSystem(Configuration.windows());
	private final Path pathToStore = fs.getPath(".");
	private final FileRepository fr = new FileRepository();

	@BeforeEach
	void setUp() {
		List.of(
				"newFile.txt",
				"newFile1.bin",
				"newFile2.bin",
				"newFile1.png",
				"newFile2.png",
				"newFile1.csv",
				"newFile2.csv",
				"newFile3.csv",
				"newFile1.txt",
				"newFile2.txt",
				"newFile3.txt",
				"newFile4.txt"
		).forEach(x -> fr.create(pathToStore, x));
	}

	@Test
	@DisplayName("CRUD : create file and path should work correctly")
	void createPathInWinOS() throws IOException {
		Assertions.assertAll(
				() -> Assertions.assertTrue(Files.exists(pathToStore.resolve("newFile.txt"))),
				() -> Assertions.assertTrue(Files.exists(pathToStore.resolve("newFile1.bin"))),
				() -> Assertions.assertTrue(Files.exists(pathToStore.resolve("newFile2.png"))),
				() -> Assertions.assertTrue(Files.exists(pathToStore.resolve("newFile3.csv"))),
				() -> Assertions.assertTrue(Files.exists(pathToStore.resolve("newFile4.txt")))
		);

		// EFMA
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		try (Stream<Path> walk = Files.walk(pathToStore)) {
			walk.parallel()
					.filter(x -> x.toAbsolutePath().toString().endsWith(".png"))
					.forEachOrdered(System.out::println);
		}
		System.out.println("running..");
		String result = baos.toString();
		System.out.println(result);
		Assertions.assertAll(
				() -> Assertions.assertTrue(result.contains("newFile1.png")), // positive
				() -> Assertions.assertTrue(result.contains("newFile2.png")), // positive
				() -> Assertions.assertFalse(result.contains("running..."))   // negate
		);
	}

	@Test
	@DisplayName("Files Walk should work correctly")
	void fileWalkInWinOS() throws IOException {
		long n;
		try (Stream<Path> walk = Files.walk(pathToStore)) {
			n = walk.parallel()
					.filter(x -> x.toAbsolutePath().toString().endsWith(".bin"))
					.count();
		}
		Assertions.assertEquals(2, n);
	}

	static class FileRepository {
		public void create(Path pathToStore, String fileName) {
			Path file = pathToStore.resolve(fileName);
			try {
				Files.createFile(file);
			} catch (IOException ignore) {
			}
		}
	}
}