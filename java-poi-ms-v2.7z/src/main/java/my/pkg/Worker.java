package my.pkg;

import my.db.Connector;
import my.util.Cleaner;

import java.io.IOException;
import java.sql.SQLException;

public class Worker implements Simulator {
    private final Extractor extractor;

    public Worker(Extractor e) {
        this.extractor = e;
    }

    public void saveToDatabase(
            String lineName,
            String setNo,
            String date,
            String ire,
            String method,
            int interval,
            String file
    ) {
        Connector connector = new Connector("data.db");
        connector.connect();
        connector.createNewTable();
        connector.insert(lineName, setNo, date, ire, method, interval, file);
        try {
            connector.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void search(String savedFileName) throws IOException, InterruptedException {
        extractor.sort(extractor.getSrc());
        extractor.match();
        convert();
        extractor.setExt(".jpg");
        extractor.reset();
        extractor.sort(extractor.getDst());
        Reporter.start(savedFileName, extractor);
        Cleaner.clean(extractor.getDst().toString());
    }

    @Override
    public void convert() throws InterruptedException, IOException {
        String executable = "PLRLogger.exe";
        Process p = Runtime.getRuntime().exec(executable + " " + extractor.getDst().toString());
        p.waitFor();
    }

    @Override
    public String toString() {
        return "Worker{" +
                "extractor=" + extractor +
                '}';
    }
}
