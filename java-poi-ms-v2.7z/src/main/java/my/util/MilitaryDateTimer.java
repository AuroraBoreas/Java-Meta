package my.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MilitaryDateTimer {
    private static final String pattern = "yyyyMMddHHmmss";

    public static String getMilitaryDateTime() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern(pattern);
        return now.format(fmt);
    }

    public static String getMilitaryDateTime(LocalDateTime dt) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern(pattern);
        return dt.format(fmt);
    }
}
