package my.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class CsvParser {
    private final File fileName;
    private List<List<String>> records;
    private List<String> flattenRecords;

    public CsvParser(String fileName) {
        this.fileName = new File(fileName);
    }

    public List<String> getFlattenRecords() {
        return flattenRecords;
    }

    public void displayList() {
        /*
         https://stackoverflow.com/questions/40074840/reading-a-csv-file-into-a-array
         the following code lets you iterate through the 2-dimensional array
        */
        System.out.println(records.toString());
        int lineNo = 1;
        for (List<String> line : records) {
            int columnNo = 1;
            for (String value : line) {
                System.out.println("Line " + lineNo + " Column " + columnNo + ": " + value);
                columnNo++;
            }
            lineNo++;
        }
    }

    public void get2dArray() {
        // this gives you a 2-dimensional array of strings
        records = new ArrayList<>();
        flattenRecords = new ArrayList<>();
        Scanner inputStream;
        // validate
        if (!(Files.exists(fileName.toPath()) &&
                Files.isRegularFile(fileName.toPath()) &&
                Files.isReadable(fileName.toPath()))
        ) {
            return;
        }
        try {
            inputStream = new Scanner(fileName);
            String line;
            String[] values;
            List<String> tempList;
            while (inputStream.hasNext()) {
                line = inputStream.next();
                values = line.split(",");
                // this adds the currently parsed line to the 2-dimensional string array
                tempList = Arrays.asList(values);
                records.add(tempList);
                flattenRecords.addAll(tempList);
            }
            inputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}