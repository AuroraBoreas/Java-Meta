package my.pkg;

import my.db.Connector;
import my.util.Cleaner;

import java.io.IOException;
import java.sql.SQLException;

public class Worker implements Simulator {
    private final Extractor extractor;
    private final String toFileName;
    private final String workDateTime;
    private final String lineName;

    public Worker(Extractor e, String lineName, String workDateTime, String savedFileName) {
        this.extractor = e;
        this.lineName = lineName;
        this.workDateTime = workDateTime;
        this.toFileName = savedFileName;
    }

    private void saveToDatabase() {
        Connector connector = new Connector("data.db");
        connector.connect();
        connector.createNewTable();
        connector.insert(lineName,
                extractor.getSetNo(),
                workDateTime,
                extractor.getIre(),
                Integer.valueOf(extractor.getCompMethod()).toString(),
                extractor.getSampleInterval(),
                toFileName);
        try {
            connector.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void search() throws IOException, InterruptedException {
        extractor.sort(extractor.getSrc());
        extractor.match();
        convert();
        extractor.setExt(".jpg");
        extractor.reset();
        extractor.sort(extractor.getDst());
        Reporter.start(toFileName, extractor);
        saveToDatabase();
        Cleaner.clean(extractor.getDst().toString());
    }

    @Override
    public void convert() throws InterruptedException, IOException {
        String executable = "PLRLogger.exe";
        Process p = Runtime.getRuntime().exec(executable + " " + extractor.getDst().toString());
        p.waitFor();
    }

    @Override
    public String toString() {
        return "Worker{" +
                "extractor=" + extractor +
                '}';
    }
}
