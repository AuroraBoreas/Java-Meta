package my.pkg;

import my.util.Cleaner;

import java.io.IOException;

public class Worker implements Simulator {
    private final Extractor extractor;

    public Worker(Extractor e) {
        this.extractor = e;
    }

    public void search(String savedFileName) throws IOException, InterruptedException {
        extractor.sort(extractor.getSrc());
        extractor.match();
        convert();
        extractor.setExt(".jpg");
        extractor.reset();
        extractor.sort(extractor.getDst());
        Reporter.start(savedFileName, extractor);
        Cleaner.clean(extractor.getDst().toString());
    }

    @Override
    public void convert() throws InterruptedException, IOException {
        String executable = "PLRLogger.exe";
        Process p = Runtime.getRuntime().exec(executable + " " + extractor.getDst().toString());
        p.waitFor();
    }

    @Override
    public String toString() {
        return "Worker{" +
                "extractor=" + extractor +
                '}';
    }
}
