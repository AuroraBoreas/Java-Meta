package my.pkg;

public class Holder {
    // TODO: save excel to Sqlite database, 2020515
    public double[] mesData = new double[480 * 270];
    public double[] offsetH = new double[480];
    public double[] offsetV = new double[270];
    private double[] m_Data;

    private double[] read() {
        return null;
    }
}
