package my.pkg;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.Map;

public class Reporter {
    public static void start(
            String dstFileName,
            Prototype p
    ) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            // setup sheet
            String sheetName = "Result";
            Sheet sheet = workbook.createSheet(sheetName);
            setSheetColumnWidth(sheet);
            // setup header
            int beforeColumn = 2, afterColumn = 3;
            Row header = sheet.createRow(0);
            setHeaders(header);
            // load image
            float height = 104.5f;
            Map<String, Path> beforeMap = p.getBeforeMap();
            Map<String, Path> afterMap = p.getAfterMap();
            if (!beforeMap.isEmpty() && !afterMap.isEmpty()) {
                loadBoth(beforeMap, afterMap, workbook, sheet, beforeColumn, afterColumn, height);
            } else {
                if (!beforeMap.isEmpty()) {
                    load(beforeMap, workbook, sheet, beforeColumn, height);
                }
                if (!afterMap.isEmpty()) {
                    load(afterMap, workbook, sheet, afterColumn, height);
                }
            }
            FileOutputStream saveExcel = new FileOutputStream(dstFileName);
            workbook.write(saveExcel);
        }
    }

    private static void load(Map<String, Path> map, Workbook workbook, Sheet sheet, int column, float height) throws IOException {
        String key;
        Row row;
        int i = 1;
        for (Map.Entry<String, Path> entry : map.entrySet()) {
            key = entry.getKey();
            row = sheet.createRow(i);
            row.setHeightInPoints(height);
            row.createCell(0).setCellValue(i); // No
            row.createCell(1).setCellValue(key); // log file name;
            loadImage(workbook, sheet, map.get(key).toAbsolutePath().toString(), i, column); // before adj Mura image
        }
    }

    private static void loadBoth(Map<String, Path> beforeMap, Map<String, Path> afterMap, Workbook workbook, Sheet sheet, int beforeColumn, int afterColumn, float height) throws IOException {
        String key;
        Row row;
        int i = 1;
        for (Map.Entry<String, Path> entry : beforeMap.entrySet()) {
            key = entry.getKey();
            if (afterMap.containsKey(key)) {
                row = sheet.createRow(i);
                row.setHeightInPoints(height);
                row.createCell(0).setCellValue(i); // No
                row.createCell(1).setCellValue(key); // log file name;
                loadImage(workbook, sheet, beforeMap.get(key).toAbsolutePath().toString(), i, beforeColumn); // before adj Mura image
                loadImage(workbook, sheet, afterMap.get(key).toAbsolutePath().toString(), i, afterColumn); // after adj Mura image
                i++;
            }
        }
    }

    private static void setHeaders(Row header) {
        header.createCell(0).setCellValue("No");
        header.createCell(1).setCellValue("Log");
        header.createCell(2).setCellValue("BeforeAdj");
        header.createCell(3).setCellValue("AfterAdj");
        header.setHeightInPoints(14.5f);
    }

    private static void setSheetColumnWidth(Sheet sheet) {
        sheet.setColumnWidth(1, 42 * 256);
        sheet.setColumnWidth(2, 32 * 256);
        sheet.setColumnWidth(3, 32 * 256);
    }

    private static void loadImage(Workbook workbook, Sheet sheet, String name, int firstRow, int firstColumn) throws IOException {
        InputStream inputStream = new FileInputStream(name);
        // assert inputStream != null;
        byte[] inputImageBytes = IOUtils.toByteArray(inputStream);
        int inputImagePictureID = workbook.addPicture(inputImageBytes, Workbook.PICTURE_TYPE_PNG);
        XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
        XSSFClientAnchor anchor = new XSSFClientAnchor();
        anchor.setRow1(firstRow); // Sets the row (0 based) of the first cell.
        anchor.setRow2(firstRow + 1); // Sets the row (0 based) of the Second cell.
        anchor.setCol1(firstColumn); // Sets the column (0 based) of the first cell.
        anchor.setCol2(firstColumn + 1); // Sets the column (0 based) of the Second cell.
        drawing.createPicture(anchor, inputImagePictureID);
    }
}