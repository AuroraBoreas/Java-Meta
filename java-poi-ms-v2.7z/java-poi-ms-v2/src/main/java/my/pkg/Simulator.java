package my.pkg;

import java.io.IOException;

public interface Simulator {
    void convert() throws IOException, InterruptedException;
}
