package my.gui;

import my.pkg.Extractor;
import my.pkg.Worker;
import my.util.Cleaner;
import my.util.MilitaryDateTimer;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class MyApp extends JFrame implements ActionListener {
    private JPanel mainPanel;
    private JTextField textFieldSrc;
    private JButton openButtonSrc;
    private JTextField textFieldDst;
    private JButton openButtonDst;
    private JTextField textFieldLineName;
    private JTextField textFieldSetNo;
    private JTextField textFieldDate;
    private JComboBox comboBoxIre;
    private JComboBox comboBoxMethod;
    private JSpinner spinnerInterval;
    private JTextArea textAreaOutput;
    private JButton startButton;
    private JButton resetButton;
    private JPanel sourcePanel;
    private JProgressBar progressBarOutput;
    private JPanel outputPanel;
    private JPanel setupPanel;
    private JPanel basicSetupPanel;
    private JPanel processPanel;
    private JPanel buttonPanel;
    private JPanel footPanel;
    private JLabel footLabel;

    public MyApp() throws HeadlessException {
        createWindows();
    }

    public static void main(String[] args) {
        MyApp myApp = new MyApp();
    }

    private void createWindows() {
        // main window
        final int width = 600;
        final int height = 400;
        Point point = GraphicsEnvironment.getLocalGraphicsEnvironment().getCenterPoint();
        setBounds(point.x - width / 2, point.y - height / 2, width, height);
        setLocationRelativeTo(null);
        setTitle("Bonjour");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setSize(width, height);
        setAlwaysOnTop(false);
        setFocusable(false);
        setResizable(false);
        // border
        Border border = BorderFactory.createLineBorder(Color.white, 2, true);
        sourcePanel.setBorder(border);
        setupPanel.setBorder(border);
        outputPanel.setBorder(border);
        footPanel.setBorder(border);
        mainPanel.setBorder(border);
        textAreaOutput.setLineWrap(true);
        // action listeners
        attachActionListeners();
        // init states
        spinnerInterval.setValue(1);
        // go
        add(mainPanel);
    }

    private void attachActionListeners() {
        openButtonSrc.addActionListener(e -> selectDirectoryDialog(textFieldSrc));
        openButtonDst.addActionListener(e -> selectDirectoryDialog(textFieldDst));

        startButton.addActionListener(e -> {
            if (isValidatedTextFields()) {
                progressBarOutput.setValue(0);
                progressBarOutput.setStringPainted(true);
                footLabel.setText("processing...");
                new Thread(() -> SwingUtilities.invokeLater(() -> {
                    startButton.setEnabled(false);
                    try {
                        processWorkload();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    } catch (InterruptedException ex) {
                        throw new RuntimeException(ex);
                    }
                })).start();
                new Thread(() -> {
                    for (int i = 0; i <= 100; i++) {
                        int finalI = i;
                        SwingUtilities.invokeLater(() -> progressBarOutput.setValue(finalI));
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                    footLabel.setText("Finished!");
                    startButton.setEnabled(true);
                }).start();
            } else {
                footLabel.setText("aborted!");
            }
        });

        resetButton.addActionListener(e -> {
            textFieldSrc.setText("");
            textFieldSrc.setBackground(Color.white);
            textFieldDst.setText("");
            textFieldDst.setBackground(Color.white);
            textFieldLineName.setText("");
            textFieldLineName.setBackground(Color.white);
            textFieldSetNo.setText("");
            textFieldSetNo.setBackground(Color.white);
            textFieldDate.setText("");
            textFieldDate.setBackground(Color.white);
            startButton.setEnabled(true);
            comboBoxIre.setSelectedIndex(1);
            comboBoxMethod.setSelectedIndex(0);
            spinnerInterval.setValue(1);
            textAreaOutput.setText("");
            footLabel.setText("TV QA: Balabala");
        });
    }

    private void processWorkload() throws IOException, InterruptedException {
        Extractor extractor = new Extractor(
                textFieldSrc.getText(),
                textFieldSetNo.getText(),
                textFieldDate.getText(),
                comboBoxIre.getSelectedItem().toString(),
                comboBoxMethod.getSelectedIndex(),
                (Integer) spinnerInterval.getValue()
        );

        String folderPath = textFieldDst.getText();
        if (folderPath.length() < 1 || !Files.isDirectory(Paths.get(folderPath))) {
            folderPath = "./report";
            Cleaner.create(folderPath);
        }
        String savedFileName = folderPath + "\\"
                + MilitaryDateTimer.getMilitaryDateTime()
                + "_"
                + textFieldLineName.getText()
                + "_"
                + textFieldSetNo.getText()
                + "_Mura_Image_List_MesData" + comboBoxIre.getSelectedItem()
                + ".xlsx";
        Worker worker = new Worker(extractor);
        worker.search(savedFileName);
        textAreaOutput.setText(textAreaOutput.getText() + "\n" + extractor);
    }

    private boolean isValidatedTextFields() {
        if (textFieldSrc.getText().length() < 1 || !Files.isDirectory(Paths.get(textFieldSrc.getText()))) {
            textFieldSrc.setBackground(Color.red);
        } else {
            textFieldSrc.setBackground(Color.white);
        }

        if (textFieldDst.getText().length() < 1 || !Files.isDirectory(Paths.get(textFieldDst.getText()))) {
            textFieldDst.setBackground(Color.lightGray);
        } else {
            textFieldDst.setBackground(Color.white);
        }
        if (textFieldLineName.getText().length() < 1) {
            textFieldLineName.setText("unknown");
        } else {
            textFieldLineName.setBackground(Color.white);
        }
        if (textFieldSetNo.getText().length() != 8) {
            textFieldSetNo.setBackground(Color.red);
        } else {
            textFieldSetNo.setBackground(Color.white);
        }
        if (textFieldDate.getText().length() != 8) {
            textFieldDate.setText("");
        } else {
            textFieldDate.setBackground(Color.white);
        }
        if (textFieldSrc.getBackground() == Color.red ||
                textFieldLineName.getBackground() == Color.red ||
                textFieldSetNo.getBackground() == Color.red
        ) {
            JOptionPane.showMessageDialog(this,
                    "Eggs are not supposed to be green.",
                    "Inane error",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }

    private void selectDirectoryDialog(JTextField textField) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int option = fileChooser.showOpenDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            textField.setText(file.getAbsolutePath());
        } else {
            textField.setText("");
        }
    }

    private void createUIComponents() {
        Integer[] ires = {1, 2, 3, 4, 5, 1023, 896, 768, 640, 512, 384, 256, 128};
        comboBoxIre = new JComboBox(ires);
        comboBoxIre.setSelectedIndex(1);
        String[] methods = {"both", "before", "after"};
        comboBoxMethod = new JComboBox(methods);
        comboBoxMethod.setSelectedIndex(0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }

}
