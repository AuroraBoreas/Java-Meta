package my.util;

public class BiCubicRescaleImage {
    public static double[][] BiCubicRescaleImage(double[][] data, int hxSize, int hySize) {
        try {
            int xSize = data.length;
            int ySize = data[0].length;
            double xpos, ypos;
            double hokanX = (double) (xSize - 1) / hxSize;
            double hokanY = (double) (ySize - 1) / hySize;
            double[][] bufdata = new double[hxSize][ySize];
            double[][] rescaledata = new double[hxSize][hySize];

            // X方向の補間
            for (int i = 0; i < ySize; i++) {
                xpos = 0.0;

                // 配列入れ替え
                double[] q = new double[xSize];
                for (int j = 0; j < xSize; j++) {
                    q[j] = data[j][i];
                }

                // 補間
                for (int j = 0; j < hxSize; j++) {
                    bufdata[j][i] = CubicConvolution(q, xpos);
                    xpos += hokanX;
                }
            }
            // Y方向の補間
            for (int i = 0; i < hxSize; i++) {
                ypos = 0.0;

                // 配列入れ替え
                double[] q = new double[ySize];
                System.arraycopy(bufdata[i], 0, q, 0, ySize);

                // 補間
                for (int j = 0; j < hySize; j++) {
                    rescaledata[i][j] = CubicConvolution(q, ypos);
                    ypos += hokanY;
                }
            }

            return rescaledata;
        } catch (Exception e) {
            return null;
        }
    }

    public static double CubicConvolution(double[] q, double position) {
        try {
            int roundPos = (int) position;
            //バイキュービックでの補間
            if (roundPos >= 2 && roundPos < q.length - 2) {
                double a = -1;     // 定数
                double value = 0;  // 戻り値

                for (int i = roundPos - 2; i <= roundPos + 2; i++) {
                    if (i < q.length && i >= 0) {
                        double t = Math.abs(position - i);
                        if (t >= 0 && t < 1) {
                            double h =
                                    (a + 2) * Math.abs(Math.pow(t, 3)) -
                                            (a + 3) * Math.pow(t, 2) +
                                            1;
                            value += q[i] * h;
                        } else if (t >= 1 && t < 2) {
                            double h =
                                    a * Math.abs(Math.pow(t, 3)) -
                                            5 * a * Math.pow(t, 2) +
                                            8 * a * Math.abs(t) -
                                            4 * a;
                            value += q[i] * h;
                        }
                    }
                }
                return value;
            } else if (roundPos >= 0 && roundPos < q.length) {
                return LinearFunction(q[roundPos + 1], q[roundPos], position);
            } else {
                return 0;
            }
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    public static double LinearFunction(double y1, double y0, double position) {
        try {
            return (y1 - y0) * (position - (int) position) + y0;
        } catch (Exception e) {
            return Double.NaN;
        }
    }
}
