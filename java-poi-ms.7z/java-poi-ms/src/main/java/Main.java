import my.pkg.Extractor;
import my.pkg.Reporter;
import my.util.Cleaner;
import my.util.MilitaryDateTimer;

import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) throws IOException {
        clientCode();
        System.out.println("hello world!");
    }

    private static void clientCode() throws IOException {
        // searchMuraLogs();
        Cleaner.create("report");
        String p = "report/%s_%s_%s_Mura_Image_List_MesData%d.xlsx".formatted(MilitaryDateTimer.getMilitaryDateTime(), "M2", "12552100", 2);
        loadImagesToExcel(p);
    }

    private static void searchMuraLogs() throws IOException {
        String src = "\\\\43.98.232.66\\Local\\XJ\\MURA_COLLECT\\M2 FH65\\20230405";
        String dst = "data";
        int sampleInterval = 10;
        Cleaner.clean(dst);
        Extractor checker = new Extractor(dst, "12543800", "20230405", 2, -1, sampleInterval);
        checker.sort(src);
        src = "\\\\43.98.232.66\\Local\\XJ\\MURA_COLLECT\\M2 FH65\\CHK";
        Extractor extractor = new Extractor(dst, "12543800", "20230405", 2, 1, sampleInterval);
        extractor.sort(src);
        checker.setAfterMap(extractor);
        checker.filter();
    }

    private static void loadImagesToExcel(String p) throws IOException {
        Map<String, String> before = new TreeMap<>();
        Map<String, String> after = new TreeMap<>();
        before.put("1", "ironman.jfif");
        before.put("2", "ironman.jfif");
        before.put("3", "ironman.jfif");
        before.put("4", "ironman.jfif");
        before.put("5", "ironman.jfif");
        before.put("6", "ironman.jfif");
        after.put("1", "spiderman.jfif");
        after.put("2", "spiderman.jfif");
        after.put("3", "spiderman.jfif");
        after.put("4", "spiderman.jfif");
        after.put("5", "spiderman.jfif");
        after.put("6", "spiderman.jfif");
        Reporter.start(p, before, after);
    }
}
