package my.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public final class Cleaner {
    public static void clean(String where) throws IOException {
        Cleaner.create(where);
        File folder = new File(where);
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (!file.isDirectory()) {
                    file.delete();
                }
            }
        }
    }

    public static void create(String where) throws IOException {
        File folder = new File(where);
        if (!Files.exists(folder.toPath())) {
            Files.createDirectory(folder.toPath());
        }
    }
}
