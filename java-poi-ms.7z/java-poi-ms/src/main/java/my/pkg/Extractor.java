package my.pkg;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Extractor extends Prototype {
    private String mesData;
    private String mesDataResult;
    private String setNo;
    private String productDate;
    private int sampleInterval;
    private int compMethod;
    private Path dst;

    public Extractor(String dst, String setNo, String productDate, int ire, int compMethod, int sampleInterval) {
        this.dst = Paths.get(dst);
        this.mesData = "mesdata%d_".formatted(ire);
        this.mesDataResult = "mesdata%dresult_".formatted(ire);
        if (setNo.length() != 8) {
            throw new IllegalArgumentException("The length of SetNo must be 8 bits, like 12543800");
        } else {
            this.setNo = setNo;
        }
        if (productDate.length() != 8) {
            throw new IllegalArgumentException("The length of SetNo must be 8 bits, like 20230405");
        } else {
            this.productDate = productDate;
        }
        this.compMethod = compMethod < -1 || compMethod > 1 ? 0 : compMethod;
        this.sampleInterval = sampleInterval < 0 ? 1 : sampleInterval;
    }

    public Extractor(String dst, String setNo, String productDate) {
        this(dst, setNo, productDate, 2, 1, 10);
    }

    public String getMesData() {
        return mesData;
    }

    public void setMesData(String mesData) {
        this.mesData = mesData;
    }

    public String getMesDataResult() {
        return mesDataResult;
    }

    public void setMesDataResult(String mesDataResult) {
        this.mesDataResult = mesDataResult;
    }

    public String getSetNo() {
        return setNo;
    }

    public void setSetNo(String setNo) {
        this.setNo = setNo;
    }

    public String getProductDate() {
        return productDate;
    }

    public void setProductDate(String productDate) {
        this.productDate = productDate;
    }

    public int getSampleInterval() {
        return sampleInterval;
    }

    public void setSampleInterval(int sampleInterval) {
        this.sampleInterval = sampleInterval;
    }

    public int getCompMethod() {
        return compMethod;
    }

    public void setCompMethod(int compMethod) {
        this.compMethod = compMethod;
    }

    public Path getDst() {
        return dst;
    }

    public void setDst(Path dst) {
        this.dst = dst;
    }

    //    private
    public void sort(String srcRoot) {
        try (Stream<Path> walk = Files.walk(Paths.get(srcRoot))) {
            walk.filter(getPathPredicate())
                    .parallel()
                    .sorted(Comparator.reverseOrder())
                    .forEachOrdered(getPathConsumer());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Consumer<Path> getPathConsumer() {
        return x -> {
            String fileName = x.getFileName().toString().toLowerCase();
            String trailedName = fileName.replaceAll(timestampPattern, emptyString);
            String aNo_Scc = trailedName.replaceAll(fileHeaderPattern, emptyString);
            boolean cond1 = fileName.startsWith(mesData);
            boolean cond2 = fileName.startsWith(mesDataResult);
            switch (compMethod) {
                case -1 -> {
                    if (cond1 && !beforeMap.containsKey(aNo_Scc))
                        beforeMap.put(aNo_Scc, x);
                }
                case 0 -> {
                    if (cond1 && !beforeMap.containsKey(aNo_Scc))
                        beforeMap.put(aNo_Scc, x);
                    if (cond2 && !afterMap.containsKey(aNo_Scc))
                        afterMap.put(aNo_Scc, x);
                }
                default -> {
                    if (cond2 && !afterMap.containsKey(aNo_Scc))
                        afterMap.put(aNo_Scc, x);
                }
            }
        };
    }

    private Predicate<Path> getPathPredicate() {
        return x -> {
            String fileName = x.getFileName().toString().toLowerCase();
            return (fileName.startsWith(mesData) || fileName.startsWith(mesDataResult)) && fileName.endsWith(ext) && fileName.contains(setNo) && fileName.contains(productDate);
        };
    }

    public void filter() throws IOException {
        if (!beforeMap.isEmpty() && !afterMap.isEmpty()) {
            this.compMethod = 0;
        } else {
            if (!beforeMap.isEmpty()) {
                this.compMethod = -1;
            }
            if (!afterMap.isEmpty()) {
                this.compMethod = 1;
            }
        }
        switch (compMethod) {
            case -1 -> compare(beforeMap);
            case 0 -> compareBoth(beforeMap, afterMap);
            default -> compare(afterMap);
        }
    }

    protected void compareBoth(
            TreeMap<String, Path> beforeMap,
            TreeMap<String, Path> afterMap
    ) throws IOException {
        String key;
        int i = 0;
        for (Map.Entry<String, Path> entry : beforeMap.entrySet()) {
            key = entry.getKey();
            if (afterMap.containsKey(key) && (i % sampleInterval == 0)) {
                Files.copy(beforeMap.get(key), dst.resolve(beforeMap.get(key).getFileName()), StandardCopyOption.REPLACE_EXISTING);
                Files.copy(afterMap.get(key), dst.resolve(afterMap.get(key).getFileName()), StandardCopyOption.REPLACE_EXISTING);
            }
            i++;
        }
    }

    protected void compare(TreeMap<String, Path> map) throws IOException {
        int i = 0;
        List<Path> before = new ArrayList<>(map.values());
        before.sort(Comparator.reverseOrder());
        for (Path e : before) {
            if (i % sampleInterval == 0)
                Files.copy(e, dst.resolve(e.getFileName()), StandardCopyOption.REPLACE_EXISTING);
            i++;
        }
    }

    @Override
    public String toString() {
        return "Extractor{" +
                "mesData='" + mesData + '\'' +
                ", mesDataResult='" + mesDataResult + '\'' +
                ", setNo='" + setNo + '\'' +
                ", productDate='" + productDate + '\'' +
                ", sampleInterval=" + sampleInterval +
                ", compMethod=" + compMethod +
                ", dst=" + dst +
                '}';
    }
}
