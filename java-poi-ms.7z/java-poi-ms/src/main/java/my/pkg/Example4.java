package my.pkg;

import org.apache.logging.log4j.util.PropertiesUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class Example4 {
    public static void write(String dstFileName) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Avenger");
        sheet.setDefaultColumnWidth(15);
        sheet.setDefaultRowHeightInPoints(72.5f);
        Row row1 = sheet.createRow(0);
        row1.createCell(0).setCellValue("IRON-MAN");
        Row row2 = sheet.createRow(1);
        row2.createCell(0).setCellValue("SPIDER-MAN");
        InputStream inputStream1 = PropertiesUtil.class.getClassLoader().getResourceAsStream("ironman.jfif");
        InputStream inputStream2 = PropertiesUtil.class.getClassLoader().getResourceAsStream("spiderman.jfif");
        assert inputStream1 != null;
        byte[] inputImageBytes1 = IOUtils.toByteArray(inputStream1);
        assert inputStream2 != null;
        byte[] inputImageBytes2 = IOUtils.toByteArray(inputStream2);
        int inputImagePictureID1 = workbook.addPicture(inputImageBytes1, Workbook.PICTURE_TYPE_PNG);
        int inputImagePictureID2 = workbook.addPicture(inputImageBytes2, Workbook.PICTURE_TYPE_PNG);
        XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
        XSSFClientAnchor ironManAnchor = new XSSFClientAnchor();
        XSSFClientAnchor spiderManAnchor = new XSSFClientAnchor();
        ironManAnchor.setRow1(0); // Sets the row (0 based) of the first cell.
        ironManAnchor.setRow2(1); // Sets the row (0 based) of the Second cell.
        ironManAnchor.setCol1(1); // Sets the column (0 based) of the first cell.
        ironManAnchor.setCol2(2); // Sets the column (0 based) of the Second cell.
        spiderManAnchor.setCol1(1);
        spiderManAnchor.setCol2(2);
        spiderManAnchor.setRow1(1);
        spiderManAnchor.setRow2(2);
        drawing.createPicture(ironManAnchor, inputImagePictureID1);
        drawing.createPicture(spiderManAnchor, inputImagePictureID2);
        for (int i = 0; i < 3; i++) {
            sheet.autoSizeColumn(i);
        }
        try (FileOutputStream saveExcel = new FileOutputStream(dstFileName)) {
            workbook.write(saveExcel);
        }
    }
}
