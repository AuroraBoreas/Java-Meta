package my.pkg;

import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

public class Example3 {
    public static void read(String fileName) {
        //String fileName = "D:\\SimpleSolution\\Data\\data.xlsx";
        File file = new File(fileName);

        try (Workbook workbook = WorkbookFactory.create(file)) {
            Iterator<Sheet> sheetIterator = workbook.sheetIterator();
            while (sheetIterator.hasNext()) {
                Sheet sheet = sheetIterator.next();
                System.out.println("Sheet: " + sheet.getSheetName());
                Iterator<Row> rowIterator = sheet.rowIterator();
                while (rowIterator.hasNext()) {
                    Row row = rowIterator.next();
                    Iterator<Cell> cellIterator = row.cellIterator();
                    while (cellIterator.hasNext()) {
                        Cell cell = cellIterator.next();
                        CellType cellType = cell.getCellType();
                        if (cellType == CellType.STRING) {
                            System.out.print(cell.getStringCellValue() + "\t");
                        } else if (cellType == CellType.NUMERIC) {
                            System.out.print(cell.getNumericCellValue() + "\t");
                        }
                    }
                    System.out.println();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
