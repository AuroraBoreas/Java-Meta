package my.pkg;

public interface Simulator {
    void convert();
}
