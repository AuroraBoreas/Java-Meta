package my.pkg;

import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

public class Example2 {
    public static void read(String fileName) {
//        String fileName = "D:\\SimpleSolution\\Data\\data.xlsx";
        File file = new File(fileName);

        try (Workbook workbook = WorkbookFactory.create(file)) {
            Iterator<Sheet> sheetIterator = workbook.sheetIterator();
            while (sheetIterator.hasNext()) {
                Sheet sheet = sheetIterator.next();
                Iterator<Row> rowIterator = sheet.rowIterator();
                while (rowIterator.hasNext()) {
                    Row row = rowIterator.next();
                    Iterator<Cell> cellIterator = row.cellIterator();
                    while (cellIterator.hasNext()) {
                        Cell cell = cellIterator.next();
                        // Read cell data
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
