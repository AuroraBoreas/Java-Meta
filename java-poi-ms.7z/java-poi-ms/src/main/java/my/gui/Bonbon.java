package my.gui;

import javax.swing.*;
import java.awt.event.*;
import java.io.File;

public class Bonbon extends JDialog {
    private JTextField textFieldSrc;
    private JButton openButtonSrc;
    private JTextField textFieldDst;
    private JButton openButtonDst;
    private JTextField textFieldLineName;
    private JTextField textFieldSetNo;
    private JTextField textFieldProductDate;
    private JComboBox comboBoxIRE;
    private JComboBox comboBoxCompMethod;
    private JSpinner spinnerSampleInterval;
    private JTextArea textAreaResult;
    private JButton startButton;
    private JButton resetButton;
    private JProgressBar progressBarResult;
    private JPanel jpanelContent;
    private JLabel lableSrc;
    private JLabel lableDst;
    private JSeparator separator1;
    private JLabel labelLineName;
    private JLabel labelSetNo;
    private JLabel labelDate;
    private JLabel labelIRE;
    private JLabel labelMethod;
    private JLabel labelInterval;
    private JSeparator separator2;
    private JSeparator separator3;
    private JSeparator separator4;
    private JPanel jpanelConstraints;
    private JPanel jpanelButtons;
    private JPanel jpanelRight;
    private JPanel jpanelLeft;

    public Bonbon() {
        setContentPane(jpanelContent);
        setModal(true);
        getRootPane().setDefaultButton(startButton);
        jpanelContent.add(textFieldSrc);
        jpanelContent.add(textFieldDst);
        jpanelContent.add(openButtonSrc);
        jpanelContent.add(openButtonDst);
        jpanelContent.add(textFieldLineName);
        jpanelContent.add(textFieldSetNo);
        jpanelContent.add(textFieldProductDate);
        jpanelContent.add(comboBoxIRE);
        jpanelContent.add(comboBoxCompMethod);
        jpanelContent.add(spinnerSampleInterval);
        jpanelContent.add(jpanelConstraints);
        jpanelContent.add(jpanelButtons);
        jpanelContent.add(jpanelLeft);
        jpanelContent.add(jpanelRight);
        jpanelContent.add(lableSrc);
        jpanelContent.add(lableDst);
        jpanelContent.add(labelLineName);
        jpanelContent.add(labelSetNo);
        jpanelContent.add(labelDate);
        jpanelContent.add(labelIRE);
        jpanelContent.add(labelMethod);
        jpanelContent.add(labelInterval);
        jpanelContent.add(progressBarResult);
        jpanelContent.add(textAreaResult);
        jpanelContent.add(separator1);
        jpanelContent.add(separator2);
        jpanelContent.add(separator3);
        jpanelContent.add(separator4);

        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK();
            }
        });

        resetButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        jpanelContent.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("OK is clicked!");
            }
        });
        openButtonSrc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int option = fileChooser.showOpenDialog(null);
                if (option == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    textFieldSrc.setText("File Selected: " + file.getName());
                } else {
                    textFieldSrc.setText("Open command canceled");
                }

            }
        });
    }

    private void onOK() {
        // add your code here
        dispose();
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    public static void main(String[] args) {
        Bonbon dialog = new Bonbon();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }
}
