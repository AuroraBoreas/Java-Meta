package my.lib.chapter11;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.util.Optional;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class UseOptionalTest {
	private UseOptional useOptional;

	@BeforeEach
	void setUp() {
		useOptional = new UseOptional();
	}

	@Test
	@DisplayName("getCarInsuranceName method should work as expected")
	void getCarInsuranceNameMethodShouldWorkAsExpected() {
		String result = useOptional.getCarInsuranceName(Optional.ofNullable(new Person(new Car(new Insurance("hello")))));
		System.out.println(result);
	}
}