package my.lib.chapter07;

import my.lib.chapter10.GroupingBuilder;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;

class ForkJoinSumCalculatorTest {
	private ForkJoinSumCalculator forkJoinSumCalculator;

	@BeforeEach
	void setUp() {
		forkJoinSumCalculator = new ForkJoinSumCalculator(LongStream.rangeClosed(1, 1_000).toArray());
	}

	@Test
	@DisplayName("compute method should work as expected")
	void computeMethodShouldWorkAsExpected() {
		var result = forkJoinSumCalculator.compute();
		System.out.println(result);
		Assertions.assertFalse(forkJoinSumCalculator.isParallel());
	}

	@Test
	@DisplayName("negate test")
	void negateTest() {
		ForkJoinSumCalculator fjc = new ForkJoinSumCalculator(LongStream.rangeClosed(1, 2_000_000).toArray());
		Assertions.assertTrue(fjc.isParallel());
		System.out.println(fjc.compute());
	}

	@Test
	@DisplayName("forkJoinSum method should work as expected")
	void forkJoinSumMethodShouldWorkAsExpected() {
		long result = ForkJoinSumCalculator.forkJoinSum(50_000_000L);
		System.out.println(result);
	}

	@Test
	@DisplayName("ForkJoinTask method should work as expected")
	void forkJoinTaskMethodShouldWorkAsExpected() {
		List<String> list = List.of("hello", "world", "a", "b", "c", "cyan");
		IntStream.range(0, list.size())
				.mapToObj(list::get)
				.forEach(System.out::println);
	}

	@Test
	@DisplayName("CharacterPlusString should work as expected")
	void characterPlusStringShouldWorkAsExpected() {
		String s = "hello world";
		var result = Character.toUpperCase(s.charAt(0)) + s.substring(1);
		Assertions.assertEquals("Hello world", result);
		System.out.println('C' + "hello");
	}

	@Test
	@DisplayName("quiz8.2 improvement")
	void quiz82Improvement() {
		Seven seven = new Seven();
		Map<String, Integer> map = new HashMap<>() {
			{
				put("JamesBond", 20);
				put("Matrix", 15);
				put("Harry Potter", 5);

			}
		};
		seven.simplifyQuiz82(map);
	}

	@Test
	@DisplayName("groupingBuilder method should work correctly")
	void groupingBuilderMethodShouldWorkCorrectly() {
	}

}