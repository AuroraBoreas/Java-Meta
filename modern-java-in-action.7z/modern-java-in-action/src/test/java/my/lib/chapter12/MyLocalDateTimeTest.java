package my.lib.chapter12;

import org.junit.jupiter.api.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class MyLocalDateTimeTest {
	private MyLocalDateTime mdt;

	@BeforeEach
	void setUp() {
		mdt = new MyLocalDateTime();
	}

	@Test
	@DisplayName("createLocalDateAndReadItsValue method should work as expected")
	void createLocalDateAndReadItsValueMethodShouldWorkAsExpected() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		mdt.createLocalDateAndReadItsValue();
		var result = baos.toString();
		System.out.println(result);
		Assertions.assertAll(
				() -> Assertions.assertTrue(result.contains("THURSDAY")),
				() -> Assertions.assertTrue(result.contains("29")),
				() -> Assertions.assertTrue(result.contains("180")),
				() -> Assertions.assertTrue(result.contains("false"))
		);
	}

	@Test
	@DisplayName("temporalAdjust method should work as expected")
	void temporalAdjustMethodShouldWorkAsExpected() {
		mdt.temporalAdjuster();
	}

	@Test
	@DisplayName("buildChinaFormatter method should work as expected")
	void buildChinaFormatterMethodShouldWorkAsExpected() {
		mdt.buildChinaFormatter();
	}

	@Test
	@DisplayName("japaneseData method should work as expected")
	void japaneseDataMethodShouldWorkAsExpected() {
		mdt.japaneseDate();
	}

	@Test
	@DisplayName("tiradeVerbosity method should work as expected")
	void tiradeVerbosityMethodShouldWorkAsExpected() {
		mdt.tiradeVerbosity();
	}


}