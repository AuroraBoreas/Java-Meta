package my.lib.chapter11;

import java.util.Optional;

public class UseOptional {
	/* P308 Using Optional as an alternative to null */
	// when: may or may not (maybe)
	// how : Optional.of(); Optional.ofNullable();
	public String getCarInsuranceName(Optional<Person> person) {
	    return person.flatMap(Person::getCar)
			    .flatMap(Car::getInsurance)
			    .map(Insurance::getName)
			    .orElse("unknown");
	}
}