package my.lib.chapter11;

import java.util.Optional;

public class Car {
	private Optional<Insurance> insurance;

	public Car(Insurance insurance) {
		this.insurance = Optional.ofNullable(insurance);
	}

	public Optional<Insurance> getInsurance() {
		return insurance;
	}
}
