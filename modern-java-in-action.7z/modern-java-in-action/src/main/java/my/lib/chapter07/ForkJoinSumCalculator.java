package my.lib.chapter07;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.stream.LongStream;

public class ForkJoinSumCalculator extends java.util.concurrent.RecursiveTask<Long> {
	public static final long THRESHOLD = 10_000;
	/* P219 */
	private final long[] numbers;
	private final int start;
	private final int end;

	public ForkJoinSumCalculator(long[] numbers) {
		this(numbers, 0, numbers.length);
	}

	public ForkJoinSumCalculator(long[] numbers, int start, int end) {
		this.numbers = numbers;
		this.start = start;
		this.end = end;
	}

	public boolean isParallel() {
		return end - start >= THRESHOLD;
	}

	protected Long compute() {
		int length = end - start;
		if (length < THRESHOLD) {
			return computeSequentially();
		}
		ForkJoinSumCalculator left = new ForkJoinSumCalculator(numbers, start, length / 2);
		ForkJoinSumCalculator right = new ForkJoinSumCalculator(numbers, start + length / 2, end);
		long leftResult = left.compute();
		long rightResult = right.compute();
		return leftResult + rightResult;
	}

	private long computeSequentially() {
		long sum = 0;
		for (int i = start; i < end; i++) {
			sum += numbers[i];
		}
		return sum;
	}

	public static long forkJoinSum(long n) {
		// work stealing
		long[] numbers = LongStream.rangeClosed(1, n).toArray();
		ForkJoinTask<Long> task = new ForkJoinSumCalculator(numbers);
		return new ForkJoinPool().invoke(task);
	}
}
