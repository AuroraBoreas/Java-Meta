package my.lib.chapter07;

import java.util.Map;

public class Seven {
	// Stream
	// operation: sequential vs parallel(normal fjt)
	// category: LID
	// statistics: 大小计平和
	// source: F I G R
	//
	public void simplifyQuiz82(Map<String, Integer> map) {
		// Map has patterns
		// get
		// put
		// compute
		// forEach
		// reduce
		// search
		// replace
		// remove
		// sort
		map.entrySet().removeIf(e -> e.getValue() < 10);
		System.out.println(map);
	}
	
}
