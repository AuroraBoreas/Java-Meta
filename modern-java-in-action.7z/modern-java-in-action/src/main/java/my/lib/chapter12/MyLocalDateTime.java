package my.lib.chapter12;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.chrono.JapaneseDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;

import static java.time.temporal.TemporalAdjusters.*;

public class MyLocalDateTime {
	/* P339 / 592 */
	public void createLocalDateAndReadItsValue() {
		// plusXXX pattern (nanoseconds, milliseconds, seconds, minute, hour, day, date, week, month, year)
		// minusXXX pattern
		// isXXX pattern
		LocalDate date = LocalDate.of(2023, 6, 29);
		System.out.println(date.getDayOfWeek());
		System.out.println(date.getDayOfMonth());
		System.out.println(date.getDayOfYear());
		System.out.println(date.isLeapYear());
	}

	public void temporalAdjuster() {
		// firstDayOfXXX pattern (week, month, year)
		// lastDayOfXXX pattern (week, month, year)
		// nextXXX pattern
		// previousXXX pattern
		LocalDate d1 = LocalDate.of(2023, 6, 21);
		LocalDate d2 = d1.with(nextOrSame(DayOfWeek.SUNDAY));
		LocalDate d3 = d1.with(lastDayOfMonth());
		System.out.println(d1);
		System.out.println(d2);
		System.out.println(d3);
	}

	public void buildChinaFormatter() {
		// customize DataTimeFormatter xd
		// method pattern: appendXXX
		DateTimeFormatter dateTimeFormatter = new DateTimeFormatterBuilder()
				.appendText(ChronoField.DAY_OF_MONTH)
				.appendLiteral(". ")
				.appendText(ChronoField.MONTH_OF_YEAR)
				.appendLiteral(" ")
				.appendText(ChronoField.YEAR)
				.parseCaseInsensitive()
				.toFormatter(Locale.CHINA);

		LocalDate date = LocalDate.of(2023, 6, 29);
		String formattedDate = date.format(dateTimeFormatter);
		System.out.println(formattedDate);
		LocalDate newDate = LocalDate.parse(formattedDate, dateTimeFormatter);
		System.out.println(newDate);
	}

	public void japaneseDate() {
		LocalDate d1 = LocalDate.of(2023, Month.JUNE, 29);
		JapaneseDate d2 = JapaneseDate.from(d1);
		System.out.println(d2);
	}

	public void javaConcurrency() {
		ForkJoinPool pool = new ForkJoinPool(15);
		ForkJoinTask<String> task = pool.submit(
				() -> {
					String s = "hello";
					Thread.sleep(400);
					return s;
				}
		);

		String result = null;
		try {
			result = task.get();
		} catch (ExecutionException | InterruptedException ignore) {
		} finally {
			pool.shutdown();
		}
		System.out.println(result);
	}

	public void tiradeVerbosity() {
		// 5a r 3c
		// accept
		// anyOf
		// allOf
		// apply
		// async
		// run
		// compose
		// combine
		// complete
		System.out.println("finer-grained control vs coarse-grained control");
		System.out.println(Runtime.getRuntime().availableProcessors());
	}


}
