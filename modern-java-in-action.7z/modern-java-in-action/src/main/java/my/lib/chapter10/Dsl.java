package my.lib.chapter10;

public class Dsl {
	/* P299 / 592 */
	// L M N
	// function sequencing with lambdas
	// method chaining
	// nested functions
	// jOOQ DSL

	// Class.forName("org.h2.Driver");
}
